<?php

namespace App\Http\Controllers;
use App\Models\student_question;
use App\Models\cbt_data;
use App\Models\cbt_answer_data;
use App\Models\cbt_answer;
use App\Models\cbt_score_setting;
use App\Models\raw_score;
use App\Models\cbt_exam_submit;
use App\Models\cbt_score_data;
use App\Models\cbt_course;
use App\Models\control_level;
use App\Models\attendance_sheet;
use Illuminate\Http\Request;

class cbt_exam extends Controller
{
    //

    public function logout(){

        session()->pull('student_reg');
        session()->pull('student_name');
        session()->pull('faculty_id');
        session()->pull('department_id');
        session()->pull('cbt_data_id');
        session()->pull('cbt_set_id');

        return redirect('/');
    }
    public function cbt_exam_mode_status(){
        // checking for the available open courses
        $cbt_data = cbt_data::where('cbt_status', '=', 'published')->where('student_status', '=', 'activated')->get();
        return view('student.welcome', compact('cbt_data'));
    }
    private function cbt_mass_question_fetch($cbt_id){

       
        // cbt id are attached to a course id, random loop and
        $cbt_question = student_question::with('cbt_student_answer')->where('cbt_data_id', '=', $cbt_id)->get();

        return $cbt_question;
    }


    public function subject_select(request $request){

        // validation frokm request 
        $request->validate([
            'student_class' => 'required',
            'class_section' => 'required',
            'student_subject'
        ]);
        // putting the data in session 

        session()->put('student_reg', $request->student_reg);
        session()->put('student_name');
    }



    public function cbt_mode_submit(request $request){
        $request->validate([
            '_token' => 'required'
        ]);
        // amount of question recieved by the student
        $cbt_question = $request->cbt_question;
        $cbt_data = $request->input('cbt_data_id');
        // check the attempt limit of student and it started or finished
     
        if($request->ajax()){
        
            // pass in the data you want to return
            return response();
        }elseif(!$request->ajax()){
            // answer_create_update($student_reg, $cbt_data_id, $cbt_set_id, $cbt_student_answer, $cbt_question_id, $faculty_id, $department_id)
           
            // $request->dd();

            for($i=0; $cbt_question > $i; $i++){

                // if the current loop is true
                if($request->input('cbt_answer_'.$i)){

                    // insert or updating the cbt ansnwer db
                    $student_reg = session()->get('student_reg');
                    $cbt_data_id = session()->get('cbt_data_id');
                    $cbt_set_id = session()->get('cbt_data_id');
                    $cbt_student_answer = $request->input('cbt_answer_'.$i);
                    $cbt_question_id = $request->input('cbt_question_id_'.$i);
                    $faculty_id = session()->get('student_class');
                    $department_id = session()->get('class_subject');
                    // dd("hello world");    
                    $this->answer_create_update($student_reg, $cbt_data_id, $cbt_set_id, $cbt_student_answer, $cbt_question_id, $faculty_id, $department_id);
                }
            }
            // $request->dd();
            return redirect('/student_cbt/cbt_summary');
        }

    }

    private function answer_create_update($student_reg, $cbt_data_id, $cbt_set_id, $cbt_student_answer, $cbt_question_id, $faculty_id, $department_id){
        // checking if the answer existed
            $answer = cbt_answer_data::where('student_reg', '=', $student_reg)->where('cbt_data_id', '=', $cbt_set_id)->where('cbt_question_id', '=', $cbt_question_id)->where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_type', '=', session()->get('cbt_type'))->first();
      
            //if existed, then update the db
        if($answer){
            cbt_answer_data::where('student_reg', '=', $student_reg)->where('cbt_data_id', '=', $cbt_set_id)->where('cbt_question_id', '=', $cbt_question_id)->where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->update([
                'cbt_option_id' => $cbt_student_answer
            ]);
        }elseif(!$answer){
 
                cbt_answer_data::create([
                    'student_reg' => $student_reg,
                    'cbt_data_id' => $cbt_data_id,
                    'cbt_set_id' => $cbt_set_id,
                    'cbt_type' => session()->get('cbt_type'),
                    'cbt_option_id' => $cbt_student_answer,
                    'cbt_question_id' => $cbt_question_id,
                    'faculty_id' => $faculty_id,
                    'department_id' => $department_id,
                    'academic_session_id' => session()->get('academic_session_id')
                ]);
        }
    }

    public function cbt_question_fetch(){
        if(!session()->has('student_reg') && !session()->has('student_name') && !session()->has('student_class') && !session()->has('student_subject') && !session()->has('class_section')){

            return redirect('/student_login');
        }
        // cbt attempt limit check
        $course = cbt_course::where('course_id', '=', session()->get('class_subject'))->first();
        $cbt_data = cbt_data::where('course_id', '=', session()->get('class_subject'))->first();
        // student fetching questions
        $cbt_question = $this->cbt_mass_question_fetch($cbt_data->cbt_data_id);
        session()->put('cbt_data_id', $cbt_data->cbt_data_id);
         session()->put('cbt_type', $cbt_data->cbt_type);
         session()->put('cbt_duration', $cbt_data->cbt_duration);
        
        return view('student.cbt_mode_review', compact('cbt_question', 'course'));

    }



    public function cbt_score_submit(request $request){

        if(!session()->has('cbt_data_id') && !session()->has('class_subject') && !session()->get('student_reg')){

            return redirect('/student_login');
        }
        $request->validate([
            '_token' => 'required'
        ]);

        // score coming from staff
        $score_data = cbt_score_setting::where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_type', '=', session()->get('cbt_type'))->where('cbt_course_id', '=', session()->get('class_subject'))->first();
$score = $score_data->cbt_score;
        // student answer
        $student_answer = cbt_answer_data::where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_type', '=', session()->get('cbt_type'))->where('student_reg', '=', session()->get('student_reg'))->get();
       
        // cbt answer
        
        $count = count($student_answer);

        // dd($student_answer);
        for($i=0; $count > $i; $i++){
            $staff_answer = cbt_answer::where('cbt_data_id', '=', session()->get('cbt_data_id'))->where('cbt_question_id', '=', $student_answer[$i]->cbt_question_id)->where('option_label_id', '=', $student_answer[$i]->cbt_option_id)->where('option_status', '=', 'correct_option')->first();
      

            if($staff_answer){
        
                // check if exists
                $raw_score =raw_score::where('student_reg', '=', session()->get('student_reg'))->where('academic_session_id', '=', session()->get('academic_session_id'))->where('course_id', '=', session()->get('class_subject'))->where('cbt_type', '=', session()->get('cbt_type'))->where('cbt_question_id', '=', $staff_answer->cbt_question_id)->first();
        
                // dd($raw_score);
                if(!$raw_score){
                    
                    $create = raw_score::create([
                        'cbt_question_id' => $staff_answer->cbt_question_id,
                        'student_reg' => session()->get('student_reg'),
                        'academic_session_id' => session()->get('academic_session_id'),
                        'cbt_type' => session()->get('cbt_type'),
                        'course_id' => session()->get('class_subject'),
                        'score' => $score
                    ]);
                }

            }
            
            }

            // sum all the accumulated in the raw db and move it score db
            $final_score = raw_score::where('student_reg', '=', session()->get('student_reg'))->where('academic_session_id', '=', session()->get('academic_session_id'))->where('course_id', '=', session()->get('class_subject'))->where('cbt_type', '=', session()->get('cbt_type'))->sum('score');
        
            // checking final score exits

            $score_update = cbt_score_data::where('student_reg', '=', session()->get('student_reg'))->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_course_id', '=', session()->get('class_subject'))->where('cbt_type', '=', session()->get('cbt_type'))->first();
    
            if(!$score_update){
    //   dd($final_score);
                $create = cbt_score_data::create([
                    'student_reg' => session()->get('student_reg'),
                    'cbt_score' => $final_score,
                    'academic_session_id' => session()->get('academic_session_id'),
                    'cbt_course_id' => session()->get('class_subject'),
                    'cbt_type' => session()->get('cbt_type')
                ]);
        
            }elseif($score_update){
    //  dd("hi");           
                cbt_score_data::where('academic_session_id', '=', session()->get('academic_session_id'))->where('student_reg', '=', session()->get('student_reg'))->where('cbt_type', '=', session()->get('cbt_type'))->where('cbt_course_id', '=', session()->get('class_subject'))->update([
                    'cbt_score' => $final_score
                ]);

        }

            return back();
    }

    public function cbt_summary(){

        if(!session()->has('cbt_data_id') && !session()->has('cbt_course_id') && !session()->get('student_reg')){

            return redirect('/student_cbt/welcome');
        }
        $cbt_question = student_question::where('cbt_data_id', '=', session()->get('cbt_data_id'))->get();
        $cbt_exam_submit = cbt_score_data::where('student_reg', '=', session()->get('student_reg'))->where('cbt_type', '=', session()->get('cbt_type'))->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_course_id', '=', session()->get('class_subject'))->first();
        $course = cbt_course::where('course_id', '=', session()->get('class_subject'))->first();  
            //   dd($cbt_exam_submit);
        return view('student.cbt_summary', compact('cbt_exam_submit', 'course', 'cbt_question'));
    }

    public function cbt_course_select(request $request){

    $request->validate([
    '_token' => 'required'
    ]);
        // cbt test duration 
        $duration = cbt_data::where('cbt_data_id', '=', $request->cbt_data_id)->where('academic_session_id', '=', session()->get('academic_session_id'))->first();

        session()->put('cbt_duration', $duration->cbt_duration);
        
        // level 1 checking
        // compare cbt_data_id with the attendance sheet cbt_data_id, if not the same create new one
        $cbt_attendance_sheet = attendance_sheet::where('student_reg', '=', session()->get('student_reg'))->where('cbt_type', '=', $request->cbt_type)->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_course_id', '=', $request->cbt_course_id)->first();

        if(!$cbt_attendance_sheet){
        
        // create attendance sheet with the the same cbt data

            $create = attendance_sheet::create([
                'academic_session_id' => session()->get('academic_session_id'),
                'student_reg' => session()->get('student_reg'),
                'cbt_data_id' => $request->cbt_data_id,
                'cbt_type' => $request->cbt_type,
                'cbt_course_id' => $request->cbt_course_id
            ]);

            // attendance created successfully
            if($create){   
                $cbt_attendance_sheet = attendance_sheet::where('student_reg', '=', session()->get('student_reg'))->where('cbt_type', '=', $request->cbt_type)->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_course_id', '=', $request->cbt_course_id)->first();

                session()->put('cbt_type', $cbt_attendance_sheet->cbt_type);
                session()->put('cbt_data_id', $cbt_attendance_sheet->cbt_data_id);
            session()->put('cbt_set_id', $cbt_attendance_sheet->cbt_data_id);
            session()->put('cbt_course_id', $cbt_attendance_sheet->cbt_course_id);
    
            }
        }

        // if the current db cbt id with the session is the same
        if($cbt_attendance_sheet){
            
            session()->put('cbt_type', $cbt_attendance_sheet->cbt_type);
            session()->put('cbt_data_id', $cbt_attendance_sheet->cbt_data_id);
        session()->put('cbt_set_id', $cbt_attendance_sheet->cbt_data_id);
        session()->put('cbt_course_id', $cbt_attendance_sheet->cbt_course_id);
    }

            return redirect('/student_cbt/cbt_mode');

    }


}
