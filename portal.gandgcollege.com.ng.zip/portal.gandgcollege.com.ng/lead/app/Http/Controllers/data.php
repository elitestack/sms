<?php 
// migrate old question to new question

$cbt_data_count = cbt_question::where('cbt_data_id', '=', 'CBT_ID1692883053')->count();

$question_id = 'CBT_QI'.time().$cbt_data_count;
// $cbt_data_count;
    
// fetching oold data 
$old = cbt_data_migration::where('quiz_id','=', 'gst2023-06-09 00:59:01')->get();

$count = count($old);
 dd($count);

for($i=0; $count > $i; $i++){

    cbt_question::create([       
        'cbt_question_id' => $question_id,
        'cbt_question' => $old[$i]->question,
        'question_no' => $old[$i]->question_id,                    
        'cbt_staff_id' => 'gst112staff@cbt.com',
        'cbt_data_id' => 'CBT_ID1695888250',
        'faculty_id' => 'FA1692879632',
        'department_id' => 'DA1692880598'
    ]);
}

// migrate old question to new question

// create new student 
$row_count = student_data::count();

$result = $row_count + 1;
if($result < 10){

    $student = '000'.$result;
}elseif($result > 10 && $result < 100){
    $student = '00'.$result;
}elseif($result > 100 && $result < 1000){
    $student = '0'.$result;
}else{
    $student = $result;
}

$student_reg = 'FT22ACMP'.$student;

// dd($student_reg);
student_data::create([
    'student_reg' => $student_reg,
    'name'=> 'Test Data',
    'level' => '100l',
    'department_id' => 'DA1694722852',
    'faculty_id' => 'FA1694722765',
]);

// create new student end

// registering new corse for student

$check = student_register_courses::where('student_reg', '=', $student[$i]->student_reg)->where('cbt_course_id', '=', 'CBT_COURSE1692883198')->first();
if(!$check){
    student_register_courses::create([
        'student_reg' =>$student[$i]->student_reg,
        'cbt_course_id' => 'CBT_COURSE1692883198',
        'department_id' => 'DA1694722852',
        'faculty_id' => 'FA1694722765',
    ]);
}
// registering new courses for student end