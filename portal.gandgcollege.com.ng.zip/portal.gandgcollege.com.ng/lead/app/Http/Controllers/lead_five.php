<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\temp_student_application_id;
use App\Models\pending_student;
use App\Models\student_passport;
use App\Models\student_reg_base;
use App\Models\student_2024_session;
use App\Models\academic_session;
use App\Models\academic_session_term;
use App\Models\student_class;
use App\Models\class_student_record;
use App\Models\student_ca;
use App\Models\student_grade_record;
use App\Models\pending_student_data;
use App\Models\test;

class lead_five extends Controller
{
    //

    public function application_data_m(){
        
        
        $d = student_ca::where('academic_session_id', '=', 7)->update([
            'term_id' => 7,
            'academic_session_id' => 8
            ]);
        
        
    }
    public function mass_result_sheet($academic_session_id, $term_id, $class_id){
        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $term = academic_session_term::where('id', '=', $term_id)->first();
        $class = student_class::where('id', '=', $class_id)->first();
        $student = student_reg_base::with('students')->get();
        

        $student_count = student_grade_record::where('academic_session_id', '=', $academic_session_id)->where('term_id', '=', $term_id)
        ->where('class_id', '=', $class_id)->count();



        if(!$academic_session || !$term || !$class){
        
            return redirect('/lead_five/student_result/'.$student_reg);
        
        }
        return view('mass_result_sheet', compact('academic_session','academic_session_id','term_id', 'class_id', 'student_count', 'term', 'class', 'student'));
    }



    
    public function result_sheet($academic_session_id, $term_id, $class_id, $student_reg){
        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $term = academic_session_term::where('id', '=', $term_id)->first();
        $class = student_class::where('id', '=', $class_id)->first();
        $student = student_reg_base::with('students')->where('student_reg', '=', $student_reg)->first();
        
        $result = student_ca::with('subject')->where('academic_session_id', '=', $academic_session_id)->where('term_id', '=', $term_id)
        ->where('class_id', '=', $class_id)->where('student_reg', '=', $student_reg)->get();
        $student_grade = student_grade_record::where('academic_session_id', '=', $academic_session_id)->where('term_id', '=', $term_id)
        ->where('class_id', '=', $class_id)->where('student_reg', '=', $student_reg)->first();


        $student_count = student_grade_record::where('academic_session_id', '=', $academic_session_id)->where('term_id', '=', $term_id)
        ->where('class_id', '=', $class_id)->count();



        if(!$academic_session || !$term || !$class || !$student){
        
            return redirect('/lead_five/student_result/'.$student_reg);
        
        }
        return view('result_sheet', compact('result', 'academic_session', 'student_count', 'term', 'class', 'student', 'student_grade'));
    }
    public function student_login(request $request){
        $request->validate([
            'student_reg' => 'required'
        ]);

        $validate = student_reg_base::where('student_reg', '=', $request->student_reg)->first();

        if(!$validate){

            return back()->with('message', 'invalid credentials');
        }
    
            return redirect('/lead_five/dashboard/'.$request->student_reg);
    }

    public function dashboard($student_reg){

              $student = student_reg_base::where('student_reg', '=', $student_reg)->first();


        if(!$student){

            return redirect('/student_login')->with('message', 'invalid credentials');
        }


        $application_data = pending_student::where("application_id", "=", $student->application_id)->first();
        $passport = student_passport::where('application_id', '=', $student->application_id)->first();

        return view('lead_five.dashboard', compact('student','student_reg', 'application_data', 'passport'));
    }
    
    
    public function admin_student_data($student_reg){

              $student = student_reg_base::where('student_reg', '=', $student_reg)->first();


        if(!$student){

            return redirect('/student_login')->with('message', 'invalid credentials');
        }


        $application_data = pending_student::where("application_id", "=", $student->application_id)->first();
        $passport = student_passport::where('application_id', '=', $student->application_id)->first();

        return view('lead_five.admin_student_data', compact('student','student_reg', 'application_data', 'passport'));
    }


   
    public function logout(){

        return redirect('/student_login');
    }
    public function student_class($student_reg){

        return view('lead_five.student_class', compact('student_reg'));
    }

    public function student_result($student_reg){

        $student = student_reg_base::where('student_reg', '=', $student_reg)->first();
        $result = class_student_record::where('student_reg', '=', $student_reg)->with('class')->
        with('academic_session')->with('term')->get();
        // dd($result);

        if(!$student){

            return redirect('/student_login')->with('message', 'invalid credentials');
        }

        return view('lead_five.student_result', compact('result', 'student'));
    }

    public function application_login(request $request){

       $request->validate([
         "application_id" => "required"
       ]);
        // verifies the application id eitther with guardian phone number or application id
       $pending_application_id = pending_student::where("application_id", "=", $request->application_id)->first();
       $pending_application_phone_number = pending_student::where("guardian_phone", "=", $request->application_id)->first();


    //    if the application id exists
       if($pending_application_id){

        // start session 
        session()->put("application_id", $pending_application_id->application_id);
        // return to application dashboard with information
            return redirect("/application/".$pending_application_id->application_id);
       }

        // if the phone number exists return with array of application attach to the account

        if($pending_application_phone_number){

                    // return to application dashboard with information
                    return redirect("/application_associated/".$pending_application_phone_number->guardian_phone);

        }

        // restrict login

        return back()->with("message", "invalid credential, please contact management system");
    }







    public function associated_application($application_id){
        // return arrays of associated applications 
        $applicated_associated = pending_student::where("guardian_phone", "=", $application_id)->get();
        
        // if data does not exists
        if(!$applicated_associated){

            return redirect("/application_login");
        }
        return view("associated_application", compact('applicated_associated'));
    }







public function student_passport_upload(request $request){

    // upload student passport
    $request->validate([
        "student_passport" => "required"
    ]);

    // renaming passport
    $passport_name = session()->get('application_id').".".$request->student_passport->extension();

    // move passport to storage folder and db reference 
    $request->student_passport->move(public_path("student_passport"), $passport_name);
    // verifies if passport exists already
    $db_passport_verify = student_passport::where("application_id", "=", session()->get("student_passport"))->first();

    if(!$db_passport_verify){

        $db_passport_store = student_passport::create([
            "student_passport" => $passport_name,
            "application_id" => session()->get("application_id")
        ]);
        
        return back();
    }
    
    // update existing passport
    $db_passport_verify = student_passport::where("application_id", "=", session()->get("student_passport"))->update([
        "student_passport" => $request->student_passport
    ]);


    return back();
}





    public function application_data($application_id){

        $application_data = pending_student::where("application_id", "=", $application_id)->first();
        $passport = student_passport::where('application_id', '=', session()->get('application_id'))->first();
        // if application does not exist

        if(!$application_data){
            
            return redirect("/application_login");
        }

        if($application_data->application_status === 'activated'){
            
            $student_reg_id = student_2024_session::where('application_id', '=', $application_id)->first();

            if(!$student_reg_id){
    
                $student_reg_create = student_2024_session::create([
                    'application_id' => $application_id,
                    'student_reg' => 'pending'
                ]);
            }
                // student reg generation 
                $student_reg_id = student_2024_session::where('application_id', '=', $application_id)->first();
                
                if($student_reg_id->id < 9){
                    $new_student_reg = 'MCA000'.$student_reg_id->id;
                }elseif($student_reg_id->id < 99){
                    $new_student_reg = 'MCA00'.$student_reg_id->id;
                }elseif($student_reg_id->id < 999){
                    $new_student_reg = 'MCA0'.$student_reg_id->id;
                }elseif($student_reg_id->id > 999){
                    $new_student_reg = 'MCA'.$student_reg_id->id;
                }


          
                    student_2024_session::where('application_id', '=', $application_id)->update([
                        'application_id' => $application_id,
                        'student_reg' => $new_student_reg
                    ]);



                    //general base  
                $student_reg_base = student_reg_base::where('application_id', '=', $application_id)->first();
                if(!$student_reg_base){
    
                    student_reg_base::create(
                       [
                        'application_id' => $application_id,
                        'student_reg' => $new_student_reg
                       ]
                    );
                }

                // return base that disable edit info
                return view('application_data_disabled', compact('application_data', 'passport'));

                }

                


                
            
        
        return view('application', compact('application_data', 'passport'));
    }




    public function student_application_update(request $request){
        $request->validate([
            'surname' => 'required',
            'othernames' => 'required',
            'sex' => 'required',
            'address' => 'required',
            'guardian' => 'required',
            'guardian_address' => 'required',
            'guardian_phone' => 'required'
        ]);

        $update = pending_student::where('application_id', '=', $request->application_id)->update([
            "surname" => $request->surname,
            "othernames" => $request->othernames,
            "sex"=> $request->sex,
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
        ]);

        if(!$update){
            return back()->with('message', 'please try again...');
        }
        return back()->with('message', 'application data updated successfully');
    }




    public function student_data_update(request $request){
        $request->validate([
            'address' => 'required',
            'guardian' => 'required',
            'guardian_address' => 'required',
            'guardian_phone' => 'required',
            'application_id' => 'required'
        ]);

 
        $update = pending_student::where('application_id', '=', $request->application_id)->update([
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
        ]);

        if(!$update){
            return back()->with('message', 'please try again...');
        }
        return back()->with('message', 'application data updated successfully');
    }


    public function admin_student_data_update(request $request){
        // $request->dd();
        $request->validate([
            'address' => 'required',
            'guardian' => 'required',
            'guardian_address' => 'required',
            'guardian_phone' => 'required',
            'application_id' => 'required',
            'surname'=> 'required',
            'othernames' => 'required'
        ]);

 
        $update = pending_student::where('application_id', '=', $request->application_id)->update([
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
            'othernames' => $request->othernames,
            'surname' => $request->surname
        ]);

        if(!$update){
            return back()->with('message', 'please try again...');
        }
        return back()->with('message', 'application data updated successfully');
    }


    public function student_application(request $request){

        // student application data
        $request->validate([
            'surname' => 'required',
            'othernames' => 'required',
            'sex' => 'required',
            'address' => 'required',
            'guardian' => 'required',
            'guardian_address' => 'required',
            'guardian_phone' => 'required'
        ]);

        // create temp application id

        $temp_id = time().rand(0, 100000);

        // save the tmp id 
        temp_student_application_id::create([
            "temp_id" =>$temp_id 
        ]);

        // generating the student application id
        $temp_id_db = temp_student_application_id::where("temp_id", "=", $temp_id)->first();
        $application_format = "MCA000N";
        $new_application_id = $application_format.$temp_id_db->id;
        // if($temp_id_db->id < 1){
        //     $new_application_id = $application_format."000".$temp_id_db->id;
        // }else if($temp_id_db->id > 9){
        //     $new_application_id = $application_format."00".$temp_id_db->id;
        
        // }else if($temp_id_db->id > 99){
        //     $new_application_id = $application_format."0".$temp_id_db->id;
        // }else{
        //     $new_application_id = $application_format.$temp_id_db->id;
        // }

        // save the application in database 
        $save_application = pending_student::create([
            "surname" => $request->surname,
            "othernames" => $request->othernames,
            "sex"=> $request->sex,
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
            "application_id" => $new_application_id,
            "academic_session_id" => "pending",
            "term_id" => "pending",
            'application_status' => 'pending'
            // other credentials
        ]);

        // start session and return redirect to continue application
        session()->put("application_id", $new_application_id);

        return redirect("/application_login");

    }

    public function application(request $request){

        //update existing applications 
    }
}
