<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\assign_class;
use App\Models\subject;
use App\Models\assign_subject;
use App\Models\academic_session;
use App\Models\academic_session_term;
use App\Models\academic_session_term as term;
use App\Models\student_class;
use App\Models\class_student_record;
use App\Models\assign_staff_subject;
use App\Models\student_ca;

class lead_four extends Controller
{
    //

    public function assessment_data($academic_session_id, $term_id, $subject_id){


        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $subject = assign_staff_subject::with('subject')->with('class')->where('staff_id', '=', session()->get('lead_four'))->where('subject_id', '=', $subject_id)->first();
        $term = term::where('id', '=', $term_id)->first();
        $student = class_student_record::where('class_id', '=', $subject->class->id)->where('academic_session_id', '=', $academic_session_id)
        ->where('term_id', '=', $term_id)->get();

// dd($student);
        // fetch student data attach to the class for the session and term

        if(!$academic_session || !$term || !$subject){

            return redirect('/lead_four/class');
        }
        return view('lead_four.general_assessment_sheet', 
        compact('subject', 'academic_session', 'term', 'student'));
    }
    public function dashboard(){

        return view('lead_four.dashboard');
    }


    public function assessment_capture(request $request){
        // $request->dd();
$request->validate([
    'academic_session_id' => 'required',
    'term_id' => 'required',
    'class_id' => 'required',
    'subject_id' => 'required'
]);
        // loop and save in database
        for($i = 0; $request->input('student_count') > $i; $i++){
            $update = student_ca::where('student_reg', '=', $request->input('student_reg_'.$i))->
            where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->
            where('subject_id', '=', $request->subject_id)->
            where('class_id', '=', $request->class_id)->update([
                'ca_score' => $request->input('ca_score_'.$i),
                'exam_score' => $request->input('exam_score_'.$i)
            ]);

           
        }

        return back()->with('message', 'record updated successfully');
    }

    public function class(){

        $assigned_class = assign_class::with('class')->where('staff_email', '=', session()->get('lead_four'))
        ->get();
        return view('lead_four.class', compact('assigned_class'));
    }

    public function select_class(request $request){

        $request->validate([
            'class_id' => 'required'
        ]);

        return redirect('/lead_four/class/'.$request->class_id);
    }

    public function class_data($class_id){

        // return subjects and make the staff is assigned to the class
        $assigned_subject = assign_subject::with('subject')->where('class_id', '=', $class_id)->get();
        $academic_data = academic_session::where('academic_session_status', '=', 'published')->first();
        $term = academic_session_term::where('term_status', '=', 'published')->where('academic_session_id', '=', $academic_data->id)->first();


       if(!$assigned_subject && !$term){

        return redirect('/lead_four/dashboard');
       }
        return view('lead_four.class_data', compact('assigned_subject', 'academic_data', 'term'));
    }

    public function student(){

        $academic_session = academic_session::get();
        return view('lead_four.student', compact('academic_session'));
    }

    public function student_view(request $request){

        $request->validate([
            'academic_session_id' => 'required'
        ]);

        return redirect('/lead_four/student_view/academic_session='.$request->academic_session_id);
    }

    public function student_view_academic_session($academic_session_id){

        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $term = academic_session_term::where('academic_session_id', '=', $academic_session_id)->get();
        $class = student_class::get(); 
        return view('lead_four.student_view_academic_session', compact('term', 'class', 'academic_session'));
    }



    public function student_view_academic_session_term($academic_session_id, $term_id, $class_id){

        $student = class_student_record::where('class_id', '=', $class_id)->where('academic_session_id', '=', $academic_session_id)->where('term_id', '=', $term_id)->get();
        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $term = term::where('id', '=', $term_id)->first();
        $class = student_class::where('id', '=', $class_id)->first();
        if(!$class){

            return redirect('/lead_four/student')->with('message', 'unable to fetch student for the session and term');
        }

        if(!$student){

            return redirect('/lead_four/student')->with('message', 'unable to fetch student for the session and term');
        }
        if(!$academic_session){

            return redirect('/lead_four/student')->with('message', 'unable to fetch student for the session and term');
        }
        if(!$term){

            return redirect('/lead_four/student')->with('message', 'unable to fetch student for the session and term');
        }


        return view('lead_four.student_view_academic_session_term', compact('student','class', 'academic_session', 'term'));
    }



    public function fetch_student_term(request $request){
        $request->validate([
            'term_id' => 'required',
            'academic_session_id' => 'required',
            'class_id' => 'required'
        ]);

        return redirect('/lead_four/student_view/academic_session_id='.$request->academic_session_id.'/term_id='.$request->term_id.'/class_id='.$request->class_id);
    }


    public function ca_record_academic_session($academic_session_id, $subject_id){

        // validation 
        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $subject = assign_staff_subject::with('subject')->with('class')->where('staff_id', '=', session()->get('lead_four'))->where('subject_id', '=', $subject_id)->first();
        $term = term::where('academic_session_id', '=', $academic_session_id)->get();

        if(!$academic_session || !$subject){
            return redirect('/lead_four/ca_record')->with('message', 'action not allowed');
        }
        return view('lead_four.ca_record_academic_session', compact('academic_session', 'subject', 'term'));
    }


    public function ca_record_start(request $request){
        $request->validate([
            'subject_id' => 'required',
            'academic_session_id',
            'term_id' => 'required'
        ]);

        return redirect('/lead_four/ca_record/academic_session_id='.$request->academic_session_id.'/term_id='.$request->term_id.'/subject_id='.$request->subject_id);
    }

    public function ca_record_subject($subject_id){

        // $subject_id = assign_staff_subject::where('staff_id', '=', session()->get('lead_four'))
        // ->where('subject_id', '=', $subject_id)->first();
        $subject = assign_staff_subject::with('subject')->with('class')->where('staff_id', '=', session()->get('lead_four'))->where('subject_id', '=', $subject_id)->first();

        $academic_session = academic_session::get();

        if(!$subject){

            return redirect('/lead_four/ca_record')->with('message', 'please select a subject assigned to you');
        }

        return view('lead_four.ca_record_subject', compact('subject', 'academic_session'));
    }


    public function ca_record_post(request $request){
        $request->validate([
            'academic_session_id' => 'required',
            'subject_id' => 'required'
        ]);

        return redirect('/lead_four/ca_record/academic_session_id='.$request->academic_session_id.'/subject_id='.$request->subject_id);
    }
    public function ca_record(){

        $assign_subject = assign_staff_subject::with('subject')->with('class')->where('staff_id', '=', session()->get('lead_four'))->get();
        return view('lead_four.ca_record', compact('assign_subject'));

    }
}
