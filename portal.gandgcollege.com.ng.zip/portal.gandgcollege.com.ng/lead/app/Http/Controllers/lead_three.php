<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\academic_session;
use App\Models\academic_session_term;
use App\Models\student_class;
use App\Models\pending_student;
use App\Models\student_reg_base;
use App\Models\class_student_record;
use App\Models\academic_session_term as term;
use App\Models\temp_student_application_id;
use App\Models\student_passport;
use App\Models\student_2024_session;



class lead_three extends Controller
{
    //

    public function dashboard(){

        return view('lead_three.dashboard');
    }

    public function student(){

        $academic_session = academic_session::get();
        $class=student_class::get();
        $student = student_reg_base::with('students')->get();

        return view('lead_three.student', compact('academic_session', 'class', 'student'));
    }


public function submit_application(request $request){
            // student application data
        $request->validate([
            'surname' => 'required',
            'othernames' => 'required',
            'sex' => 'required',
            'address' => 'required',
            'guardian' => 'required',
            'guardian_address' => 'required',
            'guardian_phone' => 'required',
            'academic_session_id' => 'required',
            'dob' => 'required'
        ]);

        // create temp application id

        $temp_id = time().rand(0, 100000);

        // save the tmp id 
        temp_student_application_id::create([
            "temp_id" =>$temp_id 
        ]);

        // generating the student application id
        $temp_id_db = temp_student_application_id::where("temp_id", "=", $temp_id)->first();
        $application_format = "GNGA000N";
        $new_application_id = $application_format.$temp_id_db->id;
        

        // save the application in database 
        $save_application = pending_student::create([
            "surname" => $request->surname,
            "othernames" => $request->othernames,
            "sex"=> $request->sex,
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
            "application_id" => $new_application_id,
            "academic_session_id" => $request->academic_session_id,
            "term_id" => "pending",
            'application_status' => 'pending',
            'dob' => $request->dob
            // other credentials
        ]);

        // start session and return redirect to continue application
        session()->put("application_id", $new_application_id);
            session()->put("class_id", $request->class_id);
                    session()->put("sex", $request->sex);

        return redirect("/lead_three/application/".$new_application_id);

}

   public function application_data($application_id){

        $application_data = pending_student::where("application_id", "=", $application_id)->first();
        $passport = student_passport::where('application_id', '=', session()->get('application_id'))->first();
        // if application does not exist

        if(!$application_data){
            
            return redirect("/application_login");
        }

        if($application_data->application_status === 'activated'){
            
            $student_reg_id = student_2024_session::where('application_id', '=', $application_id)->first();

            if(!$student_reg_id){
    
                $student_reg_create = student_2024_session::create([
                    'application_id' => $application_id,
                    'student_reg' => 'pending'
                ]);
            }
                // student reg generation 
                $student_reg_id = student_2024_session::where('application_id', '=', $application_id)->first();
                
                if($student_reg_id->id < 9){
                    $new_student_reg = 'GNG24AS000'.$student_reg_id->id;
                }elseif($student_reg_id->id < 99){
                    $new_student_reg = 'GNG24AS00'.$student_reg_id->id;
                }elseif($student_reg_id->id < 999){
                    $new_student_reg = 'GNG24AS0'.$student_reg_id->id;
                }elseif($student_reg_id->id > 999){
                    $new_student_reg = 'GNG24AS'.$student_reg_id->id;
                }


          
                    student_2024_session::where('application_id', '=', $application_id)->update([
                        'application_id' => $application_id,
                        'student_reg' => $new_student_reg
                    ]);



                    //general bas
                $student_reg_base = student_reg_base::where('application_id', '=', $application_id)->first();
                if(!$student_reg_base){
    
                    student_reg_base::create(
                       [
                        'application_id' => $application_id,
                        'student_reg' => $new_student_reg
                       ]
                    );
                }

                // return base that disable edit info
                return view('application_data_disabled', compact('application_data', 'passport'));

                }

                

        
        return view('lead_three.student_data', compact('application_data', 'passport'));
    }


public function pending_admission($application_id){
        $application_data = pending_student::where("application_id", "=", $application_id)->first();
        if($application_data->term_id === "approved"){
            
            return $application_id." is already approved";
        }
        $passport = student_passport::where('application_id', '=', $application_id)->first();
        
        
                $current_class=student_class::where('id', '=', session()->get('class_id'))->first();
        $class=student_class::get();
                $term = term::where('academic_session_id', '=', $application_data->academic_session_id)->get();
                // dd($term);
               $academic_session_data = academic_session::where('id', '=', $application_data->academic_session_id)->first();
$academic_session = $academic_session_data->academic_session;
        // if application does not exist

        if(!$application_data){
            
            return "invalid admission application id, please confirm the admission application id";
        }

        if($application_data->application_status === "activated"){
            return redirect('/application/'.$application_id)->with('student application has been approved');

        }
        return view('lead_three.pending_admission', compact('application_data', 'passport', 'class', 'current_class', 'term', 'academic_session'));
    }
    
    public function application(){
        $class=student_class::get();
                $academic_session = academic_session::get();
        return view('lead_three.application', compact('class', 'academic_session'));
    }
    public function add_student(request $request){
        $request->validate([
            'student_reg' => 'required',
            'class_id' => 'required',
            'academic_session_id' => 'required'
        ]);

        // validate the student reg
        $student_verify = student_reg_base::with('students')->where('student_reg', '=', $request->student_reg)->first();
         $student = student_reg_base::with('students')->where('student_reg', '=', $request->student_reg)->first();
       
        $class = student_class::where('id', '=', $request->class_id)->first(); 
        $academic_session = academic_session::where('id', '=', $request->academic_session_id)->first();
        $term = term::where('academic_session_id', '=', $request->academic_session_id)->get();
        
        
        
        if(!$class){

            return back()->with('message', 'please select class');
        }
        if(!$academic_session){

            return back()->with('message', 'please select academic session');
        }
        if(!$student_verify){

            return back()->with('message', 'invalid student reg');
        }
        return view('lead_three.student_select_term', compact('student', 'class', 'academic_session', 'term'));
    }


public function student_application_approve(request $request){
        // $request->dd();
        $request->validate([
            'application_id' => 'required',
            'term_id' => 'required'
            
        ]);

        // fetch publish term and public academic session
        // $academic_session = academic_session::where('academic_session_status', '=', 'published')->first();
        // $term = academic_session_term::where('academic_session_id', '=', $request->academic_session_id)->first();
        // dd($term);
        // if(!$term){
            
        //     return back()->with('message', 'please select term');
        // }
        // approved and generate student reg id

        $verify_pending_student = pending_student::where('application_id', '=', $request->application_id)->update([
            "surname" => $request->surname,
            "othernames" => $request->othernames,
            "sex"=> $request->sex,
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
            "application_id" => $request->application_id,
            "term_id" => $request->term_id,
            'application_status' => 'activated'
        ]);


        if(!$verify_pending_student){
          
            return back()->with('message', 'invalid application id');
        
        }

        // generate matric number
        // $student_reg_config = student_reg_config::where('status', '=', 'published')->first();
        
        return redirect('/lead_three/generate_student_reg/'.$request->application_id)->with('student application has been approved');
    }

    public function generate_student_reg($application_id){

        $application_data = pending_student::where("application_id", "=", $application_id)->first();
        $passport = student_passport::where('application_id', '=', session()->get('application_id'))->first();
        // if application does not exist

        if(!$application_data){
            
            return redirect("/application_login");
        }

        if($application_data->application_status === 'activated'){
            
            $student_reg_id = student_2024_session::where('application_id', '=', $application_id)->first();

            if(!$student_reg_id){
    
                $student_reg_create = student_2024_session::create([
                    'application_id' => $application_id,
                    'student_reg' => 'pending'
                ]);
            }
                // student reg generation 
                $student_reg_id = student_2024_session::where('application_id', '=', $application_id)->first();
                
                if($student_reg_id->id < 9){
                    $new_student_reg = 'GNG24A000'.$student_reg_id->id;
                }elseif($student_reg_id->id < 99){
                    $new_student_reg = 'GNG24A00'.$student_reg_id->id;
                }elseif($student_reg_id->id < 999){
                    $new_student_reg = 'GNG24A0'.$student_reg_id->id;
                }elseif($student_reg_id->id > 999){
                    $new_student_reg = 'GNG24A'.$student_reg_id->id;
                }


          
                    student_2024_session::where('application_id', '=', $application_id)->update([
                        'application_id' => $application_id,
                        'student_reg' => $new_student_reg
                    ]);



                    //general base  
                $student_reg_base = student_reg_base::where('application_id', '=', $application_id)->first();
                if(!$student_reg_base){
    
                    student_reg_base::create(
                       [
                        'application_id' => $application_id,
                        'student_reg' => $new_student_reg
                       ]
                    );
                }


                    // check if similar records has not been created before
        // $student_check = class_student_record::where('student_reg', '=', $application_data->student_reg)
        // ->where('term_id', '=', $request->term_id)->where('academic_session_id', '=', $application_data->academic_session_id)->first();

        
        // if($student_check){

        //     return 'student has already been assigned already';
        //     }

        // create new record 
        // $create = class_student_record::create([
        //         'student_reg' => $new_student_reg,
        //         'class_id' => $application_data->class_id,
        //         'term_id' => $application_data->term_id,
        //         'academic_session_id' => $application_data->academic_session_id
        // ]);


                // return base that disable edit info
                return view('lead_three.generate_student_reg', compact('application_data', 'passport'));

                }

                

                
    }




    public function add_student_confirm(request $request){
     
        $request->validate([
            'student_reg' => 'required',
            'term_id' => 'required',
            'academic_session_id' => 'required',
            'class_id' => 'required'
        ]);

        
        // validates data 
        $student = student_reg_base::where('student_reg', '=', $request->student_reg)->first();
       
        $class = student_class::where('id', '=', $request->class_id)->first(); 
        $academic_session = academic_session::where('id', '=', $request->academic_session_id)->first();
        $term = term::where('academic_session_id', '=', $request->academic_session_id)->first();

        
        if(!$term){
            return redirect('/lead_three/dashboard')->with('message', 'please try again');
        }
        if(!$class){

            return redirect('/lead_three/dashboard')->with('message', 'please try again');
                }
        if(!$academic_session){

            return redirect('/lead_three/dashboard')->with('message', 'please try again');
        }
        if(!$student){

            return redirect('/lead_three/dashboard')->with('message', 'please try again');
        }

        // check if similar records has not been created before
        $student_check = class_student_record::where('student_reg', '=', $request->student_reg)
        ->where('term_id', '=', $request->term_id)->where('academic_session_id', '=', $request->academic_session_id)->first();

        
        if($student_check){

            return back()->with('message', 'student has already been assigned already');
        }

        // create new record 
        $create = class_student_record::create([
                'student_reg' => $request->student_reg,
                'class_id' => $request->class_id,
                'term_id' => $request->term_id,
                'academic_session_id' => $request->academic_session_id
        ]);

        if(!$create){

            return redirect('/lead_three/add_student')->with('message', 'unable to assign student to class');
        }
        return redirect('/lead_three/add_student')->with('message', 'student assgined to class successfully');

    }

    public function student_view(request $request){

        
        $request->validate([
            'academic_session_id'
        ]);

        return redirect('/lead_three/student_view/academic_session_id='.$request->academic_session_id);

    }

    public function student_view_academic_session($academic_session_id){

        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $term = term::where('academic_session_id', '=', $academic_session_id)->get();
        $class = student_class::get();

        if(!$academic_session){
            return redirect('/lead_three/add_student')->with('message', 'please select academic session');
        }
        return view('lead_three.student_view_academic_session', compact('academic_session', 'term', 'class'));
    }

    public function result_sheet($academic_session_id, $term_id, $class_id, $student_reg){
        
    }

    public function fetch_student_term(request $request){
        $request->validate([
            'term_id' => 'required',
            'academic_session_id' => 'required',
            'class_id' => 'required'
        ]);

        return redirect('/lead_three/student_view/academic_session_id='.$request->academic_session_id.'/term_id='.$request->term_id.'/class_id='.$request->class_id);
    }

    public function student_view_academic_session_term($academic_session_id, $term_id, $class_id){

        $student = class_student_record::where('class_id', '=', $class_id)->where('academic_session_id', '=', $academic_session_id)->where('term_id', '=', $term_id)->get();
        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $term = term::where('id', '=', $term_id)->first();
        $class = student_class::where('id', '=', $class_id)->first();

        if(!$class){

            return redirect('/lead_three/add_student')->with('message', 'unable to fetch student for the session and term');
        }


        if(!$student){

            return redirect('/lead_three/add_student')->with('message', 'unable to fetch student for the session and term');
        }
        if(!$academic_session){

            return redirect('/lead_three/add_student')->with('message', 'unable to fetch student for the session and term');
        }
        if(!$term){

            return redirect('/lead_three/add_student')->with('message', 'unable to fetch student for the session and term');
        }


        return view('lead_three.student_view_academic_session_term', compact('student', 'class', 'academic_session', 'term'));
    }

}
