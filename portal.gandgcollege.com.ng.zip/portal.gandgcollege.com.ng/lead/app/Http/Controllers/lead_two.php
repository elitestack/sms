<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\staff_data;
use App\Models\subject;
use App\Models\student_reg_base;
use App\Models\student_class;
use App\Models\assign_subject;
use App\Models\assign_class;
use App\Models\assign_staff_subject;
use App\Models\academic_session;
use App\Models\academic_session_term;
use App\Models\class_student_record;
use App\Models\student_grade_record;
use App\Models\student_ca;


class lead_two extends Controller
{
    //

    public function student_result_grade(request $request){

        $request->validate([
            'class_id' => 'required',
            'academic_session_id' => 'required',
            'term_id' => 'required'
        ]);
        

        // fetch all the students in the class for the academic session and class and term
        $class_record = class_student_record::where('class_id', '=', $request->class_id)->
        where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->get();

        // average 
        $average_data = assign_subject::where('class_id', '=', $request->class_id)->get();
        $average_subject_count = count($average_data);

// grade calculation
for($i =0; count($class_record) > $i; $i++){

    $ca_record = student_ca::where('student_reg', '=',  $class_record[$i]->student_reg)->where('class_id', '=', $request->class_id)->
    where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->first();

                    // sum all the student ca
if($ca_record){

    // summing
    $ca_sum = student_ca::where('student_reg', '=',  $class_record[$i]->student_reg)->where('class_id', '=', $request->class_id)->
    where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->sum('ca_score');

    $exam_sum = student_ca::where('student_reg', '=',  $class_record[$i]->student_reg)->where('class_id', '=', $request->class_id)->
    where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->sum('exam_score');


    $sum = $ca_sum + $exam_sum;
    $average = round( $sum/ $average_subject_count, 2);
    // storing the sum in db
    $store = student_grade_record::where('student_reg', '=', $class_record[$i]->student_reg)->where('class_id', '=', $request->class_id)->
    where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->first();

    if(!$store){
        student_grade_record::create([

            'academic_session_id' => $request->academic_session_id,
            'class_id' => $request->class_id,
            'term_id' => $request->term_id,
            'total_score' => $sum,
            'average' => $average,
            'position' => 'pending',
            'student_reg' => $class_record[$i]->student_reg
        ]);
    }

    student_grade_record::where('student_reg', '=', $class_record[$i]->student_reg)->where('class_id', '=', $request->class_id)->
    where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->update([
        'total_score' => $sum,
        'average' => $average,
        'position' => 'pending'
    ]);

}
    
// loop end
}

$raw = DB::select('SELECT
student_reg, total_score,
 rank() 
OVER (ORDER BY total_score DESC) 
AS position FROM student_grade_records WHERE class_id = ? AND academic_session_id = ? AND 
term_id = ?
', [
    $request->class_id,
    $request->academic_session_id,
    $request->term_id
]);

for($i=0; count($raw) > $i; $i++){

    student_grade_record::where('student_reg', '=', $raw[$i]->student_reg)->where('class_id', '=', $request->class_id)->
    where('academic_session_id', '=', $request->academic_session_id)->where('term_id', '=', $request->term_id)->update([
        'position' => $raw[$i]->position
    ]); 
}
return back()->with('message', 'student grade and grade position calculated successfully');

}



    public function grade_student_session_class($academic_session_id, $class_id){

        $term = academic_session_term::where('academic_session_id', '=', $academic_session_id)->get();
        $academic_session = academic_session::where('id', '=', $academic_session_id)->first();
        $class = student_class::where('id', '=', $class_id)->first();
       
        // pending case
        $student_grade = student_grade_record::with('academic_session')->with('term')->with('student')->
        with('class')->where('academic_session_id', '=', $academic_session_id)->where('class_id', '=', $class_id)->get();
        
        if(!$academic_session || !$class){

            return redirect('/lead_two/dashboard')->with('message', 'action not allowed');
        }
        return view('lead_two.grade_student_session_class', compact('term', 'student_grade', 'academic_session', 'class'));
    }

    public function grade_student_select(request $request){

        return redirect('/lead_two/grade_student/academic_session_id='.$request->academic_session_id
        .'&class_id='.$request->class_id);
    }

    public function grade_student(){

        $class = student_class::get();
        $academic_session = academic_session::get();

        return view('lead_two.grade_student', compact('class', 'academic_session'));
    }
    public function dashboard(){

        return view('lead_two.dashboard');
    }

    public function subject(){

        $subject = subject::get();
        return view('lead_two.subject', compact('subject'));
    }

    public function class_data($class_id){
        $class = student_class::where('id', '=', $class_id)->first();

        if(!$class){
            return redirect('/lead_two/student_class');
        }
        $staffs = staff_data::where('staff_role', '=', 'lead_four')->get();
        $subject = subject::get();
        $class_subject = assign_subject::with('subject')->where('class_id', '=', $class_id)->get();
        $assigned_staff = assign_class::with('staff')->where('class_id', '=', $class_id)->first();
       
        return view('lead_two.class_data', compact('subject', 'class_subject',
    'class', 'staffs', 'assigned_staff'
    ));
    }

    public function assign_subject(request $request){
        $request->validate([
            'subject_id' => 'required',
            'class_id' => 'required'
        ]);
        // assing subjects
        $check = assign_subject::where('subject_id', '=', $request->subject_id)->where('class_id', '=', $request->class_id)->first();
        
        if($check){

            return back()->with('message', 'subject already added');
        }

        $add = assign_subject::create([
            'subject_id' => $request->subject_id,
            'class_id' => $request->class_id
        ]);

        if(!$add){

            return back()->with('message', 'unable to add subject to class');
        }

        return back()->with('message', 'subject added successfully');
    }

    public function student_class(){

        $class = student_class::get();
        return view('lead_two.student_class', compact('class'));
    }


    public function students(){

        $student = student_reg_base::with('students')->get();
        $academic_session = academic_session::get();
        $class = student_class::get(); 

        return view('lead_two.students', compact('student', 'academic_session', 'class'));
    }

    public function staff(){
        $staff = staff_data::get();
        return view('lead_two.staff', compact('staff'));
    }


    public function create_staff(request $request){

        // this account type can only create lead four staff

        $request->validate([
            'staff_email' => 'required',
            'staff_name' => 'required'
        ]);

        // validates if the exists already
        $validate = staff_data::where('staff_email', '=', $request->email)->first();

        if($validate){

            return back()->with('message', 'staff email already exists');
        }

        $create = staff_data::create([
            'staff_email' => $request->staff_email,
            'staff_name' => $request->staff_name,
            'staff_role' => 'lead_four',
            'password' => 'new12345678'
        ]);

        if(!$create){

            return back()->with('message', 'unable create new staff');
        }

        return back()->with('message', 'staff created successfully, staff can login with the default password');
    }


    public function assign_staff(request $request){
        $request->validate([
            'staff_email',
            'class_id'
        ]);

        // check if the class has been assigned to a staff before
        $check = assign_class::where('class_id', '=', $request->class_id)->first();

        if($check){

            // update record
            $update = assign_class::where('class_id', '=', $request->class_id)->update([
                'staff_email' => $request->sttaff_email
            ]);

            if(!$update){

                return back()->with('message', 'please try again...');
            }
            return back()->with('message', 'record updated successfully');
        }

        // create new record 
        $create = assign_class::create([
            'class_id' => $request->class_id,
            'staff_email' => $request->staff_email
        ]);

        if(!$create){

            return back()->with('message', 'record not created successfully');
        }

        return back()->with('message', 'records created successfully');
    }

    public function assign_class(request $request){

        // validate request
        $request->validate([
            'class_id',
            'staff_email'
        ]);

        return redirect('/lead_two/staff/'.$request->staff_email.'/'.$request->class_id);
    }


    public function staff_data($staff_email){
        $class = student_class::get();
        return view('lead_two.staff_data', compact('staff_email', 'class'));
    }

    public function staff_data_assign_subject($staff_email, $class_id){

        $subject = subject::get();
        $assign_subject = assign_staff_subject::with('subject')->with('class')->where('staff_id', '=', $staff_email)->get();
        // dd( $assign_subject);
        return view('lead_two.assign_staff_class_subject', compact('staff_email', 'subject', 'class_id', 'assign_subject'));
    }


    public function assign_subject_confirm(request $request){
        // 
        
        $request->validate([
            'class_id' => 'required',
            'subject_id' => 'required',
            'staff_email' => 'required'
        ]);

        $check = assign_staff_subject::where('class_id', '=', $request->class_id)->where('subject_id', '=',
        $request->subject_id
        )->where('staff_id', '=', $request->staff_email)->first();

        if($check){
            return back()->with('message', 'subject is already assigned to staff');

        }


        $create = assign_staff_subject::create([
            'subject_id' => $request->subject_id,
            'class_id' => $request->class_id,
            'staff_id' => $request->staff_email
        ]);

        if(!$create){

            return back()->with('message', 'subject not assigned to staff successfully');
        }

        return back()->with('message', 'subject assigned to staff sucessfully');

    }
}
