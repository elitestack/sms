<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\cbt_course;
use App\Models\assign_course;
use App\Models\cbt_data;
use App\Models\staff_data;
use App\Models\cbt_score_data;
use App\Models\control_level;
use App\Models\academic_session;


class department_controller extends Controller
{
    //

    public function student_cbt_fetch_result($course_id, $academic_session_id){
        $score_sheet = cbt_score_data::where('cbt_course_id', '=',$course_id)->where('academic_session_id', '=', $academic_session_id)->get();
    //    dd($score_sheet);
    $score_sheet_count = count($score_sheet);
    // dd($score_sheet_count);    
    if($score_sheet_count === 0){

            return redirect('/department/student_result');
        }
        return view('department.student_result_sheet', compact('score_sheet'));
    }

    public function student_result_request(request $request){

        $request->validate([
            '_token' => 'required'
        ]);
       return  redirect('/department/student_cbt_result/course_id='.$request->course_id.'&academic_session_id='.$request->academic_session_id);

    }

    public function cbt_data_processing(request $request){


        $request->validate([
            'cbt_session_id' => 'required',
            'cbt_course_id' => 'required',
            'cbt_type' => 'required',
            '_token' => 'required'
        ]);
        return redirect('/department/cbt_data_id/cbt_session_id='.$request->cbt_session_id.'&cbt_course_id='.$request->cbt_course_id.'&cbt_type='.$request->cbt_type);
    }

    public function dashboard(){
        $staff_data = staff_data::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('incoming_request', '=', 'activated')->get();
        $course_data = cbt_course::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->get();
        return view('department.dashboard', compact('staff_data', 'course_data'));
    }

    public function cbt_data(){
        // dd('hi');
        $academic_session = academic_session::all();
        $course_data = cbt_course::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->get();
        return view('department.cbt_data', compact('academic_session', 'course_data'));
    }

    public function cbt_data_id($cbt_session_id, $cbt_course_id, $cbt_type){
        // dd('hi');
        $cbt_data = cbt_data::where('student_status', '=', 'activated')->where('academic_session_id', '=', $cbt_session_id)->where('course_id', '=', $cbt_course_id)->where('cbt_status', '=', 'published')->where('cbt_type', '=', $cbt_type)->get();
        
        // dd($cbt_data);
        $cbt_data_count = count($cbt_data);
        if($cbt_data_count === 0){
            return redirect('/department/cbt_data');
        }

        $course_data = cbt_course::where('course_id', '=', $cbt_course_id)->first();
        $academic_session = academic_session::where('academic_session_id', '=', $cbt_session_id)->first();
        $cbt_data = cbt_data::where('student_status', '=', 'activated')->where('academic_session_id', '=', $cbt_session_id)->where('course_id', '=', $cbt_course_id)->where('cbt_status', '=', 'published')->where('cbt_type', '=', $cbt_type)->get();
        // $cbt_data = cbt_data::all();
        // dd($cbt_data);
        return view('department.cbt_data_id', compact('course_data', 'academic_session', 'cbt_data'));
    }

    public function control_level_request(request $request){
        $request->validate([
            'control_status' => 'required',
            '_token' => 'required' 
        ]);
        // check for data
        $control_level= control_level::where('department_id', '=', session()->get('department_id'))->where('academic_session_id', '=', $request->cbt_session_id)->where('course_id', '=', $request->course_id)->where('cbt_type', '=', $request->cbt_type)->where('cbt_data_id', '=', $request->cbt_data_id)->first();
        if(!$control_level){
        //   create new record
        $create = control_level::create([
            'department_control_level' => $request->control_status,
            'course_id' => $request->course_id,
            'cbt_type' => $request->cbt_type,
            'cbt_data_id' => $request->cbt_data_id,
            'academic_session_id' => $request->cbt_session_id,
            'department_id' => session()->get('department_id')
        ]);
        return back();

        }


        if($control_level){

            $update = control_level::where('department_id', '=', session()->get('department_id'))->where('academic_session_id', '=', $request->cbt_session_id)->where('course_id', '=', $request->course_id)->where('cbt_type', '=', $request->cbt_type)->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                'department_control_level' => $request->control_status,
            ]);

            return back();
          }

    }

    public function add_new_course(request $request){

        $request->validate([
            '_token' => 'required'
        ]);
        // dd(session()->get('faculty_id'));

        $course_reg_id = 'CBT_COURSE'.time().session()->get('ldi');

        // check for id the course exits

        $cbt_course_verify = cbt_course::where('course_name', '=', $request->course_name)->where('course_code', '=', $request->course_code)->first();

        // faculty data fetch
        if($cbt_course_verify){

            return back()->with('message', 'course already exists');
        }

        // dd(session()->get('faculty_id'));
        $cbt_course_create = cbt_course::create([
            'course_name' => $request->course_name,
            'course_code' => $request->course_code,
            'faculty_id' => session()->get('faculty_id'),
            'course_id' => $course_reg_id,
            'access_level' => 'pending',
            'department_id' => session()->get('department_id'),
            'staff_taken_id' => 'pending',
            'staff_created' => session()->get('faculty_id')
            
        ]);

        if(!$cbt_course_create){

            return back()->with('message', 'unable to create new course');
        }

        return back()->with('message', 'new course created successfully');

        
    }


    public function staff(){

        $deactivated_staff = staff_data::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('incoming_request', '=', 'deactivated')->get();
        $staff_fetch = staff_data::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('incoming_request', '=', 'activated')->get();
        // dd($cbt_course_fetch);
        return view('department.staff', compact('deactivated_staff', 'staff_fetch'));
    }

    public function incoming_request(){

        $total_staff = staff_data::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->get();
        $activated_staff = staff_data::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('incoming_request', '=', 'activated')->get();
        // dd($cbt_course_fetch);
        return view('department.incoming_request', compact('total_staff', 'activated_staff'));
    }

    public function staff_request(request $request){
                $request->validate([
                    '_token' => 'required'
                ]);

                // staff status
        if($request->status_request){

            if($request->staff_status === 'activated'){
                $status = 'deactivated';
            }elseif($request->staff_status === 'deactivated'){

                $status = 'activated';
            }

            $status_update = staff_data::where('email', '=', $request->staff_id)->update([
                'staff_status' => $status
            ]);
            return back();
        }

        // incoming request account status
        if($request->incoming_request){
            
                $status = 'activated';
            
            $status_update = staff_data::where('email', '=', $request->staff_id)->update([
                'incoming_request' => $status
            ]);

            // dd($status_update);
            return back();
        }
    }


    public function student_result(){

        $academic_session = academic_session::all();
        $course = cbt_course::where('department_id', '=', session()->get('department_id'))->get();
        return view('department.student_result', compact('academic_session', 'course'));
    }
    public function course_usage_request(request $request){

        $request->validate([
            'course_status' => 'required',
            'course_id' => 'required',
            'staff_id' => 'required',
            '_token' => 'required'
        ]);

        $update = assign_course::where('staff_id', '=', $request->staff_id)->where('course_id', '=', $request->course_id)->update([
            'status' => $request->course_status
        ]);

        return back();
    }

    public function add_new_course_request(request $request){
        $request->validate([
            'staff_id' => 'required',
            'course_id' => 'required',
            '_token' => 'required'
        ]);

        // check if the course has been assigned to the staff before
        $assign_check = assign_course::where('staff_id', '=', $request->staff_id)->where('course_id', '=', $request->course_id)->first();

        if(!$assign_check){
            $create = assign_course::create([
                'staff_id' => $request->staff_id,
                'course_id' => $request->course_id,
                'status' => 'activated',
                'faculty_id' => session()->get('faculty_id'),
                'department_id' => session()->get('department_id')
            ]);
        }
// dd("hi");
        return back();
    }
    public function course_usage($course_id){

        $data = assign_course::where('course_id', '=', $course_id)->get();
        // dd($data);
        $course = cbt_course::where('course_id', '=', $data[0]->course_id)->first();
        
        if(!$course){

            return redirect('/department/courses');
        }

        if(!$data){

            return redirect('/department/courses');
        }
        return view('department.course_usage', compact('data', 'course'));
    }
    public function courses(){

        $staff = staff_data::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('incoming_request', '=', 'activated')->get();
        $cbt_course_fetch = cbt_course::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->get();
        return view('department.courses', compact('cbt_course_fetch', 'staff'));
    }

}
