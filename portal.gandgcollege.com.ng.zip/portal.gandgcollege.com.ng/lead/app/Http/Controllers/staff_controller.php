<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Models\assign_course;
use App\Models\cbt_course;
use App\Models\cbt_data;
use App\Models\department;
use App\Models\faculty;
use App\Models\cbt_question;
use App\Models\student_question;
use App\Models\cbt_answer;
use App\Models\academic_session;
use App\Models\cbt_score_data;
use App\Models\cbt_score_setting;
use App\Models\control_level;
use App\Models\cbt_question_image;
use App\Models\activate_course;
use App\Models\quiz_answer;
use App\Models\cbt_data_migration;

class staff_controller extends Controller
{

    public function student_cbt_fetch_result($course_id, $academic_session_id){
        $score_sheet = cbt_score_data::where('cbt_course_id', '=',$course_id)->where('academic_session_id', '=', $academic_session_id)->get();
    //    dd($score_sheet);
    $score_sheet_count = count($score_sheet);
    // dd($score_sheet_count);    
    if($score_sheet_count === 0){

            return redirect('/staff/student_result');
        }
        return view('staff.student_result_sheet', compact('score_sheet'));
    }

    public function cbt_data_id_review($data_id){

        $cbt_question = student_question::with('cbt_student_answer')->where('cbt_data_id', '=', $data_id)->get();
        $cbt_data_id = cbt_data::where('cbt_data_id', '=', $data_id)->first();
        $course_data = cbt_course::where('course_id', '=', $cbt_data_id->course_id)->first();
        $count_cbt_question = count($cbt_question);
        if($count_cbt_question === 0){

            return redirect('/staff/cbt_data');
        }
        return view('staff.cbt_data_id_review', compact('cbt_question', 'course_data', 'cbt_data_id'));
    }
    public function student_result_request(request $request){

        $request->validate([
            '_token' => 'required'
        ]);
       return  redirect('/staff/student_cbt_result/course_id='.$request->course_id.'&academic_session_id='.$request->academic_session_id);

    }
 
    public function delete_add_media(request $request){

        // $request->dd();
        $request->validate([
            'cbt_question_id' => 'required',
            'image_name' => 'required'
        ]);

        // dd("hi");
        $delete = cbt_question_image::where('cbt_question_id', '=', $request->cbt_question_id)->where('image_name', '=', $request->image_name)->delete();
        
            return back();
        
    }
    public function activate_course_request(request $request){

        $request->validate([
            'academic_session' => 'required',
            'cbt_course' => 'required',
            'cbt_status' => 'required',
            'cbt_type' => 'required',
            '_token' => 'required'
        ]);

        $check = activate_course::where('staff_id', '=', session()->get('staff_id'))->where('cbt_type', '=', $request->cbt_type)->where('course_id', '=', $request->cbt_course)->where('academic_session_id', '=', $request->academic_session)->first();

        if($check){

            $update =activate_course::where('cbt_type', '=', $request->cbt_type)->where('course_id', '=', $request->cbt_course)->where('academic_session_id', '=', $request->academic_session)->update([
                'cbt_type' => $request->cbt_type,
                'status' => $request->cbt_status
            ]);
            
            return back();
        }

        $create = activate_course::create([
            'cbt_type' => $request->cbt_type,
            'status' => $request->cbt_status,
            'academic_session_id' => $request->academic_session,
            'course_id' => $request->cbt_course,
            'staff_id' => session()->get('staff_id')
        ]);

        return back();
    }
    
    public function activate_course(){

        $academic_session = academic_session::all();
        $activated_course = activate_course::where('staff_id', '=', session()->get('staff_id'))->get();
        $assign_courses = assign_course::where('staff_id', '=', session()->get('staff_id'))->get();
        return view('staff.activate_course', compact('academic_session', 'assign_courses', 'activated_course'));
    }

    public function dashboard(){

        // faculty data
        $faculty = $this->faculty_single_fetch(session()->get('faculty_id'));
        
        // cbt counts 
        $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->get();
                // department data
        $department = $this->faculty_department_data_fetch(session()->get('faculty_id'), session()->get('department_id'));
        $cbt_all_course_fetch = $this->cbt_assign_mass_fetch(session()->get('faculty_id'), session()->get('department_id'), session()->get('staff_id'));

        return view('staff.dashboard', compact('cbt_all_course_fetch', 'faculty', 'department', 'cbt_data'));
    }


    private function faculty_single_fetch($faculty_id){

        // fetching the faculty data from data
        $faculty = faculty::where('reg_code', '=', $faculty_id)->first();

        return $faculty;
    }

    public function activate_cbt_score_request(request $request){

        $request->validate([
            '_token' => 'required',
            'academic_session' => 'required',
            'cbt_course' => 'required',
            'cbt_score' => 'required',
            'cbt_type' => 'required'
        ]);

        // check for existing records

        $existing_record = cbt_score_setting::where('academic_session_id', '=', $request->academic_session)->where('cbt_course_id', '=', $request->cbt_course)->where('cbt_type', '=', $request->cbt_type)->first();

        if($existing_record){

            $update = cbt_score_setting::where('academic_session_id', '=', $request->academic_session)->where('cbt_course_id', '=', $request->cbt_course)->where('cbt_type', '=', $request->cbt_type)->update([
                'cbt_score' => $request->cbt_score
            ]);
        }elseif(!$existing_record){
            $create = cbt_score_setting::create([
                'academic_session_id' => $request->academic_session,
                'cbt_course_id' => $request->cbt_course,
                'cbt_score' => $request->cbt_score,
                'cbt_type' => $request->cbt_type
            ]);
        }

        return back();
    }
    public function cbt_course_config(){

        $academic_session = academic_session::all();
        $assign_courses = assign_course::where('staff_id', '=', session()->get('staff_id'))->where('status', '=', 'activated')->get();

        return view('staff.cbt_score_config', compact('academic_session', 'assign_courses'));
    }
    private function faculty_department_data_fetch($faculty_id, $department_id){

        // fetching from department

        $department = department::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->first();

        return $department;
    }
    private function cbt_assign_mass_fetch($faculty_id, $department_id, $staff_id){

        // checking for the records

        $assign_cbt_courses = assign_course::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('staff_id', '=', $staff_id)->where('status', '=', 'activated')->get();
        
        // dd($assign_cbt_courses);
        return $assign_cbt_courses;
    }

    private function cbt_assign_single_course_fetch($faculty_id, $department_id, $staff_id, $course_id){

        // checking for the records

        $assign_cbt_courses = assign_course::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('staff_id', '=', $staff_id)->where('course_id', '=', $course_id)->where('status', '=', 'activated')->first();

        return $assign_cbt_courses;
    }

    private function cbt_course_mass($faculty_id, $department_id, $staff_id){

        // fetch all cbt already created courses 

        $cbt_course = cbt_course::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('staff_id')->get();

        return $cbt_course;
    }

    public function cbt_data(){

        // courses fetching 
        // dd(session()->get('faculty_id'));
        $cbt_allow_course = $this->cbt_assign_mass_fetch(session()->get('faculty_id'), session()->get('department_id'), session()->get('staff_id'));
        $cbt_already_created_course = $this->created_cbt(session()->get('faculty_id'), session()->get('department_id'), session()->get('staff_id'));
        
        return view('staff.cbt_data', compact('cbt_allow_course', 'cbt_already_created_course'));
    }


    public function processing_set_cbt(request $request){

        $request->validate([
            'course_id' => 'required',
            'cbt_duration' => 'required',
            '_token' => 'required'
        ]);

        $rand = rand(10, 10000000);
        $cbt_id = 'CBT_ID'.time().session()->get('lsi').$rand.$rand;

        // dd($cbt_id);

        cbt_data::create([
            'course_id' => $request->course_id,
            'cbt_data_id' => $cbt_id,
            'staff_id' => session()->get('staff_id'),
            'department_id' => session()->get('department_id'),
            'faculty_id' => session()->get('faculty_id'),
            'cbt_duration' => $request->cbt_duration,
            'cbt_status' => 'draft',
            'academic_session_id' => 'pending',
            'cbt_type' => 'pending',
            'department_status' => 'deactivated',
            'student_status' => 'deactivated'
        ]);

        return back()->with('message', 'cbt created successfully');
    }

    private function cbt_course_question($faculty_id, $department_id, $staff_id, $cbt_id){

        $cbt_data = cbt_data::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('staff_id', '=', $staff_id)->where('cbt_data_id', '=', $cbt_id)->first();
        // dd($cbt_data);
        return $cbt_data;
    }
    private function created_cbt($faculty_id, $department_id, $staff_id){

        $cbt_data = cbt_data::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('staff_id', '=', $staff_id)->get();
        // dd($cbt_data);
        return $cbt_data;
    }
    private function question_id_check($cbt_id, $question_id){

        // checking for the question in the database
    }

    private function cbt_question_mass_fetch($cbt_id){

        $question = cbt_question::where('cbt_data_id', '=', $cbt_id)->where('cbt_staff_id', session()->get('staff_id'))->get();
        return $question;
    }

    private function cbt_question_single_fetch($cbt_id, $question_id){

        $question = cbt_question::where('cbt_data_id', '=', $cbt_id)->where('cbt_staff_id', session()->get('staff_id'))->where('cbt_question_id', '=', $question_id)->first();
        return $question;
    }


    private function cbt_assigned_staff($faculty_id, $department_id, $course_id){

        $cbt_data = cbt_data::where('faculty_id', '=', $faculty_id)->where('department_id', '=', $department_id)->where('course_id', '=', $course_id)->get();
        // dd($cbt_data);
        return $cbt_data;
    }

    private function awaiting_question_merging($id){


    }

    private function cbt_data_id_verify($cbt_id){
        // running checks
        $cbt_check = cbt_data::where('cbt_data_id', '=', $cbt_id)->first();

        // returning results
        return $cbt_check;
    }

    private function existing_question_count($cbt, $staff_id){

        // counting
        $count = cbt_question::where('cbt_data_id', '=', $cbt)->where('cbt_staff_id', '=', $staff_id)->count();
        return $count;
    }

    public function processing_set_questions(request $request){

        $request->validate([
            'question' => 'required',
            'cbt_data_id' => 'required',
            '_token' => 'required'
        ]);

        // generate cbt_question id
        $rand = rand(10, 100000000);
        $question_id = 'CBT_QI'.time().$rand.session()->get('lsi').$rand;


        // cbt_data_id verification 
        $cbt_data_id_verify = $this->cbt_data_id_verify($request->cbt_data_id);

        if(!$cbt_data_id_verify){
            return back()->with('message', 'invalid CBT ID');
            // dd($question_id);
        }
        // counting the row of question number and adding plus to it
        $counting = $this->existing_question_count($request->cbt_data_id, session()->get('staff_id'));
        $question_no = $counting + 1;
        // creating new question
        $new_question = $this->create_question($question_id,$request->question, $request->cbt_data_id, session()->get('staff_id'), session()->get('faculty_id'), session()->get('department_id'),$question_no);

        if($new_question){
            return back()->with('message', 'question added successfully');
        }

        return back()->with('message', 'question not added successfully');
    }

    public function cbt_data_setting_request(request $request){

$request->validate([
    '_token' => 'required'
]);
        // fetching related
        if($request->cbt_session){

            
            $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                'academic_session_id' => $request->academic_session_id
            ]);
            
            return back();
        }
        if($request->cbt_type){

            $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                'cbt_type' => $request->cbt_type_value
            ]);
            
            return back();
            
        }

        $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->first();
        // dd(session()->get('staff_id'));
        if(!$cbt_data){

            return redirect('/staff/cbt_data');
        }

        if($request->cbt_status){

                // checking cbt status
                if($cbt_data->cbt_status === 'published'){
                    $cbt_status = 'draft';
                }elseif($cbt_data->cbt_status === 'draft'){
                    $cbt_status = 'published';
                }
                $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                    'cbt_status' => $cbt_status
                ]);

                // dd($cbt_data);
                return back()->with('message', 'saved successfully');
        }elseif($request->student_status){

                // checking student status
                if($cbt_data->student_status === 'deactivated'){
                    $student_status = 'activated';
                }elseif($cbt_data->student_status === 'activated'){
                    $student_status = 'deactivated';
                }
                $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                    'student_status' => $student_status
                ]);

                return back()->with('message', 'saved successfully');


        }elseif($request->admin_status){

                // checking student status
                if($cbt_data->admin_status === 'deactivated'){
                    $admin_status = 'activated';
                }elseif($cbt_data->admin_status === 'activated'){
                    $admin_status = 'deactivated';
                }
                $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                    'admin_status' => $admin_status
                ]);

                return back()->with('message', 'saved successfully');
        }elseif($request->faculty_status){

                        // checking cbt question merging
                        if($cbt_data->cbt_question_merging !== 'disable'){
                            // checking student status
                            if($cbt_data->faculty_status === 'deactivated'){
                                $faculty_status = 'activated';
                            }elseif($cbt_data->faculty_status === 'activated'){
                                $faculty_status = 'deactivated';
                            }
                            $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                                'faculty_status' => $faculty_status
                            ]);
            
                            return back()->with('message', 'saved successfully');
                        }
        }elseif($request->department_status){


                            // checking student status
                            if($cbt_data->department_status === 'deactivated'){
                                $department_status = 'activated';
                            }elseif($cbt_data->student_status === 'activated'){
                                $department_status = 'deactivated';
                            }

                            $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                                'department_status' => $department_status
                            ]);

            
                            return back()->with('message', 'saved successfully');
                        }elseif($request->cbt_duration){
                            // checking student status
                            if($cbt_data->student_status === 'deactivated'){
                                $student_status = 'activated';
                            }elseif($cbt_data->student_status === 'activated'){
                                $student_status = 'deactivated';
                            }
                            $cbt_data = cbt_data::where('staff_id', '=', session()->get('staff_id'))->where('cbt_data_id', '=', $request->cbt_data_id)->update([
                                'student_status' => $student_status
                            ]);
            
                            return back()->with('message', 'saved successfully');
                        }

        return redirect('/staff/cbt_data');
    }

    private function create_question($question_id,$question,$cbt_data_id,$staff_id,$faculty_id,$department_id,$question_no){

        // checks if the questions exists already

        $existing_question_check = cbt_question::where('cbt_staff_id', '=', $staff_id)->where('cbt_question_id', '=', $question_id)->first();
    
        if(!$existing_question_check){
        // adding the question to database
        $cbt_question_create = cbt_question::create([
            'cbt_question_id' => $question_id,
            'cbt_question' => $question,
            'cbt_data_id' => $cbt_data_id,
            'cbt_staff_id' => $staff_id,
            'faculty_id' => $faculty_id,
            'department_id' => $department_id,
            'question_no' => $question_no
        ]);
            if($cbt_question_create){

                return $cbt_question_create;
            }
        }elseif($existing_question_check){
            $cbt_question_update = cbt_question::where('cbt_staff_id', '=', $staff_id)->where('cbt_question_id', '=', $question_id)->update([
            'cbt_question' => $question,
            'cbt_data_id' => $cbt_data_id,
            'faculty_id' => $faculty_id,
            'department_id' => $department_id,
            'question_no' => $question_no
            ]);

            if($cbt_question_update){
                
                return $cbt_question_update;
            }
        }
        
    }

    private function cbt_course_data($cbt_id){

        // fetch the cbt course 

        $cbt_data = cbt_data::where('cbt_data_id', '=', $cbt_id)->first();
        $course_fetch = cbt_course::where('course_id', '=', $cbt_data->course_id)->first();

        // return the data

        return $course_fetch;
    }
    
    public function cbt_setting($cbt_id){

        // condition to reject wrong id
        $cbt_data = $this->cbt_data_id_verify($cbt_id);

        if(!$cbt_data){

            return redirect('/staff/cbt_data');
        }
        // cbt course fetch
        $course_fetch = cbt_course::where('course_id', '=', $cbt_data->course_id)->first();
        // faculty data
        $faculty = $this->faculty_single_fetch(session()->get('faculty_id'));
        // departmental data 
        $department = $this->faculty_department_data_fetch(session()->get('faculty_id'), session()->get('department_id'));
        // dd($cbt_data);
        // academic session data
        $academic_session = academic_session::all();
        $current_session = academic_session::where('academic_session_id', '=', $cbt_data->academic_session_id)->first();
        return view('staff.cbt_setting', compact('current_session','cbt_data', 'academic_session', 'course_fetch', 'faculty', 'department'));
    }
    public function cbt_question($cbt_id){

        // verifying from the cbt data if it exists
        $cbt_data_id = $this->cbt_course_question(session()->get('faculty_id'), session()->get('department_id'), session()->get('staff_id'), $cbt_id);
        // fetch the previous cbt questions
        $question = $this->cbt_question_mass_fetch($cbt_id);
        // fetching related data to the course from course table
        $course_data = $this->cbt_course_data($cbt_id);
        // fetching the number of staff attached to the course
        $cbt_assign_staff_no = $this->cbt_assigned_staff(session()->get('faculty_id'), session()->get('department_id'), $course_data->course_id);
        
        if(!$cbt_data_id){
            return redirect('/staff/cbt_data');
        }
        return view('staff.cbt_question', compact('cbt_data_id', 'question', 'course_data', 'cbt_assign_staff_no','cbt_id'));
    }

    public function question_option_request(request $request){

        // request validation
        $request->validate([
            'option' => 'required',
            'cbt_id' => 'required',
            'question_id' => 'required',
            'option_id_type'=> 'required',
            '_token' => 'required'
        ]);


    }

    private function cbt_question_option_create($faculty_id, $department_id, $cbt_staff_id, $cbt_data_id, $cbt_question_id, $cbt_option, $option_label_id, $option_status){

        $rand = rand(100, 100000000);
        // if not none
            $cbt_option_id = 'CBT_OPTION_ID'.time().$rand.session()->get('lsi');
        // option creating
      $create =  cbt_answer::create([
            'staff_id' => $cbt_staff_id,
            'options' => $cbt_option,
            'option_status' => $option_status,
            'cbt_question_id' => $cbt_question_id,
            'option_label_id' => $option_label_id,
            'cbt_option_id' => $cbt_option_id,
            'cbt_data_id' => $cbt_data_id,
            'faculty_id' => $faculty_id,
            'department_id' => $department_id
        ]);

        return $create;
    }

    public function edit_answer($cbt_id, $question_id, $answer_id){
// dd('hi');
        // cbt id verification 
        $cbt_id_verify = $this->cbt_data_id_verify($cbt_id);
        // cbt question fetch 
        $cbt_question = $this->cbt_question_single_fetch($cbt_id, $question_id);
        $cbt_mass_question = $this->cbt_question_mass_fetch($cbt_id);
        $answer = cbt_answer::where('cbt_question_id', '=', $question_id)->where('cbt_data_id', '=', $cbt_id)->where('cbt_option_id', '=', $answer_id)->first();
        if(!$answer){
            return redirect('/staff/cbt_data');
        }

        // cbt question

        if(!$cbt_id_verify){

            return redirect('/staff/cbt_data');
        }
        // dd($cbt_question);
        return view('staff.edit_answer', compact('cbt_question', 'cbt_mass_question', 'answer'));
    }

    public function cbt_answer($cbt_id, $question_id){

        // cbt id verification 
        $cbt_id_verify = $this->cbt_data_id_verify($cbt_id);
        // cbt question fetch 
        $cbt_question = $this->cbt_question_single_fetch($cbt_id, $question_id);
        $cbt_mass_question = $this->cbt_question_mass_fetch($cbt_id);

        // dd($cbt_question);
        // cbt question

        if(!$cbt_id_verify){

            return redirect('/staff/cbt_data');
        }
        // dd($cbt_question);
        return view('staff.cbt_answer', compact('cbt_question', 'cbt_mass_question'));
    }

    public function add_media(request $request){
    
        $request->validate([
            'question_image' => ['required', 'mimes:jpeg,jpg,png,', 'max:5000'],
            'image_title' => 'required',
            'cbt_question_id' => 'required'  
        ]);
        // dd("hi");
        $rand = rand(1, 10000000);
        $image_name = time().'-'.$rand.'-'.'.'.$request->question_image->extension();

        $request->question_image->move(public_path('question_images'), $image_name);


        $create = cbt_question_image::create([
            'image_name' => $image_name,
            'cbt_question_id' => $request->cbt_question_id,
            'image_title' => $request->image_title
        ]);
        // $request->dd();
        return back();
    }

    public function processing_update_question(request $request){

        $request->validate([
            'question' => 'required',
            'cbt_data_id' => 'required',
            'cbt_question_id' => 'required'
        ]);
        // update the question 

        $cbt_question = cbt_question::where('cbt_question_id', '=', $request->cbt_question_id)->update([

            'cbt_question' => $request->question
        ]); 

        if($cbt_question){

            return back();
        }

        return redirect('/staff/cbt_data');
    }
    public function question_answer_request(request $request){
        $request->validate([
            '_token' => 'required'
        ]);
        // deleting request
        if($request->delete_request){

            $delete = cbt_answer::where('cbt_option_id', '=', $request->cbt_option_id)->delete();

            if($delete){

                return back();
            }

            return redirect('/staff/cbt_data');
        }

        // correct answer request
        if($request->option_request){

            if($request->option_status === 'correct_option'){

                $option_status = 'option';
            }
            if($request->option_status === 'option'){

                $option_status = 'correct_option';
            }
            $option_status_update = cbt_answer::where('cbt_option_id', '=', $request->cbt_option_id)->update([
                'option_status' => $option_status
            ]);

            if($option_status_update){
                return back();
            }
            return redirect('/staff/cbt_data');
        }
        $request->validate([
            'option' => 'required',
            'cbt_id' => 'required',
            'question_id' => 'required',
            'option_status' => 'required',
            'option_label_id' => 'required'            
        ]);
        // cbt_question_option_create($faculty_id, $department_id, $cbt_staff_id, $cbt_data_id, $cbt_question_id, $cbt_option, $option_label_id, $option_status); 
        $option_create = $this->cbt_question_option_create(session()->get('faculty_id'), session()->get('department_id'), session()->get('staff_id'), $request->cbt_id, $request->question_id, $request->option, $request->option_label_id, $request->option_status);
        
        // option not created succeful
        if(!$option_create){
            return back()->with('message', 'option not added successfully');
        }

        // option created successfully
        return back()->with('message', 'option added successfully');

    }

    public function student_result(){

        $academic_session = academic_session::all();
        $course = assign_course::where('department_id', '=', session()->get('department_id'))->where('staff_id', '=', session()->get('staff_id'))->get();
        return view('staff.student_result', compact('academic_session', 'course'));
    }


}


