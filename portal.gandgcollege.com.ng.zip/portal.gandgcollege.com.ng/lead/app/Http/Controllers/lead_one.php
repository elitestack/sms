<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\pending_student;
use App\Models\student_passport;
use App\Models\academic_session;
use App\Models\academic_session_term;
use App\Models\subject;
use App\Models\student_class;
use App\Models\student_reg_base;
use App\Models\staff_data;


class lead_one extends Controller
{
    //

    public function dashboard(){

        return view('lead_one.dashboard');
    }
    public function create_subject(request $request){

        // create new class
        $request->validate([
            'subject_name' => 'required'
        ]);
        // 
        $class_create = subject::create([
            'subject' => $request->subject_name
        ]);

        if(!$class_create){

            return back()->with('message', 'unable to create new subject');
        }

        return back()->with('message', 'subject created successfully');
    }



    public function staff_create(request $request){

        $request->validate([
            'staff_role' => 'required',
            'staff_email' => 'required',
            'staff_name' => 'required'
        ]);

        // validates request
        $validate_email_exist = staff_data::where('staff_email', '=', $request->staff_email)->first();
        
        if($validate_email_exist){

            return back()->with('message', 'please this email has been used already');
        }

        // staff role verification 
        if($request->staff_role === 'lead_two'){
            $lead_two_role = staff_data::where('staff_role', '=', $request->staff_role)->first();
            $password = 'lead_two_12345678';
            if($lead_two_role){
                return back()->with('message', 'maximum one staff for lead two role');
            }

        }

        if($request->staff_role === 'lead_three'){
            $lead_three_role = staff_data::where('staff_role', '=', $request->staff_role)->first();
            $password = 'lead_three_12345678';
            if($lead_three_role){
                return back()->with('message', 'maximum one staff for lead three role');
            }

        }

    
    

        // create new staff
        $create = staff_data::create([
            'staff_role' => $request->staff_role,
            'staff_email' => $request->staff_email,
            'staff_name' => $request->staff_email,
            'password' => $password
        ]);

        if(!$create){

            return back()->with('message', 'unable to create new staff, please try again...');
        }
        
        return back()->with('message', 'new staff created successfully');
    }

    public function create_student_class(request $request){

        // create new class
        $request->validate([
            'class_name' => 'required'
        ]);

        // 
        $class_create = student_class::create([
            'class' => $request->class_name
        ]);

        if(!$class_create){

            return back()->with('message', 'unable to create new class');
        }

        return back()->with('message', 'class created successfully');
    }

    public function subject(){


        $subject = subject::get();

        return view('lead_one.subject', compact('subject'));
    }

    public function staff(){

        $staff = staff_data::get();
        return view('lead_one.staff', compact('staff'));
    }
    public function student_class(){

        $class = student_class::get();
        return view('lead_one.student_class', compact('class'));
    }
    public function students(){

        $student = student_reg_base::with('students')->get();

        return view('lead_one.student', compact('student'));
    }
    public function admission_verify(){
        $pending_admission = pending_student::where('application_status', '=', 'pending')->get();
        
        return view('lead_one.admission_verify', compact('pending_admission'));
    }

    public function post_admission_verify(request $request){
        $request->validate([
            "application_id" => "required"
        ]);
        // return redirect
        return redirect("/lead_one/pending_admission/".$request->application_id);
    }

    public function academic_session(){
        $academic_session = academic_session::get();

        return view("lead_one.academic_session", compact("academic_session"));
    }

    public function academic_session_status(request $request){
        $request->validate([
            "academic_session_id" => "required",
            "status" => "required"
        ]);

        if($request->status === "delete"){

            // delete and exit
            $academic_session_term_validate = academic_session_term::where('academic_session_id', '=', $request->academic_session_id)->get();

            if(count($academic_session_term_validate) > 0){
    
                // cannot delete academic session parent, because it has a terms child
    
                return back()->with("message", "academic session cannot be deleted, please delete the academic terms first");
            }
    
            // else delete the academci session 
            $delete_academic_session = academic_session::where("id", "=", $request->academic_session_id)->delete();
    
            if($delete_academic_session){
    
                return back()->with("message", "academic session deleted successfully");
            }
    
            return back()->with("message", "an error occur, academic session cannot be deleted");
    
            
        }
        

        $action = academic_session::where("id", "=", $request->academic_session_id)->update([
            "academic_session_status" => $request->status
        ]);

        if(!$action){

            return back()->with("message", "an error occur");
        }

        return back()->with("message", "academic status update successfully");
    }


    public function student_application_approve(request $request){
        $request->validate([
            'application_id' => 'required'
        ]);

        // fetch publish term and public academic session
        $academic_session = academic_session::where('academic_session_status', '=', 'published')->first();
        $term = academic_session_term::where('academic_session_id', '=', $academic_session->id)->first();
        // approved and generate student reg id

        $verify_pending_student = pending_student::where('application_id', '=', $request->application_id)->update([
            "surname" => $request->surname,
            "othernames" => $request->othernames,
            "sex"=> $request->sex,
            "address" => $request->address,
            "guardian" => $request->guardian,
            "guardian_address" => $request->guardian_address,
            "guardian_phone" => $request->guardian_phone,
            "application_id" => $request->application_id,
            "academic_session_id" => $academic_session->id,
            "term_id" => $term->id,
            'application_status' => 'activated'
        ]);


        if(!$verify_pending_student){
          
            return back()->with('message', 'invalid application id');
        
        }

        // generate matric number
        // $student_reg_config = student_reg_config::where('status', '=', 'published')->first();
        
        return redirect('/application/'.$request->application_id)->with('student application has been approved');
    }


    public function create_academic_session(request $request){
        $request->validate([
            "academic_session" => "required"
        ]);
        // create new academic session

        $action = academic_session::create([
            "academic_session" => $request->academic_session,
            "user_id" => "admin",
            "academic_session_status" => "pending"
        ]);

        if(!$action){

            return back()->with("message", "an error occur");
        }

        return back()->with("message", "academic session created successfully");
    }


    public function academic_session_id($academic_session_id){

        // validate the academic session id
        $fetch = academic_session::where("id", "=", $academic_session_id)->first();

        if(!$fetch){

            return "academic session does not exists, please try again";
        }

        // terms already created
        $terms = academic_session_term::get();

        return view("lead_one.academic_session_id", compact("fetch", "academic_session_id", "terms"));
    }

    public function term_status(request $request){

        $request->validate([
            "academic_session_id" => "required",
            "status" => "required",
            "term_id" => "required"
        ]);

        return "working in progress";
        if($request->status === "delete"){

            // delete and exit
            $academic_session_term_validate = academic_session_term::where('academic_session_id', '=', $request->academic_session_id)->get();

            if(count($academic_session_term_validate) > 0){
    
                // cannot delete academic session parent, because it has a terms child
    
                return back()->with("message", "academic session cannot be deleted, please delete the academic terms first");
            }
    
            // else delete the academci session 
            $delete_academic_session = academic_session::where("id", "=", $request->academic_session_id)->delete();
    
            if($delete_academic_session){
    
                return back()->with("message", "academic session deleted successfully");
            }
    
            return back()->with("message", "an error occur, academic session cannot be deleted");
    
            
        }
        $action = academic_session::where("id", "=", $request->academic_session_id)->update([
            "status" => $request->status
        ]);

        if(!$action){

            return back()->with("message", "an error occur");
        }

        return back()->with("message", "academic status update successfully");

    }
    public function create_academic_session_term(request $request){
        $request->validate([
            "academic_session_id" => "required",
            "term" => "required",
            "term_status" => "pending"
        ]);
        // validates academic session ids
        $academic_session_verify = academic_session::where("id", "=", $request->academic_session_id)->first();
        if(!$academic_session_verify){
            return back()->with("message", "an error occur, cannot create new term");
        }

        $create = academic_session_term::create([
            "academic_session_id" => $request->academic_session_id,
            "term" => $request->term,
            "term_status" => "pending"
        ]);

        if(!$create){

            return back()->with("message", "an error occur, cannot create academic term");
        }

        return back()->with("message", "academic term created successfully");
    }

   public function pending_admission($application_id){
        $application_data = pending_student::where("application_id", "=", $application_id)->first();
        $passport = student_passport::where('application_id', '=', $application_id)->first();
        
        
        // if application does not exist

        if(!$application_data){
            
            return "invalid admission application id, please confirm the admission application id";
        }

        if($application_data->application_status === "activated"){
            return redirect('/application/'.$application_id)->with('student application has been approved');

        }
        return view('lead_one.pending_student', compact('application_data', 'passport'));
    }
}
