<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\staff_data;


class user extends Controller
{
    //

    public function login(request $request){

        $request->validate([
            'email' => 'required',
            'password' => 'required'
        ]);

        // login
        $check = staff_data::where('staff_email', '=', $request->email)->where('password', '=', $request->password)->first();

        if(!$check){

            return back()->with('message', 'invalid credentials');
        }

        session()->put('staff_role', $check->staff_role);
        session()->put('staff_name', $check->staff_name);
        session()->put('staff_email', $check->staff_email);

        if($check->staff_role === 'lead_one'){

            session()->put('lead_one', $check->staff_email);

            return redirect('/lead_one/dashboard');
        }

        if($check->staff_role === 'lead_two'){
           
            session()->put('lead_two', $check->staff_email);
            return redirect('/lead_two/dashboard');
        }

        if($check->staff_role === 'lead_three'){
           
            session()->put('lead_three', $check->staff_email);
            return redirect('/lead_three/dashboard');
        }

        if($check->staff_role === 'lead_four'){
           
            session()->put('lead_four', $check->staff_email);
            return redirect('/lead_four/dashboard');
        }

        return back()->with('message', 'unable to login, please try again...');
        
    }

    public function logout(){

        session()->pull('lead_one');
        session()->pull('lead_two');
        session()->pull('lead_three');
        session()->pull('lead_four');

        return redirect('/login');
    }
}
