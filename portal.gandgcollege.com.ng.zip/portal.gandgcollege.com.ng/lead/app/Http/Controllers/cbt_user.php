<?php

namespace App\Http\Controllers;

use App\Models\staff_data;
use App\Models\department;
use App\Models\student_data;
use App\Models\assign_course;
use App\Models\password_reset;
use App\Models\reset_token;
use App\Models\faculty;
use Illuminate\Http\Request;
use Mail;


class cbt_user extends Controller
{
    //

    public function student_cbt_login(request $request){
        
        // $request->dd();
        $request->validate([
            'student_reg' => 'required',
            'student_name' => 'required',
            'student_class' => 'required',
            '_token' => 'required'
        ]);

        session()->put('student_reg', $request->student_reg);
        session()->put('student_name', $request->student_name);
        session()->put('student_class', $request->student_class);
        return redirect('/student_cbt_start');
    }
    

    public function student_start_process(request $request){
        $request->validate([
            'class_section' => 'required'
        ]);

        session()->put('class_section', $request->class_section);
        return redirect('/subject_select');

    }

    public function subject_select_process(request $request){

        // $request->dd();
        $request->validate([
            'class_subject' => 'required'
        ]);

        // session data 
        session()->put('class_subject', $request->class_subject);

        return redirect('/student_cbt/cbt_mode');
    }
   
    
    
    public function cbt_staff_login_processing(Request $request){

        $request->validate([
            'email' => 'required',
            'password' => 'required',
            '_token' => 'required'
        ]);

        // existing users and verify permitted for the exams and if not return back with message
               
        $cbt_user_email_check = staff_data::where('email', '=', $request->email)->first();
      
        if(!$cbt_user_email_check){
            return back()->with('message','email does not exists');
        }

                if($cbt_user_email_check->password !== $request->password){
          
                    return back()->with('message', 'invalid password, please reset your password to login');
        }

        $assign_course = assign_course::where('staff_id', '=', $request->email)->get();

        $assign_course_count = count($assign_course);

        
        
        if($cbt_user_email_check->incoming_request === 'deactivated'){

            return back()->with('message', 'please contact your unit for verification');
        }

        


        $role = $cbt_user_email_check->staff_role;

        if($role === 'cbt_admin_level'){

            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            return redirect('/admin/dashboard');
        }elseif($role === 'cbt_faculty_level'){

            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            session()->put('faculty_id', $cbt_user_email_check->faculty_id);
            return redirect('/class/dashboard');

        }elseif($role === 'cbt_department_level'){

            // dd($cbt_user_email_check->faculty_id);
            $cbt_faculty_department_fetch = faculty::where('faculty_id', '=', $cbt_user_email_check->faculty_id)->first();
            $department_id = department::where('faculty_id', '=', $cbt_faculty_department_fetch->faculty_id)->first();
            // dd($cbt_faculty_department_fetch);
            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            session()->put('ldi', $cbt_user_email_check->id);
            session()->put('faculty_id', $cbt_faculty_department_fetch->faculty_id);
            session()->put('department_id', $department_id->department_id);
            return redirect('/section/dashboard');

        }elseif($role === 'cbt_staff_level'){

            $cbt_faculty_department_fetch = faculty::where('faculty_id', '=', $cbt_user_email_check->faculty_id)->first();
            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            session()->put('staff_id', $cbt_user_email_check->email);
            session()->put('lsi', $cbt_user_email_check->id);
            session()->put('faculty_id', $cbt_faculty_department_fetch->faculty_id);
            session()->put('department_id', $cbt_user_email_check->department_id);
            if($assign_course_count === 0){
                return back()->with('message', 'contact your unit to assign a course to your account');
            }
    
            return redirect('/staff/dashboard');
        }else{

            return redirect('/login');
        }
    
    }

    public function logout(){

            session()->pull('cbt_course_id');
            session()->pull('cbt_type');
            session()->pull('cbt_data_id');
            session()->pull('cbt_set_id');
            session()->pull('academic_session_id');
            session()->pull('role');
            session()->pull('ldi');
            session()->pull('lsi');
            session()->pull('login_id');
            session()->pull('staff_id');
            session()->pull('faculty_id');
            session()->pull('faculty_name');
            session()->pull('department_id');
            return redirect('/login');
    }

    
    
}
