<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\faculty;
use App\Models\department;
use App\Models\cbt_code;
use App\Models\session_id;
use App\Models\assign_course;
use App\Models\cbt_course;
use App\Models\staff_data as staff;

class code_validate extends Controller
{
    //

    private function cbt_department_level($reg_code){

        $department = department::where('department_reg_code', '=', $reg_code)->first();

        return $department;
    }

    private function cbt_faculty_level($reg_code){

        $faculty = faculty::where('faculty_id', '=', $reg_code)->first();

        return $faculty;
    }


    public function code_validation(request $request){

        // request validation 

        $request->validate([
            'reg_code' => 'required',
            'email' => 'required',
            'password' => 'required',
            'confirm_password' => 'required',
            '_token' => 'required'
        ]);

        
        $email_check = staff::where('email', '=', $request->email)->first();


        if($email_check){
            return back()->with('message', 'Account Already Exists, Please Reset your password with the below link to access your account');
        }

        if($request->password !== $request->confirm_password){
            return back()->with('message', 'the password and confirm password does not match');
        }
        // reg code validation and also make sure the reg code was not used before
        $validate_department = $this->cbt_department_level($request->reg_code);
        $validate_faculty_check = faculty::where('faculty_id', '=', $request->reg_code)->where('faculty_status', '=', 'pending')->first();
        // dd($validate_faculty_check);

        // staff registration verification

        $staff_course_verify = cbt_course::where('course_id', '=', $request->reg_code)->first();

        // faculty check
        if($validate_faculty_check){    
                        // checking if the registration code has not been used before
                        $faculty_used_by_you = staff::where('email', '=', $request->email)->where('faculty_id', '=', $request->reg_code)->first();
                        if($faculty_used_by_you){
                            return back()->with('message', 'faculty registration already used by you, reset  your password to login');            }
                
        // checking if the registration code has not been used before
        $faculty_check = staff::where('faculty_id', '=', $request->reg_code)->first();
        if($faculty_check){
            return back()->with('message', 'faculty registration code already used');            }

            $create = staff::create([
                    'name' => 'cbt_faculty_level',
                    'staff_id' => 'cbt_faculty_level',
                    'staff_role' => 'cbt_faculty_level',
                    'email' => $request->email,
                    'department' => 'cbt_faculty_level',
                    'faculty_id' => $request->reg_code,
                    'staff_status' => 'deactivated',
                    'incoming_request' => 'deactivated',
                    'department_id' => 'cbt_faculty_level',
                    'password' => $request->password
                    ]);
                    
                    if($create){
        // manage registration sessions
        // $session_id = $this->cbt_session_create($request->reg_code, $request->email, $type);
        // $verify_session = $this->cbt_session_id_check($session_id, $request->reg_code, $request->email, $type);
                        // return redirect('/staff_registration_password/validate_id='.$verify_session->reg_code.'&session_id='.$verify_session->session_id.'&staff_id='.$request->email);
                        return redirect('/login')->with(['message' => 'account created successfully, pending your unit verification', 'mail' => $request->email, 'password' => $request->password]);            
    
                    }
    
        }
        
        // department check
            if($validate_department){

                        // checking if the registration code has not been used before
        $department_used_by_you = staff::where('email', '=', $request->email)->where('department_id', '=', $request->reg_code)->first();
        if($department_used_by_you){
            return back()->with('message', 'department registration already used by you, reset  your password to login');            }

                // checking if the registration code has not been used before
        $department_check = staff::where('department_id', '=', $request->reg_code)->first();
        if($department_check){
            return back()->with('message', 'department registration already used');            }

                $create = staff::create([
                    'name' => 'cbt_department_level',
                    'staff_id' => 'cbt_department_level',
                    'staff_role' => 'cbt_department_level',
                    'incoming_request' => 'deactivated',
                    'staff_status' => 'deactivated',
                    'email' => $request->email,
                    'department' => $request->reg_code,
                    'faculty_id' => $validate_department->faculty_id,
                    'department_id' => 'cbt_department_level',
                    'password' => $request->password
                    ]);
                    if($create){
                                // manage registration sessions
        // $session_id = $this->cbt_session_create($request->reg_code, $request->email, $type);
        // $verify_session = $this->cbt_session_id_check($session_id, $request->reg_code, $request->email, $type);
        // return redirect('/staff_registration_password/validate_id='.$verify_session->reg_code.'&session_id='.$verify_session->session_id.'&staff_id='.$request->email);

        return redirect('/login')->with(['message' => 'account created successfully, pending your unit verification', 'mail' => $request->email, 'password' => $request->password]);            
    }
            }

        
        // staff check        
           $course_code_check = cbt_course::where('course_id', '=', $request->reg_code)->first();
            if($course_code_check){
                // create new staff records
                 staff::create([
                    'name' => 'cbt_staff_level',
                    'staff_id' => 'cbt_staff_level',
                    'staff_role' => 'cbt_staff_level',
                    'staff_status' => 'deactivated',
                    'incoming_request' => 'deactivated',
                    'email' => $request->email,
                    'department' => $staff_course_verify->department_id,
                    'faculty_id' => $staff_course_verify->faculty_id,
                    'department_id' => $staff_course_verify->department_id,
                    'password' => $request->password
            ]);

            // assigning to a course verification level
                    $assign_course_check = assign_course::where('staff_id', '=', $request->email)->where('course_id', '=', $request->reg_code)->first();
            // assigning course to staffs, and if the staff has not been assigned to the course, if the staff has assigned to the course, skip  the assign course level
             if($assign_course_check){

                return back()->with('message', 'This course has been assigned to your account already, login to your account');
             }
                if(!$assign_course_check){
                    $assign_course = assign_course::create([
                        'course_id' => $request->reg_code,
                        'staff_id' => $request->email,
                        'status' => 'deactivated',
                        'faculty_id' => $staff_course_verify->faculty_id,
                        'department_id' => $staff_course_verify->department_id
                    ]);
        // return redirect to password page, if the staff is a new staff, and if the staff was an existing staff before skip the password page
        // staff create 
                                // manage registration sessions
            //                     $session_id = $this->cbt_session_create($request->reg_code, $request->email, $type);
            //                     $verify_session = $this->cbt_session_id_check($session_id, $request->reg_code, $request->email, $type);
                        
            // return redirect('/staff_registration_password/validate_id='.$verify_session->reg_code.'&session_id='.$verify_session->session_id.'&staff_id='.$request->email);
            return redirect('/login')->with(['message' => 'account created successfully, pending your unit verification', 'mail' => $request->email, 'password' => $request->password]);            
        }elseif($assign_course_check){
                        return back()->with('message', 'The course has been assigned to your account already, contact your unit for help');                       
                    }

    }


                    // after all checks and none successfully 
                    return back()->with('message','Invalid regisration code, please contact your unit for help');
    }

    protected function cbt_session_id_check($session_id, $reg_code, $email, $type){
        $session_check = session_id::where('session_id', '=', $session_id)->where('reg_code', '=', $reg_code)->where('staff_id', '=', $email)->where('type', '=', $type)->first();
        return $session_check;
    }

    // protected function cbt_session_create($reg_code, $email, $type){

    //     $session_id = 'aequiee'.time().'yqteo38949s'.time();

    //     // checking if session exists 
    //     $session_check = session_id::where('session_id', '=', $session_id)->where('reg_code', '=', $reg_code)->first();

    //     if(!$session_check){
    //     $session_create = session_id::create([
    //         'reg_code' => $reg_code,
    //         'session_id' => $session_id,
    //         'staff_id' => $email,
    //         'type' => $type,
    //         'status' => 'unused'
    //     ]);
        
    //     $data = $session_id;
    //     return $data;
    // }
                
    // }

    // public function password_set_verify(request $request){

    //     $request->validate([
    //         'password' => 'required',
    //         'confirm_password' => 'required',
    //         'email' => 'required',
    //         'reg_code' => 'required',
    //         'session_id' => 'required',
    //         '_token' => 'required'
    //     ]);

    //     // dd('hi');
    //     if($request->password !== $request->confirm_password){

    //         return back()->with('message','password does not match');
    //     }


    //     // staff email verification
    //     $email_verification = staff::where('email', '=', $request->email)->first();

    //     if(!$email_verification){
    //         return redirect('/sign-up')->with('message', 'invalid registration credentials');
    //     }
    //         // session verification 
    //         $session = $this->session_verify_status($request->session_id, $request->reg_code);
    //         if($session){
        
    //             $staff_create = staff::where('email', '=', $request->email)->update([
    //             'password' => $request->password
    //         ]);
    //         // session id update 
    //         return redirect('/login')->with(['message' => 'account created successfully, pending your unit verification', 'mail' => $request->email, 'password' => $request->password]);            
    //     }
        
    //     return redirect('/sign-up')->with('message', 'invalid registration credentials');
    // }

    protected function session_verify_status($validate_id, $session_id, $email, $type){

        // dd($validate_id);
        $check = $this->cbt_session_id_check($session_id, $validate_id, $email, $type);
        // $check = session_verify_status($session_id, $validate_id);

        if($check){
        session_id::where('session_id', '=',$validate_id)->where('reg_code', '=', $session_id)->where('staff_id', '=', $email)->where('type', '=', $type)->update([
            'status' => 'used'
        ]);
        dd("hello world");
            }
    }
    public function password_set($validate_id, $session_id, $staff_id){ 

                $session_id_verify = $this->cbt_session_id_check($session_id,$validate_id, $staff_id, $type);


                if(!$session_id_verify){
            return redirect('/sign_up')->with('message','invalid registration session; please contact your unit for help');
        }

        return view('sign_up_verification', compact('validate_id', 'session_id', 'staff_id'));
        
}

}
