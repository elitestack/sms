<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\department;
use App\Models\staff_data;

class faculty_controller extends Controller
{
    //

    
    public function dashboard(){

        $department = department::where('faculty_id', '=', session()->get('faculty_id'))->get();
    
        return view('faculty.dashboard', compact('department'));
    }

    public function add_department(request $request){

        $request->validate([
            'department_name' => 'required',
            '_token' => 'required'
        ]);

        // checks for the department name exists already 
        $rand = rand(15000, 10000000000);
        $time = 'DA'.time().$rand;
        $faculty_check = department::where('department_name', '=', $request->department_name)->first();

        if($faculty_check){

            return back()->with('message', 'department already exists');
        }

        $faculty_create = department::create([
            'department_name' => $request->department_name,
            'department_id' => $time,
            'department_status' => 'pending',
            'department_reg_code' => $time,
            'faculty_id' => session()->get('faculty_id')
            ]);


            return back()->with('message', 'department added successfully');

    }

    public function incoming_request(){
        
        $total_department = staff_data::where('staff_role','=','cbt_department_level')->where('faculty_id', '=', session()->get('faculty_id'))->get();
        $activated_department = staff_data::where('staff_role','=','cbt_department_level')->where('incoming_request', '=', 'activated')->where('faculty_id', '=', session()->get('faculty_id'))->get();

        return view('faculty.incoming_department', compact('total_department', 'activated_department'));
    }
    public function department_id($department_id){

        return view('faculty.department_data');
    }

    public function department_incoming_request(request $request){

        $request->validate([
            'status',
            'email',
            '_token' => 'required'
        ]);

        // searching the record and updating it 
        $check = staff_data::where('email', '=', $request->email)->where('faculty_id', '=', session()->get('faculty_id'))->first();
  

        if(!$check){

            return back();
        }

        $update = staff_data::where('email', '=', $request->email)->where('faculty_id', '=', session()->get('faculty_id'))->update([
            'incoming_request' => $request->status
        ]);

        return back();
    }
    public function department(){

        $department = department::where('faculty_id', '=', session()->get('faculty_id'))->get();
        return view('faculty.department', compact('department'));
    }



}
