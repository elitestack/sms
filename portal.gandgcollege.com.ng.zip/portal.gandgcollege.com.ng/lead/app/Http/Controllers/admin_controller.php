<?php

namespace App\Http\Controllers;
use App\Models\cbt_data;
use App\Models\faculty;
use App\Models\department;
use App\Models\student_data;
use App\Models\staff_data;
use App\Models\student_register_courses;
use App\Models\academic_session;
use App\Models\current_open_cbt;
use App\Models\cbt_course;
use Illuminate\Http\Request;
use App\Http\Controllers\code_validate;



class admin_controller extends Controller
{
    //

    // ajax controll

    public function cbt_exam_ctrl_fetch(){
        
        $data = current_open_cbt::all();
       

        return view('ajax_component.academic_session_data', compact('data'));
    }

    public function ajax_academic_session(){

        $academic_session = academic_session::orderBy('id', 'DESC')->get();
// dd($academic_session);
        return view('ajax_component.academic_session', compact('academic_session'));
    }
    // ajax controller end
    public function academic_session_create(request $request){

        $request->validate([
            'academic_session' => 'required',
            '_token' => 'required'
        ]);
     
        // dd($id);
        $rand = rand(177, 10000000);
        $academic_session_id = 'ASI_'.time().$rand;


        // $create = academic_session::create([
        //     'academic_session' => $request->academic_session,
        //     'academic_session_id' => $academic_session_id,
        //     'session_status' => 'deactivated'
        // ]);

        $create = academic_session::create([
            'academic_session' => $request->input('academic_session'),
            'academic_session_id' => $academic_session_id,
            'session_status' => 'deactivated'
        ]);

        
        // return Response::json($todo);
            return response('created sucessfully');
    
        // return back()->with('message', 'academic session created sucessfully');
        
    }
    public function index(){
        $pending_cbt_data = $this->pending_cbt_data();
        $active_cbt_data = $this->active_cbt_data();
        $successful_cbt_data = $this->successful_cbt_data();
        $department = department::count();
        $faculty = $this->faculty_data();
        return view('admin.dashboard', compact('pending_cbt_data', 'department','faculty','active_cbt_data', 'successful_cbt_data'));
    }

    private function pending_faculty(){

        $faculty_data = faculty::where('faculty_status', '=', 'pending')->orderBy('id', 'DESC')->get();

        return $faculty_data;
    }

    private function active_faculty(){

        $faculty_data = faculty::where('faculty_status', '=', 'active')->orderBy('id', 'DESC')->get();
        return $faculty_data;
        
    }

    private function faculty_data(){

        $faculty_data = faculty::orderBy('id', 'DESC')->get();

        return $faculty_data;
    }

    public function student_generate(){


$old_cbt_answer = quiz_answer::where('quiz_id', '=', 'gst2023-06-09 00:59:01')->get();

$count = count($old_cbt_answer);

for($i=0; $count > $i; $i++){
// dd("hi");
        $answer_db_count = cbt_answer::where('cbt_data_id', '=', 'CBT_ID1695888250')->count();
        $option_id = 'CBT_OPTION_ID'.time() - 10000 + $answer_db_count;
            // currect option check
                        
            $cbt_data_check = cbt_data_migration::where('quiz_id', '=', 'gst2023-06-09 00:59:01')->where('question_id', '=', $old_cbt_answer[$i]->question_id)->first();
            
            // comparing the questions
            $cbt_data_new = cbt_question::where('cbt_question', '=', $cbt_data_check->question)->first();
dd("hi");

            // comparing the old quiz answer with the answers db
            if($old_cbt_answer[$i]->option_id === $cbt_data_check->correct_option_id){

                // dd($cbt_data_new);
                $option_status = 'correct_option';
            }
            if($old_cbt_answer[$i]->option_id !== $cbt_data_check->correct_option_id){

                $option_status = 'option';
            }

            
            $cbt_question_create = cbt_answer::create([
            
                'staff_id' => 'gst112staff@cbt.com',
                'options' => $old_cbt_answer[$i]->option,
                'option_status' => $option_status,
                'cbt_question_id' => $cbt_data_new->cbt_question_id,
                'option_label_id' =>$old_cbt_answer[$i]->option_id,
                'cbt_option_id' => $option_id,
                'cbt_data_id' => 'CBT_ID1695888250',
                'faculty_id' => 'FA1692879632',
                'department_id' => 'DA1692880598'
            ]);

        }


    }
    private function faculty_data_fetch($id){

        $faculty_data = faculty::where('faculty_id', '=', $id)->first();

        return $faculty_data;
    }
    private function pending_cbt_data(){

        $pending_cbt_data = cbt_data::where('cbt_status', '=', 'pending')->orderBy('id', 'DESC')->get();

        return $pending_cbt_data;
    }

    private function active_cbt_data(){

        $active_cbt_data = cbt_data::where('cbt_status', '=', 'active')->orderBy('id', 'DESC')->get();

        return $active_cbt_data;
    }

    private function successful_cbt_data(){

        $succesful_cbt_data = cbt_data::where('cbt_status', '=', 'active')->orderBy('id', 'DESC')->get();

        return $succesful_cbt_data;
    }



    public function add_faculty_request(request $request){

        $request->validate([
            'faculty_name' => 'required',
            '_token' => 'required'
            ]);


                // generating id
                $rand = rand(1000, 1000000000);
                $id = 'FA'.time().$rand;

                $faculty_create = faculty::create([
                'faculty_name' => $request->faculty_name,
                'faculty_id' => $id,
                'faculty_status' => 'pending',
                'reg_code' => 'pending'
                ]);

                if($faculty_create){
                    return response('faculty added successfully');
                }
                if(!$faculty_create){
                    return response('faculty not added successfully');
                }
    }

    public function ajax_faculty_fetch(){
        $faculty_data = faculty::orderBy('id', 'DESC')->get();

        return view('ajax_component.faculty_fetch', compact('faculty_data'));

    }
    public function faculty_delete(request $request){
        $request->validate([
            'faculty_id' => 'required'
        ]);
        // check if faulty id not used by staff
        $check = staff_data::where('faculty_id', '=', $request->faculty_id)->first();
        if($check){
            return back()->with('message','Faculty already in used, cannot be deleted');

        }
        if(!$check){
            $delete = faculty::where('faculty_id', '=', $request->faculty_id)->delete();    
            return back()->with('message','faculty deleted sucessfully');
        }
    }

    public function faculty(){

        $active_faculty = $this->active_faculty();
        $activated_faculty = $this->active_faculty();
        $pending_faculty = $this->pending_faculty();
        $faculty_data = $this->faculty_data();

        return view('admin.faculty', compact('active_faculty', 'pending_faculty', 'faculty_data', 'activated_faculty'));
    }

    public function academic_session_manage(request $request){

        $request->validate([
            '_token' => 'required'
        ]);
        if($request->delete){

            // check if has not been used
            $delet_check = cbt_data::where('academic_session_id', '=', $request->academic_session_id)->first();
            if($delet_check){
                return back()->with('message','academic session already in use');                
            }
            $delete = academic_session::where('academic_session_id', '=', $request->academic_session_id)->delete();
            
            return back()->with('message','academic session deleted successfully');
        }elseif($request->manage){
            if($request->academic_session_id === "select academic session"){
                return response("please select academic session to activate");
            }
            academic_session::where('session_status', '=', 'activated')->update([
                'session_status' => 'deactivated'
            ]);
            $activated = academic_session::where('academic_session_id', '=', $request->academic_session_id)->update([
                'session_status' => 'activated'
            ]);

            return response('academic session activated successfully');
            }
            return response("please try again");
        }
    
    public function academic_session(){

        $academic_session = academic_session::orderBy('id', 'DESC')->get();
        return view('admin.academic_session', compact('academic_session'));
    }

    public function cbt_data_academic_request(request $request){

        $request->validate([
            'academic_session' => 'required',
            'cbt_status' => 'required',
            'cbt_type' => 'required'
        ]);


        // deactivate all
        current_open_cbt::where('status', '=', 'open')->update([
            'status' => 'close'
        ]);
        // check if the session was cretaed before, update it and if not create new one
        $check = current_open_cbt::where('academic_session', '=', $request->academic_session)->first();
    if(!$check){
        $create = current_open_cbt::create([
            'academic_session' => $request->academic_session,
            'status' => $request->cbt_status,
            'cbt_type' => $request->cbt_type
        ]);

        return response($request->cbt_type.' open success');
        
    }else{
        $update = current_open_cbt::where('academic_session', '=', $request->academic_session)->where('cbt_type', '=', $request->cbt_type)->update([
            'academic_session' => $request->academic_session,
            'status' => $request->cbt_status,
            'cbt_type' => $request->cbt_type
        ]);
        return response($request->cbt_type.' updated successfully');

    }

    }

    public function faculty_incoming_request(request $request){

        $request->validate([
            'status' => 'required',
            'email' => 'required',
            '_token' => 'required',
        ]);

        // searching the record and updating it 
        $check = staff_data::where('email', '=', $request->email)->first();
  
        if(!$check){

            return back();
        }

        $update = staff_data::where('email', '=', $request->email)->update([
            'incoming_request' => $request->status
        ]);

        return back();
    }
    public function incoming_request(){

        $pending_faculty = staff_data::where('staff_role','=','cbt_faculty_level')->get();
        $faculty = staff_data::where('staff_role','=','cbt_faculty_level')->where('incoming_request', '=', 'activated')->get();

        return view('admin.incoming_faculty', compact('pending_faculty', 'faculty'));
    }

    function student_course_reg_data($course_id, $academic_session_id){

        // checking for the session id
     $course = cbt_course::where('course_id', '=', $course_id)->first();
     if(!$course){
        return redirect('/admin/cbt_data');
     }
     $academic_session = academic_session::where('academic_session_id', '=', $academic_session_id)->first();

     if(!$academic_session){
        return redirect('/admin/cbt_data');
     }
        $student_data = student_register_courses::where('cbt_course_id', '=', $course_id)->where('academic_session_id', '=', $academic_session_id)->get();

        if(!$student_data){

            return redirect('/admin/cbt_data');
        }
        return view('admin.student_course_data', compact('student_data', 'course', 'academic_session'));
    }
    public function register_course_data(request $request){

        $request->validate([
            'academic_session_id',
            'course_code',
            '_token' => 'required',
        ]);

        return redirect('/admin/student_course_reg_data/course_id='.$request->course_code.'&academic_session_id='.$request->academic_session_id);
    }
    public function cbt_code_search(){

        // fetch all academic sessions
        $academic_session = academic_session::orderBy('id', 'DESC')->get();
        $faculty = faculty::orderBy('id', 'DESC')->get();
        $cbt_course = cbt_course::orderBy('id', 'DESC')->get();
        $current_cbts =current_open_cbt::orderBy('id', 'DESC')->get();
        // dd($cbt_current_type);
        return view('admin.cbt_code_search', compact('academic_session', 'cbt_course','faculty', 'current_cbts'));
    }


    protected function department_data($id){

        $data = department::where('faculty_id', '=', $id)->orderBy('id', 'DESC')->get();
        
        return $data;
    }


    public function faculty_id($faculty_id){
        // faculty check
        $faculty_check = faculty::where('faculty_id', '=', $faculty_id)->first();

        if(!$faculty_check){

            return redirect('/admin/class');
        }
        // fetching data
        $department_data = $this->department_data($faculty_id);
        $faculty_data = $this->faculty_data_fetch($faculty_id);
        return view('admin.faculty_data', compact('department_data', 'faculty_data'));
    }

}
