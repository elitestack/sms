<?php

namespace App\Mail;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;

class passowrd_reset extends Mailable
{
    use Queueable, SerializesModels;

    /**
     * Create a new message instance.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Get the message envelope.
     *
     * @return \Illuminate\Mail\Mailables\Envelope
     */
    public function envelope()
    {
        return new Envelope(

            from: new address('nsukcbttest@gmail.com', 'Account password reset from cbt.nsuk.edu.ng'),
            subject: 'Account Passoword Reset',
        );
    }

    /**
     * Get the message content definition.
     *
     * @return \Illuminate\Mail\Mailables\Content
     */

     public function content()
    {
        return new Content(
            view: 'mail_template_1',
            with: ['data'],
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array
     */
    public function attachments()
    {
        return [];
    }

    public function student_cbt_login(request $request){
        
        $request->validate([
            'student_reg' => 'required',
            '_token' => 'required'
        ]);
        // ckecking if the student reg exits
        $student_reg_check = student_data::where('student_reg', '=', $request->student_reg)->first();
        if(!$student_reg_check){
            return back()->with('message', 'invalid student reg');
        }

        session()->put('student_reg', $student_reg_check->student_reg);
        session()->put('student_name', $student_reg_check->name);
        session()->put('faculty_id', $student_reg_check->faculty_id);
        session()->put('department_id', $student_reg_check->department_id);

        return redirect('/student_cbt/welcome');
    }

    public function password_reset_request(request $request){

        $request->validate([
            'email' => 'required',
            '_token' => 'required'
        ]);

        // check if the email exists in the databse
        $staff_data_confirm = staff_data::where('email', '=', $request->email)->first();

        if(!$staff_data_confirm){
            return back()->with('message', 'account not found');
        }
        // $now = date() + 86400;
        // dd($now);
        $rand = rand(5, 10000000);
             
        $token = 'aeeeoiee'.time().'yqteo'.$rand.'38949s'.time(); 
        // creating token 
        $token_create = password_reset::create([
            'email' => $request->email,
            'token' => $token
        ]);

        
        // expiring date
        $personal_access_token = reset_token::create([
            'tokenable_type' => 'account_reset',
            'tokenable_id'=> $token,
            'token' => $token,
            'abilities' => 'account_reset',
            'status' => 'unused'
        ]);

        return view('mail.template_1');
        // send mail and return redirect back
        return back()->with('message', 'check your mail for password reset, from cbt.nsuk.edu.ng');
    }
    public function cbt_staff_login_processing(Request $request){

        $request->validate([
            'email' => 'required',
            'password' => 'required',
            '_token' => 'required'
        ]);

        // existing users and verify permitted for the exams and if not return back with message
               
        $cbt_user_email_check = staff_data::where('email', '=', $request->email)->first();
      
        if(!$cbt_user_email_check){
            return back()->with('message','email does not exists');
        }

                if($cbt_user_email_check->password !== $request->password){
          
                    return back()->with('message', 'invalid password, please reset your password to login');
        }

        $assign_course = assign_course::where('staff_id', '=', $request->email)->get();

        $assign_course_count = count($assign_course);

        
        
        if($cbt_user_email_check->incoming_request === 'deactivated'){

            return back()->with('message', 'please contact your unit for verification');
        }

        


        $role = $cbt_user_email_check->staff_role;

        if($role === 'cbt_admin_level'){

            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            return redirect('/admin/dashboard');
        }elseif($role === 'cbt_faculty_level'){

            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            session()->put('faculty_id', $cbt_user_email_check->faculty_id);
            return redirect('/faculty/dashboard');

        }elseif($role === 'cbt_department_level'){

            // dd($cbt_user_email_check->faculty_id);
            $cbt_faculty_department_fetch = faculty::where('faculty_id', '=', $cbt_user_email_check->faculty_id)->first();
            $department_id = department::where('faculty_id', '=', $cbt_faculty_department_fetch->faculty_id)->first();
            // dd($cbt_faculty_department_fetch);
            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            session()->put('ldi', $cbt_user_email_check->id);
            session()->put('faculty_id', $cbt_faculty_department_fetch->faculty_id);
            session()->put('department_id', $department_id->department_id);
            return redirect('/department/dashboard');

        }elseif($role === 'cbt_staff_level'){

            $cbt_faculty_department_fetch = faculty::where('faculty_id', '=', $cbt_user_email_check->faculty_id)->first();
            session()->put('role', $cbt_user_email_check->staff_role);
            session()->put('login_id', $cbt_user_email_check->staff_id);
            session()->put('staff_id', $cbt_user_email_check->email);
            session()->put('lsi', $cbt_user_email_check->id);
            session()->put('faculty_id', $cbt_faculty_department_fetch->faculty_id);
            session()->put('department_id', $cbt_user_email_check->department_id);
            if($assign_course_count === 0){
                return back()->with('message', 'contact your unit to assign a course to your account');
            }
    
            return redirect('/staff/dashboard');
        }else{

            return redirect('/login');
        }
    
    }

    public function logout(){

            session()->pull('cbt_course_id');
            session()->pull('cbt_type');
            session()->pull('cbt_data_id');
            session()->pull('cbt_set_id');
            session()->pull('academic_session_id');
            session()->pull('role');
            session()->pull('ldi');
            session()->pull('lsi');
            session()->pull('login_id');
            session()->pull('staff_id');
            session()->pull('faculty_id');
            session()->pull('faculty_name');
            session()->pull('department_id');
            return redirect('/login');
    }

}
