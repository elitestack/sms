<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_question extends Model
{
    use HasFactory;

    protected $table = 'cbt_questions';
    protected $id = 'id';
    protected $fillable = [
        'cbt_question_id',
        'cbt_question',
        'question_no',
        'cbt_data_id',
        'cbt_staff_id',
        'faculty_id',
        'department_id'
    ];

    
}
