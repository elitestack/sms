<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_course extends Model
{
    use HasFactory;

    protected $table = 'cbt_courses';
    protected $id = 'id';
    protected $fillable = [
        'course_name',
        'course_code',
        'course_id',
        'faculty_id',
        'access_level',
        'department_id',
        'staff_taken_id',
        'staff_created'
    ];
}
