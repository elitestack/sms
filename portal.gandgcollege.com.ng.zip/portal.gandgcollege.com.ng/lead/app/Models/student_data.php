<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_data extends Model
{
    use HasFactory;

    protected $table = 'student_datas';
    protected $id = 'id';
    protected $fillable = [
        'student_reg',
        'name',
        'level',
        'cbt_user_ref_id',
        'faculty_id',
        'department_id'
    ];
}
