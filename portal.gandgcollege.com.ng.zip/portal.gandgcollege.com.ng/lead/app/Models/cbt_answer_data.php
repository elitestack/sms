<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_answer_data extends Model
{
    use HasFactory;

    protected $table = 'cbt_answer_datas';
    protected $id = 'id';
    protected $fillable = [
        'student_reg',
        'cbt_data_id',
        'cbt_set_id',
        'cbt_option_id',
        'cbt_question_id',
        'academic_session_id',
        'faculty_id',
        'department_id',
        'cbt_type'
        ];
}
