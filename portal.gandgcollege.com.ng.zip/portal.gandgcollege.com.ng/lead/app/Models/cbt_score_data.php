<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_score_data extends Model
{
    use HasFactory;

    protected $table = 'cbt_score_datas';
    protected $id = 'id';
    protected $fillable = [
        'student_reg',
        'academic_session_id',
        'cbt_course_id',
        'cbt_type',
        'cbt_score',
    ];
}
