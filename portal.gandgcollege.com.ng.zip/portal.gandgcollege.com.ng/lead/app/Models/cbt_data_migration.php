<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_data_migration extends Model
{
    use HasFactory;

    protected $table = 'quiz_questions';
    protected $id = 'id';
}
