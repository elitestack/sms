<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class academic_session extends Model
{
    use HasFactory;

    protected $table = 'academic_sessions';
    protected $id = 'id';

    protected $fillable =[
        'academic_session',
        'academic_session_id',
        'academic_session_status',
        "user_id"
    ];
}
