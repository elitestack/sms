<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_question_image extends Model
{
    use HasFactory;

    protected $table = 'cbt_question_images';
    protected $id = 'id';
    protected $fillable = [
        'image_name',
        'image_title',
        'cbt_question_id'
    ];

    public function student_question_images(){
        return $this->HasMany(student_question::class, 'cbt_question_id', 'cbt_question_id');
    }

    public function staff_question_images(){
        return $this->HasMany(student_question::class, 'cbt_question_id', 'cbt_question_id');
    }

}
