<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_answer extends Model
{
    use HasFactory;

    protected $table = 'cbt_answers';
    protected $id = 'id';
    protected $fillable = [
       
        'staff_id',
        'options',
        'option_status',
        'cbt_question_id',
        'option_label_id',
        'cbt_option_id',
        'cbt_data_id',
        'faculty_id',
        'department_id'
    ];
}
