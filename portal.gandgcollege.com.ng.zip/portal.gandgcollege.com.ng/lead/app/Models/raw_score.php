<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class raw_score extends Model
{
    use HasFactory;

    protected $table = 'raw_scores';
    protected $id = 'id';

    protected $fillable = [
        'student_reg',
        'course_id',
        'academic_session_id',
        'cbt_question_id',
        'score',
        'cbt_type'
    ];
}
