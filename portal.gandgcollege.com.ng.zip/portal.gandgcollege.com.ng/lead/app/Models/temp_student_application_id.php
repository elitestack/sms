<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class temp_student_application_id extends Model
{
    use HasFactory;

    protected $id = "id";
    protected $table = "temp_student_application_ids";
    protected $fillable = [
        "temp_id"
    ];
}
