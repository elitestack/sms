<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_code_approval extends Model
{
    use HasFactory;

    protected $table = 'cbt_code_approvals';
    protected $id = 'id';
    protected $fillable = [
        'staff_approve_id',
        'cbt_code_id',
        'status',
        'faculty_id',
        'department_id'
    ];
}
