<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class assign_staff_subject extends Model
{
    use HasFactory;
    protected $table = "assign_staff_subjects";
    protected $id = "id";
    protected $fillable = [
        "subject_id",
        "class_id",
        "staff_id"
    ];


    public function subject(){

        return $this->hasOne(subject::class, 'id', 'subject_id');
    }

    public function class(){

        return $this->hasOne(student_class::class, 'id', 'class_id');
    }
}
