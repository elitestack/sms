<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_score_setting extends Model
{
    use HasFactory;
    protected $table = 'cbt_score_settings';
    protected $id = 'id';

    protected $fillable = [
        'academic_session_id',
        'cbt_course_id',
        'cbt_score',
        'cbt_type'
    ];
}
