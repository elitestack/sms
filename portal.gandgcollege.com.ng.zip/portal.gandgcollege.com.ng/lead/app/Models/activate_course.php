<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class activate_course extends Model
{
    use HasFactory;

    protected $table = 'activate_courses';
    protected $id = 'id';
    protected $fillable = [
        'cbt_type',
        'status',
        'academic_session_id',
        'course_id',
        'staff_id'    
    ];
}
