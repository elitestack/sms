<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class current_open_cbt extends Model
{
    use HasFactory;

    protected $table = 'current_open_cbts';
    protected $id = 'id';
    protected $fillable = [
        'cbt_type',
        'academic_session',
        'status'
    ];
}
