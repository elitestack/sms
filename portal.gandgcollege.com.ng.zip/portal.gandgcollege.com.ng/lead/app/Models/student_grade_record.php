<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_grade_record extends Model
{
    use HasFactory;

    protected $table = 'student_grade_records';
    protected $id = 'id';
    protected $fillable = [
        'academic_session_id',
        'class_id',
        'term_id',
        'total_score',
        'average',
        'position',
        'student_reg'
    ];

    public function academic_session(){

        return $this->hasOne(academic_session::class, 'id', 'academic_session_id');
    }

    public function term(){

        return $this->hasOne(academic_session_term::class, 'id', 'term_id');
    }

    public function student(){

        return $this->hasOne(student_reg_base::class, 'student_reg', 'student_reg');
    }

    public function class(){

        return $this->hasOne(student_class::class, 'id', 'class_id');
    }
}
