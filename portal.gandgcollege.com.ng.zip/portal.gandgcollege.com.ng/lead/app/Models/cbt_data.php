<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_data extends Model
{
    use HasFactory;

    protected $table = 'cbt_datas';
    protected $id = 'id';
    protected $fillable = [
            'course_id',
            'cbt_data_id',
            'staff_id',
            'department_id',
            'faculty_id',
            'cbt_duration',
            'cbt_status',
            'department_status',
            'student_status',
            'academic_session_id',
            'cbt_type'

    ];
}
