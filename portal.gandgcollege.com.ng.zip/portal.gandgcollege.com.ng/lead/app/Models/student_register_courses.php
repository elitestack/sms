<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_register_courses extends Model
{
    use HasFactory;

    protected $table = 'student_register_courses';
    protected $id = 'id';
    protected $fillable = [
        'student_reg',
        'cbt_course_id',
        'academic_session_id',
        'department_id',
        'faculty_id'
    ];

}
