<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_ca extends Model
{
    use HasFactory;
    protected $table = "student_ca";
    protected $id = "id";
    protected $fillable = [
        "student_reg",
        "academic_session_id",
        "term_id",
        "ca_score",
        "exam_score",
        "subject_id",
        "class_id"
    ];

    public function subject(){

        return $this->hasOne(subject::class, 'id', 'subject_id');
    }
}
