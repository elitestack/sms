<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_reg_base extends Model
{
    use HasFactory;

    protected $table = 'student_reg_bases';
    protected $id = 'id';
    protected $fillable = [
        'application_id',
        'student_reg'
    ];


    public function students(){

        return $this->hasOne(pending_student::class, 'application_id', 'application_id' );
    }
}
