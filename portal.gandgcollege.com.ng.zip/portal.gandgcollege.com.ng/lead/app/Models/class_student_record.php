<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class class_student_record extends Model
{
    use HasFactory;

    protected $table = "class_student_record";
    protected $id = "id";
    protected $fillable = [
        "student_reg",
        "class_id",
        "term_id",
        "academic_session_id"
    ];


    public function class(){

        return $this->belongsTo(student_class::class, 'class_id', 'id');
    }

    public function academic_session(){

        return $this->belongsTo(academic_session::class, 'academic_session_id', 'id');
    }
    public function term(){

        return $this->belongsTo(academic_session_term::class, 'academic_session_id', 'id');
    }
    
    
    // public function student_data(){

    //     return $this->belongsTo(pending_student::class, 
    //     'student_reg', 'student_reg');
    // }
}
