<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class assign_class extends Model
{
    use HasFactory;

    protected $table = "assign_classes";
    protected $id = 'id';
    protected $fillable = [
        'staff_email',
        'class_id'
    ];

    public function staff(){

        return $this->hasOne(staff_data::class, 'staff_email', 'staff_email');
    }

    public function class(){

        return $this->hasOne(student_class::class, 'id', 'class_id');
    }
}
