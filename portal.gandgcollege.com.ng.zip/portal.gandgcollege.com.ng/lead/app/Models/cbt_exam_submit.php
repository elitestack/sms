<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_exam_submit extends Model
{
    use HasFactory;

    protected $table = 'cbt_exam_submit';

    protected $id = 'id';

    protected $fillable = [
        'student_reg',
        'cbt_type',
        'academic_session_id',
        'cbt_course_id',
        'faculty_id',
        'department_id'
    ];
}
