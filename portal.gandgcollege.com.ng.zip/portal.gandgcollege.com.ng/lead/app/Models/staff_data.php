<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class staff_data extends Model
{
    use HasFactory;

    protected $table = 'staff_data';
    protected $id = 'id';
    protected $fillable = [
        'staff_name',
        'staff_email',
        'staff_role',
        'password'
    ];
}
