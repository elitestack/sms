<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class test extends Model
{
    use HasFactory;
    
     protected $table = "class_student_record";
    protected $id = "id";
    protected $fillable = [
        "student_reg",
        "class_id",
        "term_id",
        "academic_session_id"
    ];
    
}
