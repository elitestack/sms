<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class attendance_sheet extends Model
{
    use HasFactory;

    protected $table = 'attendance_sheets';

    protected $id = 'id';

    protected $fillable = [
        'academic_session_id',
        'student_reg',
        'cbt_data_id',
        'cbt_type',
        'cbt_course_id'
    ];
}
