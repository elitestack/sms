<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class session_id extends Model
{
    use HasFactory;

    protected $table = 'session_ids';

    protected $id = 'id';

    protected $fillable = [
        'reg_code',
        'session_id',
        'type',
        'staff_id',
        'status'
    ];
}
