<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class assign_course extends Model
{
    use HasFactory;

    protected $table = 'assign_courses';

    protected $id = 'id';

    protected $fillable = [
        'course_id',
        'staff_id',
        'status',
        'faculty_id',
        'department_id'
    ];
}
