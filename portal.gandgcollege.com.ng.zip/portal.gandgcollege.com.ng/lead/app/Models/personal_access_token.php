<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class personal_access_token extends Model
{
    use HasFactory;

    protected $table = 'personal_access_tokens';
    protected $id = 'id';
    protected $fillable = [
        'tokenable_type',
        'tokenable_id',
        'token',
        'status',
        'abilities'
    ];
}
