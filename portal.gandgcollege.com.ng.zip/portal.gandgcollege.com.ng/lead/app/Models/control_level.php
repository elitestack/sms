<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class control_level extends Model
{
    use HasFactory;

    protected $table = 'control_levels';
    protected $id = 'id';
    protected $fillable = [
        'department_control_level',
        'course_id',
        'cbt_data_id',
        'academic_session_id',
        'department_id',
        'cbt_type'
    ];
}
