<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class academic_session_term extends Model
{
    use HasFactory;

    protected $table = "academic_session_terms";
    protected $id = "id";
    protected $fillable = [
        "academic_session_id",
        "term",
        "term_status"
    ];
}
