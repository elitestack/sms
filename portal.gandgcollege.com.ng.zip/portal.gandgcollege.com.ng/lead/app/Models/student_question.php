<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class student_question extends Model
{
    use HasFactory;

 
    protected $table = 'cbt_questions';
    protected $id = 'id';
 
    public function cbt_student_answer(){

        return $this->hasMany(cbt_answer::class, 'cbt_question_id', 'cbt_question_id');
    }

}
