<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class pending_student extends Model
{
    use HasFactory;

    protected $table = "pending_student_data";
    protected $id = "id";
    protected $fillable = [
        "surname",
        "othernames",
        "sex",
        "address",
        "guardian",
        "guardian_address",
        "guardian_phone",
        "application_id",
        "term_id",
        "academic_session_id",
        "application_status"
    ];


}
