<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class score_data extends Model
{
    use HasFactory;

protected $table = 'score_data';    
protected $fillable = [
    'cbt_id',
    'user_id',
    'cbt_session_id',
    'score_data'
];

}
