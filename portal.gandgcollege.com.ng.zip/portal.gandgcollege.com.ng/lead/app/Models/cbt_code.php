<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class cbt_code extends Model
{
    use HasFactory;

    protected $table = 'cbt_codes';
    protected $id = 'id';
    protected $fillable = [
        'cbt_code_ref',
        'cbt_role_assign',
        'cbt_code_type',
        'cbt_code_id',
        'code_status',
        'staff_id',
        'faculty_id',
        'department_id'
    ];
}
