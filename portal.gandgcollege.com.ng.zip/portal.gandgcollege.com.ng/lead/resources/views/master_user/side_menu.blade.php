<div class="side-menu-non" id="side_content">
    <ul class="mt-4" style="list-style: none;">
        <li class="h-5 rounded" style="background-color:#ff6347; color:white"><a style="color:white" href="{{url('/user/dashboard')}}" class="nav-link"><i class="fa-solid fa-home"></i> home</a></li>
        <li><a href="{{url('/user/set-quiz')}}" class="nav-link" style="color:white"><i class="fa-solid fa-book"></i> cbt set</a></li>
        {{-- <li><a href="{{url('/user/profile')}}" class="nav-link">profile</a></li> --}}
        <li><a href="{{url('/user/logout')}}" class="nav-link" style="color:white"><i class="fa-solid fa-arrow"></i> logout</a></li>
    </ul>
</div>
