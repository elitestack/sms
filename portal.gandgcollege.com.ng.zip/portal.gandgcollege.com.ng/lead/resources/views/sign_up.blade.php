@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:45%'>
            <div class="card-header">
            <h1 class="text-center"><a href="{{url('/')}}"><img src="{{asset('/asset/icon.webp')}}" alt="cbtdraft.com" style="width:15%"></a></h1>
        <h3 class="text-center">CBTDRAFT Test Portal</h3>
        <p>start by creating cbt (computer based testing) quiz, today easier now</p>
                <h5 class="text-center">Sign up to have access !!!</h5>
                
                
            </div>
            <div class="card-body">
        
                <form action="{{url('/staff_registration_request')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center" style="color:red">
            @php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            @endphp
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Email:</label>
                        <input type="email" name="email" placeholder="type email" class="form-control" style="width:100%" value="<?php if(session()->has('mail')){
                            echo session()->get('mail');
                        } ?>">
                        <span>
                            @error('email')
                                <p style="color:red" class="text-center">empty email submitted</p>                                
                            @enderror
                        </span>
                    </div>


                    <div class="form-group">
                        <label for="" class="form-label">Password: </label>
                        <input type="password" name="password" placeholder="type password" class="form-control" style="width:100%">
                        <span>
                            @error('password')
                                <p style="color:red" class="text-center">empty registration code submitted</p>
                            @enderror
                        </span>
                    </div>
                    <div class="form-group">
                        <label for="" class="form-label">Confirm Password:</label>
                        <input type="password" name="confirm_password" placeholder="confirm your password" class="form-control" style="width:100%">
                        <span>
                            @error('password')
                                <p style="color:red" class="text-center">empty registration code submitted</p>
                            @enderror
                        </span>
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Sign up</button>
                    </div>
                    <p class="mt-3">Already have account, <a style="color:red; text-decoration:none" href="{{url('/login')}}">Login !!!</a></p>
                    <p class="mt-3">Password <a style="color:red; text-decoration:none" href="{{url('/password_reset')}}">Reset !!!</a></p>
                </form>
            </div>
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

@endsection
