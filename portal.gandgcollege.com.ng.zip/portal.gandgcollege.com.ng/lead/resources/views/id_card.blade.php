@extends('id_card_master')

@section('content')

<div style="display:flex">



<div class="card" style="width: 9.9cm; height:6.7cm">
    <div class="card-header" style="display:flex">
        <div>
            <img src="{{asset('/asset/icon.webp')}}" width="50px">
        </div>
        <div>
            <h5 class="text-center"><b>MCA  Academy</b></h5>
            <p>Student Identity Card</p>
        </div>
    </div>
    <div class="card-body" style="display:flex">
<!-- data -->
<div>
    <p><b>Surname:</b> Peter</p>  
    <p><b>Othernames:</b> Samuel</p>
    <p><b>Student Reg:</b> MCA0001</p>


</div>
<!-- data end -->

<!-- passport -->
<div>

<img src="{{url('/asset/avatar.png')}}" width="50%">
</div>
<!-- passport  end -->




    </div>
</div>




</div>


@endsection