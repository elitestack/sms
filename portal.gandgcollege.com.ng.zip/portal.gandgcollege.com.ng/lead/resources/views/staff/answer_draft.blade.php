@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

@php 

$question_count = count($cbt_question);

@endphp


<div class="card-expand  mt-5" id="mainbar">

<div class="exam-master" style="width:100%">
    <!-- master start -->
    
    <div class="exam-holder" style="width:70%">
        <!-- exam holder start -->

    <!-- question start -->
    <div class="mt-5" id="question_group">

    <!-- card start -->
    <div class="card" style="position:static">
        <div class="card-header">
            <h4 class="text-center">{{'CBT Question '}}</h4>
            <h5 class="text-center"><a href="{{url('/staff/cbt_question/cbt_id='.$cbt_question->cbt_data_id)}}"><button class="btn btn-danger">Add New Question</button></a></h5>
    </div>
        <div class="card-body">

        <form action="{{url('/staff/processing_update_questions')}}" method="post" class="w-75 mx-auto rounded" id="data-form">
            @csrf


                <div class="form-group">

                    <textarea class="form-control" name="question" rows="9" cols="50">{{$cbt_question->cbt_question}}
</textarea>                 
    <input type="hidden" name="cbt_data_id" value="">          
                    <span>
                        @error('question')
                        <h6 class="text-center" style="color:red">empty question submitted</h6>
                    @enderror
                    </span>

             </div>
             <div class="form-group mt-2">
                <button class="btn btn-danger" onclick="javascript:void()">Add Media</button>
            </div>
             
            <div class="form-group mt-3">
                <button class="btn" style="background-color:#ff6347; color:white">Update questions</button>
            </div>
        </form>


        </div>
    </div>
    <!-- card end -->

        <!-- card start -->
        <div class="card mt-3" style="position:static">
        <div class="card-header">
            <h5 class="text-center">CBT Answer</h5>
        </div>
        <div class="card-body" style="display:flex">

        <form action="{{url('/staff/question_option_request')}}" method="post"  id="data-form" style="width:50%">
                    @csrf
                     <div class="form-group">
                        <label for="" class="form-group">Option</label>
                        <input type="text" class="form-control" name="option" placeholder="type option">
                        <input type="hidden" class="form-control" name="cbt_id" value="{{$cbt_question[$i]->cbt_data_id}}" >
                        <input type="hidden" class="form-control" name="question_id" value="{{$cbt_question[$i]->cbt_question_id}}" >
                     </div>
                     <div class="form-group">
                        <label for="" class="form-label">Option Status</label>
                        <select class="form-control" name="option_status" id="">
                            <option value="correct_option">correct option</option>
                            <option value="option">option</option>
                        </select>
                     </div>
                     <div class="form-group">
                        <label for="" class="form-label">Option Label</label>
                        <select class="form-control" name="option_label_id" id="">
                                                    <option value="a">A</option>
                            <option value="b">B</option>
                            <option value="c">C</option>
                            <option value="d">D</option>
                            <option value="e">E</option>
                            <option value="f">F</option>
                            <option value="g">G</option>
                            <option value="h">H</option>
                        </select>
                     </div>
                     
                    
                    <div class="form-group mt-3">
                        <p class="text-center"><button class="btn" type="submit" style="background-color:#ff6347; color:white; width:100%">submit</button></p>
                    </div>
                </form>

                <table class='table' style="width:50%">
                        <thead>
                            <th>id</th>
                            <th>Option</th>
                            <th>status</th>
                            <th>Action</th>
                        </thead>
                        <tbody>

                        @php 

$cbt_answer_fetch = App\Models\cbt_answer::where('cbt_question_id', '=', $cbt_question[$i]->cbt_question_id)->where('cbt_data_id', '=', $cbt_question[$i]->cbt_data_id)->where('staff_id', '=', session()->get('staff_id'))->get();

$option_count = count($cbt_answer_fetch);
                        @endphp

                        </tbody>
                    </table>



        </div>
    </div>
    <!-- card end -->

</div>

        <!-- exam holder end -->

    </div>

    <div class="exam-holder" style="width:30%">
        <!-- exam holder start -->


        {{-- statistics card start --}}
<div class="card mt-5" style="position:static; width:100%; margin-left:8px;">
    <div class="card-header">
        <h4 class="text-center">Questions no</h4>
    </div>
    <div class="card-body">
       <div class="question-holder-number">
            <div class="question-number">
            @for($i =0; $question_count > $i; $i++)    
            <a href="{{url('/staff/cbt_answer/cbt_id='.$cbt_mass_question[$i]->cbt_data_id.'&question_id'.'='.$cbt_mass_question[$i]->cbt_question_id)}}"><button class="btn btn-danger mt-2" style="margin-left: 5px">{{$i+1}}</button></a>            @endfor
            </div>
       </div>
    </div>
</div>

{{-- </div> --}}


{{-- statistics card end --}}
        <!-- exam holder end -->

    </div>
     

    <!-- master end -->
</div>





{{-- ending --}}
</div>
</div>

<script>

    let question_group = document.getElementsByClassName('question_group');

    let firstTab = 0;

    group_step(firstTab);

    function group_step(n){
        // get the grouping id and make it visible
        question_group[n].style.display = "block";

        // next or previous button control
        let previous_button = document.getElementById('previous');
        let next_button = document.getElementById('next');
        if(n == 0){
            // hide the previous button 
            
            previous_button.style.display = "none";
        }else{
            // showing the previous, if the result is not equal to zero
            previous_button.style.display = "inline";
        }

        // checking for the last question group
        if(n == (question_group.length - 1)){
            // if the it the total length
            next_button.innerHtml = "Finished"
        }else{
            next_button.innerHtml = "Next"
        }
    }

    // tab number adder

    function prev_next_step(n){

        // hiding the first tab
        question_group[firstTab].style.display = 'none';
        // get the group id
        // question_group[n].style.display = 'block';

        // adding the current number to firstTab

        firstTab = n + firstTab;

        if(firstTab >= (question_group.length - 1)){

            group_step(firstTab);

        }

        group_step(firstTab);
    }



</script>
@endsection