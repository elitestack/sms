<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="{{asset('/js/jquery.slim.min.js')}}" ></script>
    <script src="{{asset('/js/popper.min.js')}}" ></script>
    <script src="{{asset('/js/bootstrap.bundle.min.js')}}" ></script>
    <script src="{{asset('fontawesome/js/all.js')}}" crossorigin="anonymous"></script>
    <title>CBT Platform</title>
</head>
<style>

</style>
<body class="container">

<?php 

$count = count($cbt_question);
?>
<div class="card mt-3">
    <div class="card-header">
        <h3 class="text-center">CBT Question Data</h3>
        <table class="table">
                <tr>
                <th>Course:</th><td>{{$course_data->course_name}}</td>
            </tr>
            <tr>
                <th>Course Code:</th><td>{{$course_data->course_code}}</td>
                </tr>
                <tr>
                    <?php
        // $control_level = App\Models\control_level::where('cbt_data_id', '=', $cbt_data_id)->first();
        $academic_session = App\Models\academic_session::where('academic_session_id', '=', $cbt_data_id->academic_session_id)->first();

        // dd($academic_session);
                    ?>
                <th>Academic session:</th><td>@if($academic_session) {{$academic_session->academic_session}} @else {{'Not assigned to an academic session'}} <a href="{{url('/staff/cbt_setting/cbt_id='.$cbt_data_id->cbt_data_id)}}"><button class="btn btn-danger">Assign now</button></a> @endif </td>
                </tr>
                <tr>
                    <th>Duration:</th><td>{{$cbt_data_id->cbt_duration}}</td>
                </tr>
                <tr>
                    <th>Questions</th><td>{{$count}}</td>
                </tr>
        </table>
    </div>
</div>

@for($i =0; $count > $i; $i++)
<div class="card mt-3" style="position:static">
    <div class="card-header">
        <h6 class="text-center">{{'Question '.$i+1}}</h6>
    </div>
    <div class="card-body">
    <div class="img-container" style="display:flex; flex-wrap:wrap;" style="100%">
            <?php 
                $fetch_all_images = App\Models\cbt_question_image::where('cbt_question_id', '=', $cbt_question[$i]->cbt_question_id)->get();
            // dd($fetch_all_images);
            ?>

@foreach($fetch_all_images as $image)

    <div>
        <form action="{{url('/staff/delete_cbt_question_media')}}" method="post">
            @csrf
            <h1 class="text-center"><img style="width:35%" src="{{asset('/question_images/'.$image->image_name)}}" alt="" srcset=""></h1>
            <h6 class="text-center">{{$image->image_title}}</h6>
    </div>
@endforeach
</div>
<p class="text"><?php echo $cbt_question[$i]->cbt_question ?></p>
        
        
        @foreach($cbt_question[$i]->cbt_student_answer as $answer)
            <ul style="list-style:none">
                <li> <?php echo $answer->option_label_id.': '; ?><?php echo $answer->options; ?>                     @if($answer->option_status === 'correct_option')
                    <i class="fa-solid fa-check" style='color:#ff6347'></i>
                    @endif</li>
        
            </ul>
        @endforeach
    </div>
</div>
@endfor
</body>


</html>