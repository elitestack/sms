@extends('faculty.master.app')

@section('content')

<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('faculty.master.side_menu')
    </div>


    <!-- php start -->


    <!-- php end -->

<div class="card-expand  mt-5" id="mainbar">



<div class="card mt-5" style="position:static; width:100%">
    <div class="card-header">
        <h3 class="text-center">CBT Record Data</h3>
    </div>
    <div class="card-body">
        <table class="table">
            <tr>
                <th>Course Name</th><td>Computers science</td>
            </tr>
            <tr>
                <th>Course Code</th><td>CMP 111</td>
            </tr>
            <tr>
                <th>Faculty</th><td>CMP 111</td>
            </tr>
            <tr>
                <th>Date</th><td>Computers science</td>
            </tr>
        </table>
    </div>
</div>

<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center">Student Score Data</h4>
    </div>
</div>

<div class="card mt-5 mb-5">
    <div class="card-body">
        <table class="table">
            <thead>
                <tr><th>S/N</th><th>Student Name</th><th>Matric</th><th>Score</th></tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>James John</td>
                    <td>ETS/3535/3554</td>
                    <td>46</td>
                </tr>
                <tr>
                <td>2</td>
                    <td>James John</td>
                    <td>ETS/3535/3554</td>
                    <td>45</td>
                                </tr>
            </tbody>
        </table>
    </div>
</div>




{{-- ending --}}
</div>
</div>

@endsection