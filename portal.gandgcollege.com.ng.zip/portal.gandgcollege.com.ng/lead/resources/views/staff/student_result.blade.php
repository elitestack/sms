@extends('staff.master.app')

@section('content')

<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>


    <!-- php start -->


    <!-- php end -->

<div class="card-expand  mt-5" id="mainbar">



<div class="card mt-5" style="position:static; width:100%">
    <div class="card-header">
        <h3 class="text-center">CBT Data</h3>
    </div>
    <div class="card-body">
        <form action="{{url('/staff/student_result_request')}}" method="post">
            @csrf
            <?php 

            $academic_session_count = count($academic_session);
            $course_count = count($course);
            ?>
            <div class="form-group">
                <label for="" class="form-label">Academic Session</label>
                <select name="academic_session_id" id="" class="form-control">
                    <option value="none">select academic session</option>
                    @for($i=0; $academic_session_count > $i; $i++)
                    <option value="{{$academic_session[$i]->academic_session_id}}">{{$academic_session[$i]->academic_session}}</option>
                    @endfor
                </select>
            </div>

            <div class="form-group">
                <label for="" class="form-label">Course</label>
                <select name="course_id" id="" class="form-control">
                    <option value="none">select course</option>
                    @for($i=0; $course_count > $i; $i++)

                    <?php
                    $course_data = App\Models\cbt_course::where('course_id', '=', $course[$i]->course_id)->get();
                    ?>

        @foreach($course_data as $course_datas)
        <option value="{{$course_datas->course_id}}">{{$course_datas->course_code.'-'.$course_datas->course_name}}</option>

        @endforeach
                    @endfor
                </select>
            </div>
            <div class="form-group mt-3">
                <button class="btn btn-danger">Fetch Result</button>
            </div>
        </form>    
    </div>
</div>





{{-- ending --}}
</div>
</div>

@endsection