@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

<div class="card-expand  mt-5" id="mainbar">

<!-- php start -->


<!-- php start -->
<!-- box start -->
<?php 

$assign_courses_count = count($assign_courses);
$academic_session_count = count($academic_session);
$activated_course_count = count($activated_course);

?>


        <div class="card mt-5" style="position:static">
            <div class="card-header">
                <h4 class="text-center">CBT Exam Control</h4>
            </div>
            <div class="card-body">
                <table class="table">
                    <form action="{{url('/staff/activate_course_request')}}" method="post">
                    @csrf    
                    <div class="form-group">
                            <label for="" class="form-label">Academic session</label>
                            <select name="academic_session" id="" class="form-control">
                            @for($i=0; $academic_session_count > $i; $i++)
                                <option value="{{$academic_session[$i]->academic_session_id}}">{{$academic_session[$i]->academic_session}}</option>
                                @endfor
                            </select>
                        </div>

                        <div class="form-group mt-2">
                            <label for="" class="form-label">CBT Course</label>
                            <select name="cbt_course" id="" class="form-control">
                            @for($i =0; $assign_courses_count > $i; $i++)
                            <?php
                                $course = App\Models\cbt_course::where('course_id', '=', $assign_courses[$i]->course_id)->first();
                             ?>
                                <option value="{{$assign_courses[$i]->course_id}}">{{$course->course_code.'-'.$course->course_name}}</option>
                            @endfor
                            </select>
                        </div>   
                            <div class="form-group">
                            <label for="" class="form-label">Status</label>
                            <select name="cbt_status" id="" class="form-control">
                                <option value="opened">open</option>
                                <option value="closed">close</option>
                            </select>
                        </div>

                        </div>   
                            <div class="form-group">
                            <label for="" class="form-label">CBT Type</label>
                            <select name="cbt_type" id="" class="form-control">
                                <option value="cbt_ca_test">C.A CBT</option>
                                <option value="cbt_exam">CBT Exam</option>
                            </select>
                        </div>

                        <div class="form-group mt-2">
                            <button class="btn btn-danger">Submit</button>
                        </div>
                    </form>
                </table>
            </div>
            <div class="card-footer">

            </div>
        </div>

        <div class="card mt-5" id="assigned_course">
            <div class="card-header">
                <h4 class="text-center">CBT Assigned Courses</h4>
            </div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <th>Course Code</th>
                        <th>Course</th>
                        <th>CBT Type</th>
                        <th>Status</th>
                        <th>Academic session</th>
                    </thead>

                    <tbody>
                    @for($i =0; $activated_course_count > $i; $i++)
                    <tr>
                    <?php
                                $course = App\Models\cbt_course::where('course_id', '=', $activated_course[$i]->course_id)->first();
                                $academic_session = App\Models\academic_session::where('academic_session_id', '=', $activated_course[$i]->academic_session_id)->first();
                             ?>
                                                     <td>{{$course->course_code}}</td>
                        <td>{{$course->course_name}}</td>
                        <td>{{$activated_course[$i]->cbt_type}}</td>
                        <td>{{$activated_course[$i]->status}}</td>
                        <td>{{$academic_session->academic_session}}</td>
                    </tr>
                    @endfor           
                </tbody>
                </table>
            </div>
            <div class="card-footer">

            </div>
        </div>

        <!-- end -->


</div>
</div>

@endsection