@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

<div class="card-expand  mt-5" id="mainbar">


<div class="card mt-5">
            <div class="card-header" style="position:static;">
                <h4 class="text-center">CBT Data</h4>
            </div>
            <div class="card-body">
                <table class="table">
                    <tr>
                        <th>Course: </th><td>{{$course_fetch->course_name}}</td>
                   </tr>

                    <tr>
                        <th>Course Code: </th><td>{{$course_fetch->course_code}}</td>
                    </tr>
                    <tr>
                        <th>Faculty: </th><td>{{$faculty->faculty_name}}</td>
                    </tr>
                    <tr>
                        <th>Department: </th><td>{{$department->department_name}}</td>
                    </tr>
                    <tr>
                        <th>Academic session: </th><td>{{$cbt_data->academic_session_id}}</td>
                    </tr>
                    <tr>
                        <th>CBT Type: </th><td>{{$cbt_data->cbt_type}}</td>
                    </tr>

                    <tr>
                        <th>CBT Status: </th><td>{{$cbt_data->cbt_status}}</td><td>
                            <form action="{{url('/staff/cbt_data_setting_request')}}" method="post">
                                @csrf
                            <input type="hidden" name="cbt_data_id" value="{{$cbt_data->cbt_data_id}}">
                            <input type="hidden" name="cbt_status" value="{{$cbt_data->cbt_status}}">
                            <button class="btn btn-danger">
                                @if($cbt_data->cbt_status === 'published')
                                    {{'Draft'}}
                                @elseif($cbt_data->cbt_status === 'draft')
                                    {{'Publish'}}
                                @endif
                            </button>
                        </form></td>
                    </tr>

                </table>
            </div>

        </div>
<!-- card end -->
<div class="card mt-5">
            <div class="card-header" style="position:static;">
                <h4 class="text-center">CBT Academic Session</h4>
            </div>
            <div class="card-body">
            <form action="{{url('/staff/cbt_data_setting_request')}}" method="post">
                    @csrf
                    <input type="hidden" name="cbt_data_id" value="{{$cbt_data->cbt_data_id}}">
                    <label for="">Select Academic Session</label>
                    <select name="academic_session_id" id="" class="form-control">
                        <option value="none">none</option>
                        @foreach($academic_session as $session)
                        <option value="{{$session->academic_session_id}}">{{$session->academic_session}}</option>
                        @endforeach
                    </select>
                    <input type="hidden" name="cbt_session" value="{{'academic_session'}}">
                    <button class="mt-3 btn btn-danger">Assign Academic CBT Exam</button>
                </form>

                <form class="mt-3" action="{{url('/staff/cbt_data_setting_request')}}" method="post">
                    @csrf
                    <input type="hidden" name="cbt_data_id" value="{{$cbt_data->cbt_data_id}}">
                    <label for="">Select CBT Type</label>
                    <select name="cbt_type_value" id="" class="form-control">
                    <option value="none">none</option>
                        <option value="cbt_ca_test">CBT Test</option>
                        <option value="cbt_exam">CBT Exam</option>
                    </select>
                    <input type="hidden" name="cbt_type" value="{{'cbt_type'}}">
                    <button class="mt-3 btn btn-danger">Assign CBT Type</button>
                </form>
            </div>

        </div>
<!-- card end -->

        <div class="card mt-5" style="position:static;">
            <div class="card-header">
                <h4 class="text-center">CBT Privacy</h4>
            </div>
            <div class="card-body">
                <table class="table">
                   <tr>
                    <th>Student Status: </th><td>{{$cbt_data->student_status}}</td>
                    <td>
                        <form action="{{url('/staff/cbt_data_setting_request')}}" method="post">
                        @csrf
                        <input type="hidden" name="cbt_data_id" value="{{$cbt_data->cbt_data_id}}">
                            <input type="hidden" name="student_status" value="{{$cbt_data->student_status}}">
                            <button class="btn btn-danger">
                                @if($cbt_data->student_status === 'deactivated')
                                    {{'activate'}}
                                @elseif($cbt_data->student_status === 'activated')
                                    {{'deactivate'}}
                                @endif
                            </button>
                        </form>
                    </td>
                   </tr>

                   <tr>
                    <th>Department Level: </th><td>{{$cbt_data->department_status}}</td>
                    <td>
                        <form action="{{url('/staff/cbt_data_setting_request')}}" method="post">
                        @csrf
                        <input type="hidden" name="cbt_data_id" value="{{$cbt_data->cbt_data_id}}">
                            <input type="hidden" name="department_status" value="{{$cbt_data->department_status}}">
                            <button class="btn btn-danger">
                                @if($cbt_data->department_status === 'deactivated')
                                    {{'activate'}}
                                @elseif($cbt_data->department_status === 'activated')
                                    {{'deactivate'}}
                                @endif
                            </button>
                            </form>
                    </td>
                   </tr>
                    <tr>
                        <th>Duration</th><td>{{$cbt_data->cbt_duration}}</td>
                        <td>
                        <form action="{{url('/staff/cbt_data_setting_request')}}" method="post">
                        @csrf
                            <div class="form-group">
                            <input type="hidden" name="cbt_data_id" value="{{$cbt_data->cbt_data_id}}">
                            <input type="number" class="form-control" name="cbt_duration" value="{{$cbt_data->cbt_duration}}">
                            </div>
                            <div class="form-group mt-2">
                            <button class="btn btn-danger">
                                Save
                            </button>

                            </div>
                            </form>
                        </td>
                    </tr>

                </table>
            </div>

        </div>
<!-- end -->
</div>
</div>

@endsection