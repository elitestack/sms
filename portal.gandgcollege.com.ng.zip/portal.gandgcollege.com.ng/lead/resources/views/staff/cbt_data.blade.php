@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

<div class="card-expand  mt-5" id="mainbar">
<!-- php codes -->

@php 


$cbt_allow_course_count = count($cbt_allow_course);
$cbt_already_created_course_count = count($cbt_already_created_course);

@endphp

<!-- php codes ends -->
<!-- box start -->

<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h1 class='text-center'>{{$cbt_already_created_course_count}}</h1>
                        <h5 class="text-center">CBT</h5>
                        <h6 class="text-center"><a href=""><button class="btn btn-danger">view CBT</button></a></h6>
        </div>
    <div class="box-holder">

        <div class="box">


        <h1 class='text-center'>{{$cbt_allow_course_count}}</h1>
                        <h5 class="text-center">Courses</h5>
                        <h6 class="text-center"><a href=""><button class="btn btn-danger">view CBT</button></a></h6>
        </div>
    </div>

</div>
<!-- end box -->
    <div class="card-header">        
<h3 class="text-center">CBT Exams</h3>
    </div>
    <div class="card-body">

        <form action="{{url('/staff/processing_set_cbt')}}" method="post" class="w-75 mx-auto rounded" id="data-form">
            @csrf


    
    <div class="form-group mt-2">
                <label for="">Course CBT</label>
            <select name="course_id" id="" class="form-control mt-2">
                @php 

                @endphp
            @for($i = 0; $i < $cbt_allow_course_count; $i++)
            @php 

            $course_fetch = App\Models\cbt_course::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('course_id', '=', $cbt_allow_course[$i]->course_id)->first();

            @endphp
            <option value="{{$course_fetch->course_id}}">{{$course_fetch->course_name}}</option>
            @endfor
            </select>    
            </div>             

            <div class="form-group">
                <label for="" class="form-label">Duration</label>
                <input type="number" class="form-control" name="cbt_duration">
            </div>
            <div class="form-group mt-3">
                <button class="btn" style="background-color:#ff6347; color:white">set cbt</button>
            </div>
        </form>
        {{-- setting quiz --}}


        <div class="question-section mt-3">
            <h5 class="text-center">CBT Exams</h5>
            <table class="table">
                <thead>
                    <th>sn</th>
                    <th>CBT Course</th>
                    <th>CBT ID</th>
                    <th>Date</th>
                    <th>action</th>
                </thead>


                @for($i =0; $i < $cbt_already_created_course_count; $i++)
                    <tr>
                        <td>{{$i+1}}</td>
                        @php 

                        $course_fetch = App\Models\cbt_course::where('faculty_id', '=', session()->get('faculty_id'))->where('department_id', '=', session()->get('department_id'))->where('course_id', '=', $cbt_already_created_course[$i]->course_id)->first();

                        @endphp
                        <td>{{$course_fetch->course_name}}</td>
                        <td>{{$cbt_already_created_course[$i]->cbt_data_id}}</td>
                        <td>{{$cbt_already_created_course[$i]->created_at}}</td>
                        <td><a href="{{url('/staff/cbt_question/cbt_id='.$cbt_already_created_course[$i]->cbt_data_id)}}"><button class="btn btn-danger">Set Questions</button></a>
                        <a href="{{url('/staff/cbt_data_id_review/cbt_data_id='.$cbt_already_created_course[$i]->cbt_data_id)}}"><button class="btn btn-danger">View Question</button></a>
                        </td>
                    </tr>
                 @endfor   

            </table>
        </div>

        {{-- ending setting quiz --}}
    </div>
</div>

{{-- ending --}}
</div>
</div>

@endsection