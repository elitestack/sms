@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

<div class="card-expand  mt-5" id="mainbar">

<!-- box start -->

@php 

$question_count = count($question);

@endphp

<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h1 class='text-center'>1</h1>
                        <h5 class="text-center">Assigned Staff</h5>
                        <h6 class="text-center"><a href=""><button class="btn btn-danger">view CBT</button></a></h6>
        </div>
    <div class="box-holder">

        <div class="box">


        <h1 class='text-center'>{{$question_count}}</h1>
                        <h5 class="text-center">CBT questions</h5>
                        <h6 class="text-center"><a href="#questions"><button class="btn btn-danger">view Questions</button></a></h6>
        </div>
    </div>

</div>
<!-- end box -->

<div class="card mt-3" style="position:static">
    <div class="card-body">
        <table class="table">
            <tr>
                <th>Course Name</th><td>{{$course_data->course_name}}</td>
            </tr>
            <tr>
                <th>Course Code</th><td>{{$course_data->course_code}}</td>
            </tr>
            <tr>
                <th>CBT ID</th><td>{{$cbt_id}}</td>
            </tr>
            <tr>
                <th>Visibility</th><td><a href="{{url('/staff/cbt_setting/cbt_id='.$cbt_id)}}"><button class="btn btn-danger">CBT Setting</button></a></td>
            </tr>
        </table>
    </div>
</div>
<div class="card mt-3" style="position:static">

    <div class="card-body">

        <form action="{{url('/staff/processing_set_questions')}}" method="post" class="rounded" style="width:100%" id="data-form">
            @csrf


                <div class="form-group">
                    <h6 class="text-center">Question</h6>
                    <textarea style="position:absolute" class="form-control" name="question" rows="9" cols="50" placeholder="please enter your questions"> 
</textarea>                 
    <input type="hidden" name="cbt_data_id" value="{{$cbt_id}}">          
                    <span>
                        @error('question')
                        <h6 class="text-center" style="color:red">empty question submitted</h6>
                    @enderror
                    </span>

             </div>
             <!-- <div class="form-group mt-2">
                <button class="btn btn-danger" onclick="javascript:void()">Add Media</button>
            </div> -->
             
            <div class="form-group mt-3">
                <button class="btn" style="background-color:#ff6347; color:white">Add questions</button>
            </div>
        </form>

    </div>
</div>
    <div class="card mt-3" id="questions" style="position:static">
        <div class="card-body">
        <table class="table">
                <thead>
                    <th>sn</th>
                    <th>questions</th>
                    <th>Action</th>
                </thead>
                {{-- {{$count}} --}}

                @php 


                $question_count = count($question);
                @endphp

                @for($i=0; $i < $question_count; $i++)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>@php echo $question[$i]->cbt_question @endphp</td>
                    <td><a href="{{url('/staff/cbt_answer/cbt_id='.$cbt_data_id->cbt_data_id.'&question_id'.'='.$question[$i]->cbt_question_id)}}"><button class="btn btn-danger">EDIT</button></a></td>
                </tr>            
                @endfor
            </table>

        </div>
    </div>

{{-- ending --}}
</div>
</div>

@endsection

