<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="{{asset('/js/jquery.slim.min.js')}}" ></script>
    <script src="{{asset('/js/popper.min.js')}}" ></script>
    <script src="{{asset('/js/bootstrap.bundle.min.js')}}" ></script>
    <script src="{{asset('fontawesome/js/all.js')}}" crossorigin="anonymous"></script>
    <title>CBT Platform</title>
</head>
<style>

</style>
<body class="container">
<?php 
                $academic_session = App\Models\academic_session::where('academic_session_id', '=', $score_sheet[0]->academic_session_id)->first();
$course = App\Models\cbt_course::where('course_id', '=', $score_sheet[0]->cbt_course_id)->first();
$score_sheet_count = count($score_sheet);
?>

<div class="card mt-3">
    <div class="card-header">
        <h3 class="text-center">CBT Student Result</h3>
        <table class="table">
            <tr>
                <th>Course:</th><td>{{$course->course_name}}</td>
            </tr>
            <tr>
                <th>Course Code:</th><td>{{$course->course_code}}</td>
                </tr>
            <tr>
                <th>Academic Session:</th><td>{{$academic_session->academic_session}}</td>
            </tr>
        </table>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <th>S/N</th>
                <th>Faculty</th>
                <th>Department</th>
                <th>Student Name</th>
                <th>Student Reg</th>
                <th>C.A</th>
                <th>Exam</th>
                <th>Total</th>
            </thead>

            <tbody>
@for($i=0; $score_sheet_count > $i; $i++)
            <tr>
                <td>{{$i+1}}</td>
@php
                $student_name = App\Models\student_data::where('student_reg', '=', $score_sheet[$i]->student_reg)->first();
                $faculty_name = App\Models\faculty::where('reg_code', '=', $student_name->faculty_id)->first();
                $department_name = App\Models\department::where('department_id', '=', $student_name->department_id)->first();
                
@endphp
                <td>{{$faculty_name->faculty_name}}</td>
                <td>{{$department_name->department_name}}</td>
                <td>{{$student_name->name}}</td>
                <td>{{$score_sheet[$i]->student_reg}}</td>
                <td> @if($score_sheet[$i]->cbt_type === 'c_a_test')
                    {{$score_sheet[$i]->cbt_score}}
                    @endif
                </td>
                <td> @if($score_sheet[$i]->cbt_type === 'cbt_exam')
                    {{$score_sheet[$i]->cbt_score}}
                    @endif
                </td>
                <td>
                    @php
                $total = App\Models\cbt_score_data::where('student_reg', '=', $score_sheet[$i]->student_reg)->where('academic_session_id', '=', $score_sheet[$i]->academic_session_id)->sum('cbt_score');
                @endphp
                {{$total}}
                </td>
            </tr>
@endfor
            </tbody>
        </table>
    </div>
</div>

</body>


</html>