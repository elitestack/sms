@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

<div class="card-expand  mt-5" id="mainbar">

<!-- php start -->

@php 

$cbt_all_course_fetch_count = count($cbt_all_course_fetch);
$cbt_data_count = count($cbt_data);

@endphp

<!-- php start -->
<!-- box start -->

<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h1 class='text-center'>{{$cbt_data_count}}</h1>
                        <h5 class="text-center">CBT Exams</h5>
                        <h6 class="text-center"><a href="{{url('/staff/cbt_data')}}"><button class="btn btn-danger">view CBT Exam</button></a></h6>
        </div>
    <div class="box-holder">

        <div class="box">


        <h1 class='text-center'>{{$cbt_all_course_fetch_count}}</h1>
                        <h5 class="text-center">Assigned Courses</h5>
                        <h6 class="text-center"><a href="#assigned_course"><button class="btn btn-danger">View Courses</button></a></h6>
        </div>
    </div>

</div>
<!-- end box -->

        <div class="card mt-5">
            <div class="card-header">
                <h4 class="text-center">welcome {{session()->get('staff_id')}}</h4>
            </div>
            <div class="card-body">
                <table class="table">
                   <tr>
                    <th>email: </th><td>{{session()->get('staff_id')}}</td>
                   </tr>
                   <tr>
                    <th>user: </th><td>{{session()->get('login_id')}}</td>
                   </tr>
                   <tr>
                    <th>account role: </th><td>{{session()->get('login_id')}}</td>
                   </tr>
                   <tr>
                    <th>faculty: </th><td>{{$faculty->faculty_name}}</td>
                   </tr>
                   <tr>
                    <th>department: </th><td>{{$department->department_name}}</td>
                   </tr>


                </table>
            </div>
            <div class="card-footer">

            </div>
        </div>

        <div class="card mt-5" id="assigned_course">
            <div class="card-header">
                <h4 class="text-center">CBT Assigned Courses</h4>
            </div>
            <div class="card-body">
                <table class="table">

                    <thead>
                        <th>S/N</th>
                        <th>Course</th>
                        <th>Course code</th>
                    </thead>
                    <tbody>
                        @for($i=0; $cbt_all_course_fetch_count > $i; $i++)
                        <tr>
                            <td>{{$i+1}}</td>
                            @php 

                            $course_import = App\Models\cbt_course::where('course_id', '=', $cbt_all_course_fetch[$i]->course_id)->first();
                            @endphp
                            <td>{{$course_import->course_name}}</td>
                            <td>{{$course_import->course_code}}</td>
                        </tr>
                        @endfor
                    </tbody>
                </table>
            </div>
            <div class="card-footer">

            </div>
        </div>

        <!-- end -->
</div>
</div>

@endsection