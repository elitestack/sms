<div class="side-menu-non" id="side_content">
    <ul class="mt-4" style="list-style: none;">
        <li class="h-5 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/staff/dashboard')}}" class="nav-link"><i class="fa-solid fa-home"></i> Dashboard</a></li>
        <li class="h-5 rounded mt-3" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/staff/cbt_data')}}" class="nav-link"><i class="fa-solid fa-home"></i> CBT Data</a></li>       
        <li class="h-5 rounded mt-3" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/staff/activate_course')}}" class="nav-link"><i class="fa-solid fa-home"></i> Activate Course</a></li>
        <li class="h-5 rounded mt-3" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/staff/cbt_course_config')}}" class="nav-link"><i class="fa-solid fa-home"></i> Course Config</a></li>
        <li class="h-5 rounded mt-3" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/staff/student_result')}}" class="nav-link"><i class="fa-solid fa-home"></i> Result</a></li>
        <li class="h-5 rounded mt-3" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/staff/logout')}}" class="nav-link"><i class="fa-solid fa-home"></i> Logout</a></li>
                
    </ul>
</div>
