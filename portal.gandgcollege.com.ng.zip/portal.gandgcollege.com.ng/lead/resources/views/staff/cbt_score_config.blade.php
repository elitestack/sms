@extends('staff.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('staff.master.side_menu')
    </div>

<div class="card-expand  mt-5" id="mainbar">

<?php 

$assign_courses_count = count($assign_courses);
$academic_session_count = count($academic_session);

?>

<div class="card mt-5" style="position:static">
            <div class="card-header">
                <h4 class="text-center">CBT Exam Score Config</h4>
            </div>
            <div class="card-body">

                    <form action="{{url('/staff/activate_cbt_score_request')}}" method="post">
                    @csrf    
                    <div class="form-group">
                            <label for="" class="form-label">Academic session</label>
                            <select name="academic_session" id="" class="form-control">
                                @for($i=0; $academic_session_count > $i; $i++)
                                <option value="{{$academic_session[$i]->academic_session_id}}">{{$academic_session[$i]->academic_session}}</option>
                                @endfor
                            </select>
                        </div>

                        <div class="form-group mt-2">
                            <label for="" class="form-label">CBT Course</label>
                            
                            <select name="cbt_course" id="" class="form-control">
                            @for($i =0; $assign_courses_count > $i; $i++)
                            <?php
                                $course = App\Models\cbt_course::where('course_id', '=', $assign_courses[$i]->course_id)->first();
                             ?>
                                <option value="{{$assign_courses[$i]->course_id}}">{{$course->course_code.'-'.$course->course_name}}</option>
                            @endfor
</select>                       
                        </div>   

                        <div class="form-group">
                            <label for="" class="form-label">CBT Score</label>
                            <input type="number" placeholder="type cbt score per course" class="form-control" name="cbt_score">
                        </div>

                        <div class="form-group">
                            <label for="" class="form-label">CBT Type</label>
                            <select name="cbt_type" id="" class="form-control">
                                <option value="cbt_ca_test">C.A CBT</option>
                                <option value="cbt_exam">CBT Exam</option>
                            </select>
                        </div>

                        <div class="form-group mt-2">
                            <button class="btn btn-danger">Save</button>
                        </div>
                    </form>
            </div>
        </div>

        <div class="card mt-5" style="position:static">

            <div class="card-header"><h4 class="text-center">CBT Config Data</h4></div>
            <div class="card-body">
                <table class="table">
                    <thead>
                        <th>S/N</th>
                        <th>Course</th>
                        <th>Academic session</th>
                        <th>CBT Type</th>
                        <th>Score</th>
                    </thead>
                        <tbody>
                        @for($i =0; $assign_courses_count > $i; $i++)
                            <?php
                    $config = App\Models\cbt_score_setting::where('cbt_course_id', '=', $assign_courses[$i]->course_id)->first();
        // dd($config);
                    $course = App\Models\cbt_course::where('course_id', '=', $config->cbt_course_id)->first();
        $academic_session = App\Models\academic_session::where('academic_session_id', '=', $config->academic_session_id)->first();
                             ?>

                             <tr>
                                <td>{{$i+1}}</td>
                                <td>{{$course->course_name}}</td>
                                <td>{{$academic_session->academic_session}}</td>
                                <td>{{$config->cbt_type}}</td>
                                <td>{{$config->cbt_score}}</td>
                             </tr>
                            @endfor
                        </tbody>
                </table>
            </div>

        </div>

        {{-- ending --}}
</div>
</div>

@endsection
