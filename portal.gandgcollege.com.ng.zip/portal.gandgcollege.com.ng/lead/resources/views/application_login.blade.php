@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:45%'>
            <div class="card-header">
        <h1 class="text-center"><a href="https://gandgcollege.com.ng"><img src="{{asset('/images/logo.jpeg')}}" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">GandGCollege Portal</h3>
                
                
            </div>
            <div class="card-body">
        
                <form action="{{url('/application_login')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center" style="color:red">
            @php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            @endphp
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Application Id/Guardian Phone:</label>
                        <input type="text" name="application_id" placeholder="application Id" class="form-control" style="width:100%" value="<?php if(session()->has('application_id')){
                            echo session()->get('application_id');
                        } ?>">
                        @error('email')
                        <p>please enter your application id</p>
                        @enderror
                    </div>


                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Login</button>
                    </div>
                    <p class="mt-3">Student <a style="color:red; text-decoration:none" href="{{url('/student_login')}}"> Account</a></p>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

@endsection
