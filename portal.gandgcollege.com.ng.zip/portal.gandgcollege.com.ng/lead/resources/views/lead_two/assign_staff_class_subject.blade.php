@extends('lead_two.master')

@section('content')

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Assign new subject</b></h4>
        @if(session()->has('message'))
            <p class="text-center" style="color:red">{{session()->get('message')}}</p>
        @endif
    </div>
    <div class="card-body">
    <form method="post" action="{{url('/lead_two/assign_subject_confirm')}}">
        @csrf()
            <div class="form-group mt-5">
                <label class="form-label">Select Subject</lablel>
                <select class="form-control" name="subject_id">
                    @for($i=0; count($subject) > $i; $i++)
                    <option value="{{$subject[$i]->id}}">{{$subject[$i]->subject}}</option>
                    @endfor
                </select>
            </div>
            <input type="hidden" value="{{$staff_email}}" name="staff_email" >
            <input type="hidden" value="{{$class_id}}" name="class_id" >
            <div class="form-group mt-4">
                <button class="form-control mt-1">Assign Subject</button>
            </div>
</form>
        </div>

</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staff subjects</b></h4>
        <h5 class="text-center mt-2"><b>{{$staff_email}}</b></h5>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>class</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                @for($i =0; count($assign_subject) > $i; $i++)
                   @if($assign_subject[$i]->subject)
                   <tr>
                        <td>{{$i+1}}</td>
                        <td>{{$assign_subject[$i]->subject->subject}}</td>
                        <td>{{$assign_subject[$i]->class->class}}</td>
                        <td><button class="btn btn-danger">Delete</button></td>
                    </tr>
                   @endif
                @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
