@extends('lead_two.master')

@section('content')


<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Classes</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>class</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                @for($i =0; count($class) > $i; $i++)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$class[$i]->class}}</td>
                    <td><a href="{{url('/lead_two/student_class/'.$class[$i]->id)}}" target="_blank">view</a>  </td>
                </tr>
                @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
