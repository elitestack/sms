@extends('lead_two.master')

@section('content')


<div class="mt-5 w-100 mx-auto">
    <div class="card-header"><h4 class="text-center mt-5"><b>Class</b></h4></h4></div>

    <div class="card-body">
    <form method="post" action="{{url('/lead_two/assign_class')}}">
            @csrf()
            <div class="form-group mt-2">
                <label>select class</label>
                <select class="form-control" name="class_id">
                    @for($i=0; count($class) > $i; $i++)
                        <option value="{{$class[$i]->id}}">
                            {{$class[$i]->class}}
                        </option>
                    @endfor
                </select>
            </div>
<input type="hidden" value="{{$staff_email}}" name="staff_email" >
            <div class="mt-3 form-group">
                <button class="form-control">Fetch Subjects</button>
            </div>
        </form>
    </div>
</div>


<div class="mt-5 card">
    <div id="load_data">

    </div>
</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staff role</b></h4>
        <h5 class="text-center mt-2"><b>{{$staff_email}}</b></h5>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>class</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

@endsection
