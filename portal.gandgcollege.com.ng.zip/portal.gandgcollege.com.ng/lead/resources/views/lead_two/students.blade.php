@extends('lead_two.master')

@section('content')

<!--<div class="mt-5 card w-100 mx-auto">-->
<!--    <div class="card-header">-->
<!--        <h4 class="text-center mt-5"><b>Filter Students</b><h4>-->
<!--    </div>-->
<!--    <div class="card-body">-->
<!--<form action="{{url('/lead_two/filter_student')}}" method="post">-->
<!--    <div class="form-group">-->
<!--        <select name="academic_session_id" class="form-control">-->
<!--            @for($i =0; count($academic_session) > $i; $i++)-->
<!--            <option value="{{$academic_session[$i]->id}}">{{$academic_session[$i]->academic_session}}</option>-->
<!--            @endfor-->
<!--</select>-->
<!--</div>-->
<!--<div class="form-group">-->
<!--        <select name="academic_session_id" class="form-control">-->
<!--            @for($i=0; count($class) > $i; $i++)-->
<!--            <option value="{{$class[$i]->id}}">{{$class[$i]->class}}</option>-->
<!--            @endfor-->
<!--</select>-->
<!--</div>-->
<!--<div class="form-group">-->
<!--    <button class="btn btn-danger form-control" disabled>Fetch Data</button>-->
<!--</div>-->
<!--</form>-->
<!--    </div>-->
<!--</div>-->

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>{{count($student).' total students'}}</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>student name</th>
                <th>student reg</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            @for($i =0; count($student) > $i; $i++)
                @if($student[$i]->students)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$student[$i]->students->surname.' '.$student[$i]->students->othernames}}</td>
                    <td>{{$student[$i]->student_reg}}</td>
                    <td><a href="{{url('/lead_five/dashboard/'.$student[$i]->student_reg)}}" target="_blank">view</a></td>

                </tr>
                @endif
        @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
