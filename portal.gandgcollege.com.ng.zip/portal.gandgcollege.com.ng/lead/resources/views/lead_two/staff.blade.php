@extends('lead_two.master')

@section('content')

<div class="card w-75 mx-auto mt-5" >
    <div class="card-header">
        <h4 class="text-center mt-4"><b>Create new staff </b></h4>
        @if(session()->has('message'))
        <p class="text-center" style="color:red">{{session()->get('message')}}</p>
        @endif
    </div>
    <div class="card-body">
        <form method="post" action="{{url('/lead_two/staff')}}">
            @csrf()
            <div class="form-group mt-2">
                <label class="form-label">Staff email</label>
                <input type="email" class="form-control" placeholder="staff email"  name="staff_email">
            </div>
            <div class="form-group mt-2">
                <label class="form-label">Staff name</label>
                <input class="form-control" placeholder="staff name" type="text" name="staff_name">
            </div>
            <div class="form-group mt-2">
                <button class="form-control btn mt-2">Create staff</button>
            </div>

        </form>
    </div>


<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staffs</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>staff email</th>
                <th>staff name</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                @for($i =0; count($staff) > $i; $i++)
                    <tr>
                        <td>{{$i+1}}</td>
                        <td>{{$staff[$i]->staff_name}}</td>
                        <td>{{$staff[$i]->staff_email}}</td>
                        <td><a href="{{url('/lead_two/staff/'.$staff[$i]->staff_email)}}" target="_blank">View</a></td>
                    <tr>
                @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
