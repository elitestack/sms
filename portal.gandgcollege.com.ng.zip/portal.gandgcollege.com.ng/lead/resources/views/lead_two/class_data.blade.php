@extends('lead_two.master')

@section('content')

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Add Subject</b></h4>
        @if(session()->has('message'))
            <p class="text-center mt-2" style="color:red">{{session()->get('message')}}</p>
        @endif
    </div>
    <div class="card-body">
        <form method="post" action="{{url('/lead_two/assign_subject')}}">
            @csrf()
            <div class="form-group mt-2">
                <label>select subject</label>
                <select class="form-control" name="subject_id">
                    @for($i=0; count($subject) > $i; $i++)
                        <option value="{{$subject[$i]->id}}">{{$subject[$i]->subject}}</option>
                    @endfor
                </select>
            </div>

            <input type="hidden" value="{{$class->id}}" name="class_id">
            <div class="mt-3 form-group">
                <button class="form-control">Add Subject</button>
            </div>
        </form>
    </div>
</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Assign Staff</b></h4>
        @if(session()->has('message'))
            <p class="text-center mt-2" style="color:red">{{session()->get('message')}}</p>
        @endif
    </div>
    <div class="card-body">
        <form method="post" action="{{url('/lead_two/assign_staff')}}">
            @csrf()
            <div class="form-group mt-2">
                <label>select staff</label>
                <select class="form-control" name="staff_email">
                    @for($i=0; count($staffs) > $i; $i++)
                        <option value="{{$staffs[$i]->staff_email}}">{{$staffs[$i]->staff_email}}</option>
                    @endfor
                </select>
            </div>

            <input type="hidden" value="{{$class->id}}" name="class_id">
            <div class="mt-3 form-group">
                <button class="form-control">Assign staff</button>
            </div>
        </form>
    </div>
</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2" style="color:red"><b>
            {{$class->class.' subjects'}}
        </b></h4>
        <?php if($assigned_staff){ ?>
        <h2 class="text-center mt-2"><b>
            {{'Class Teacher: '.$assigned_staff->staff->staff_name}}
        </b></h2>
        <h2 class="text-center mt-2"><b>
            {{'Class Teacher Email: '.$assigned_staff->staff->staff_email}}
        </b></h2>
        <?php } ?>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                @for($i =0; count($class_subject) > $i; $i++)
                @if($class_subject[$i]->subject)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$class_subject[$i]->subject->subject}}</td>
                    <td><buton class="btn btn-danger">Privilege</button></td>
                </tr>
                @endif
                @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
