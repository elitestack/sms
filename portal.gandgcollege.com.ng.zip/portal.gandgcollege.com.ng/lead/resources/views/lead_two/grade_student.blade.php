@extends('lead_two.master')

@section('content')

<div class="card mt-5">
    <div class="card-header">
        <h4 class="text-center mt-3"><b>Grade student</b></h4>
    </div>
    <div class="card-body">
        <form method="post" action="{{url('/lead_two/grade_student')}}">
        @csrf()
            <div class="form-group">
                <label class="form-label"><b>Select student class</b></label>
                <select class="form-control" name="class_id">
                    @for($i =0; count($class) > $i; $i++)
                    <option value="{{$class[$i]->id}}">{{$class[$i]->class}}</option>
                    @endfor
                </select>
            </div>
            <div class="form-group mt-2">
                <label class="form-label"><b>Select academic session</b></label>
                <select class="form-control" name="academic_session_id">
                    @for($i=0; count($academic_session) > $i; $i++)
                    <option value="{{$academic_session[$i]->id}}">{{$academic_session[$i]->academic_session}}</option>
                    @endfor
                </select>
            </div>

            <div class="form-group">
                <button class="form-control btn">Fetch Data</button>
            </div>
</form>
    </div>
</div>

@endsection
