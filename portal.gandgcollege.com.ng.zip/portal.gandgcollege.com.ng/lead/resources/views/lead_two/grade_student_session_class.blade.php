@extends('lead_two.master')

@section('content')

<div class="card mt-5">
    <div class="card-header">
        <h4 class="text-center mt-3"><b>Grade student</b></h4>
        <h4><b>Academic session: </b>{{$academic_session->academic_session}}</h4>
        <h4><b>Class: </b>{{$class->class}}</h4>
    </div>
    <div class="card-body">
        <form method="post" action="{{url('/lead_two/student_result_grade')}}">
            @csrf()
            <input type="hidden" name="class_id" value="{{$class->id}}">
            <input type="hidden" name="academic_session_id" value="{{$academic_session->id}}">
            <div class="form-group">
                
            </div>
            <div class="form-group mt-2">
                <label class="form-label"><b>Select term</b></label>
                <select class="form-control" name="term_id">
                    @for($i =0; count($term) >$i; $i++)
<option value="{{$term[$i]->id}}">{{$term[$i]->term}}
</option> 
                    @endfor
                </select>
            </div>

            <div class="form-group">
                <button class="form-control btn">Grade</button>
            </div>
</form>
    </div>
</div>

@for($i=0; count($term) > $i; $i++)
<div class="card mt-2">
    <div class="card-header"><h4 class="text-center"><b>Student Grades: </b>
    {{$term[$i]->term}}
</div>
    <div class="card-body">
        <table class="table">
            <thead>
<tr>
    <th>#</th>
    <th>student name</th>
    <th>Reg Id</th>
    <th>Class</th>
    <th>Position</th>
    <th>Action</th>
</tr>
            </thead>
            <tbody>
@for($i =0; count($student_grade) > $i; $i++)


<?php 

$student_data = App\Models\pending_student::where('application_id', '=', $student_grade[$i]->student->application_id)->first();

?>
@if($student_data)
<tr>
    <td>{{$i+1}}</td>
    <td>{{$student_data->surname.' '.$student_data->othernames}}</td>
    <td>{{$student_grade[$i]->student_reg}}</td>
    <td>{{$student_grade[$i]->class->class}}</td>
    <td>{{$student_grade[$i]->position}}</td>
    <td><a href="{{url('/lead_five/student_result/'.$student_grade[$i]->student_reg)}}" target="_blank">View</a></td>
</tr>
@endif

@endfor
</tbody>
</table>
    </div> 
</div>
@endfor
@endsection
