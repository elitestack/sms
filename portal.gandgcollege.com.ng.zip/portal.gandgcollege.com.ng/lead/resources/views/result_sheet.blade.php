@extends('master.app')

@section('content')
<div class="d-flex card page" >



<!-- school data start -->
<div class="mx-auto" style="display:flex">
    <div>
        @php
    $student_passport = App\Models\student_passport::where('application_id', '=', $student->students->application_id)->first();
        @endphp
        <img src="{{url('/images/logo.jpeg')}}" style="width:50px">
    </div>
    <div>
        <h1 class="text-center">GOSHEN & GOLD SCHOOL & COLLEGE</h1>
        <p>Along new Market road, sabon kotar, Wamba, Wamba LGA, Nasarawa, Nigeria</p>
    </div>
    <div>
        
    </div>
</div>
<!-- school data end -->


<!-- student data start -->
<div style="display:flex">
    <table class="table">
    <tr>
            <th><b>Student reg:</b></th><td>{{$student->student_reg}}</td>
        </tr>
        <tr>
            <th><b>Surname</b></th><td>{{$student->students->surname}}</td>
        </tr>
        <tr>
            <th><b>Othernames</b></th><td>{{$student->students->othernames}}</td>
        </tr>
        <tr>
            <th><b>Position:</b></th><td>@if($student_grade)  {{$student_grade->position}} @endif</td>
        </tr>
       
</table>
<table class="table">
        <tr>
            <th><b>Academic session:</b></th><td>{{$academic_session->academic_session}}</td>
        </tr>
        <tr>
            <th><b>Term:</b></th><td>{{$term->term}}</td>
        </tr>
       
        <tr>
            <th><b>No. of times school opened/times present:</b></th><td></td>
        </tr>
        <tr>
            <th><b>Total students:</b></th><td>{{$student_count}}</td>
        </tr>
        
</table>
</div>
<!-- student data end -->



<!-- result data start -->
<div style="display:flex">
    <div>
        <h3 class="text-center"><b>Student Performance</b></h3>
<table class="table">
    <thead>
    <tr >
        <th style="width:200px; padding:10px">subject</th><th>C.A</th><th>Exam</th><th>Total</th>    <th>Remark</th> 
</tr>
</thead>
<tbody>

@for($i=0; count($result) > $i; $i++)
@if($result[$i]->subject)
<tr>
<th><b>{{$result[$i]->subject->subject}}</b></th><td>{{$result[$i]->ca_score}}</td><td>{{$result[$i]->exam_score}}</td><td>{{$result[$i]->ca_score + $result[$i]->exam_score}}</td>    <td></td> 
</tr>
@endif

@endfor
<tr>
<th><b>Average</b></th></td><td></td><td></td><td>@if($student_grade) {{$student_grade->average}} @endif</td><td></td> 
</tr>
<tr>
<th><b>Total</b></th></td><td></td><td></td><td>@if($student_grade){{$student_grade->total_score}} @endif</td><td></td> 
</tr>

</tbody>
</table>
    </div>





    <div style="margin-left:50px">

<table class="table mt-2" >
    <tbody>
<tr>
    <th>
        <b>PYSCHO-MOTOR DOMAIN Development</b>
    </th>
    <td>
        5
    </td>
    <td>
        4
    </td>
    <td>
        3
    </td>
    <td>
        2
    </td>
    <td>
        1
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Games & Sport</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Drawing</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>


<tr>
    <th>
        <b>Colouring</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Musical / Singing</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Construction</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>
</tbody>
</table>


<table class="table">
    <tbody>
<tr>
    <th>
        <b>Affective Development</b>
    </th>
    <td>
        5
    </td>
    <td>
        4
    </td>
    <td>
        3
    </td>
    <td>
        2
    </td>
    <td>
        1
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Punctuality</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Neatness</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>


<tr>
    <th>
        <b>Politeness</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Honesty</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>

<tr>
    <th>
        <b>Class participation</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>
<tr>
    <th>
        <b>Friendliness</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>
<tr>
    <th>
        <b>Alertness</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>
<tr>
    <th>
        <b>Obedience to teachers</b>
    </th>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <td>
    </td>
    <tr>
</tr>
</tbody>
</table>


    </div>




</div>
<!-- result data end -->


<!-- result comment data -->
<div>

<table class="table mt-1">
    <tr><th style="width:150px"><b>Class Teacher's Remark</th><td></td></tr>
    <tr><th><b>Class Teacher's Name/Sign</th><td></td></tr>
    <tr><th><b>Head Teacher's Remark</th><td></td></tr>
    <tr><th><b>Head Teacher's Name/Sign</th><td></td></tr>
    <tr><th><b>Parent / Guardian Remark</th><td></td></tr>
</table>
</div>
<!-- result data end -->


</div>





@endsection
