@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-1" style='width:100%'>
            <div class="card-header">
                <h3 class="text-center mt-1">MCA Student Application Portal</h3>
                @php 
if(!$passport){
    $passport = "avatar.png";
}else{
    $passport =$passport->student_passport;    

}
                @endphp
   
                <p class="text-center"><img alt="student passport" style="width:10%" src="{{url('/student_passport/'.$passport)}}" ></p>
                <form action="{{url('/student_passport_upload')}}" method="post" enctype="multipart/form-data" >
                @csrf()
                <input type="file" name="student_passport"  />
                <button onClick("student_passport")>upload</button>
                </form>

        </div>
            <div class="card-body">
           
        
            <table class="table mb-3 mt-3">
                 <tr>
                    <th>Student Name: <th><td>{{$application_data->surname.' '.$application_data->othernames}}</td>
                </tr>
                <tr>
@php 
$academic_session = App\Models\academic_session::where('id', '=', $application_data->academic_session_id)->first();
$term = App\Models\academic_session_term::where('academic_session_id', '=', $application_data->term_id)->first();
$student_reg = App\Models\student_reg_base::where('application_id', '=', $application_data->application_id)->first();
@endphp
                    <th>Academic session applied:<th><td>{{$academic_session->academic_session}}</td>
                </tr>
                <tr>
                    <th>Term:<th><td>{{$term->term}}</td>
                </tr>
                <tr>
                    <th>Student reg:<th><td>{{$student_reg->student_reg}}</td>
                </tr>
                <tr>
                    <th>Application Id<th><td>{{$application_data->application_id}}</td>
                </tr>
                <tr>
                    <th>Application status<th><td>{{$application_data->application_status}}</td>
                </tr>
                <tr>
                    <th>Sex<th><td>{{$application_data->sex}}</td>
                </tr>
                <tr>
                    <th>Date Applied<th><td>{{$application_data->created_at}}</td>
                </tr>
            </table>
                <form action="{{url('/student_data_update')}}" class="w-100 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center" style="color:red">
            @php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            @endphp
    </h6>
    <input type="hidden" value="{{$application_data->application_id}}" name="application_id" >
                    
                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="2" class="form-control" style="width:100%" placeholder="address" >{{$application_data->address}}</textarea>
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian name:</label>
                        <input type="guardian" placeholder="guardian name" name="guardian" class="form-control" style="width:100%" value="{{$application_data->guardian}}">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%" value="{{$application_data->guardian_phone}}">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="2" class="form-control" style="width:100%" placeholder="address">{{$application_data->guardian_address}}</textarea>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Update Application</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

@endsection
