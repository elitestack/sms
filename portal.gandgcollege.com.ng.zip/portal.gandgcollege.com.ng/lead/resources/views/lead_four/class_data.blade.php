@extends('lead_four.master')

@section('content')

<div class="card mx-auto w-100 mt-5">
    
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Assessment Sheet</b></h4>
        <h4 class="mt-2"><b>Academic session:</b> {{$academic_data->academic_session}}</h4>
        <h4 class="mt-2"><b>Academic Term:</b> {{$term->term}}</h4>

    </div>
    <div class="card-body">
    <table class="table mt-3">
        <thead>
            <th>#</th>
            <th>Subject</th>
            <th>Assessment</th>
        </thead>
        <tbody>
            @for($i =0; count($assigned_subject) > $i; $i++)

           @if($assigned_subject)
           <tr>
                <td>{{$i+1}}</td>
                <td>{{$assigned_subject[$i]->subject->subject}}</td>
                
                <td>
                <a href="{{'/lead_four/assessment&class_id='.$assigned_subject[$i]->class_id.'&subject_id='.$assigned_subject[$i]->subject_id.'&academic_session_id='.$academic_data->id.'&term_id='.$term->id}}" target="_blank">Assessment Sheet</a>
                </td>
                </tr>
           @endif
            @endfor
        </tbody>
</table>

    </div>
</div>


@endsection
