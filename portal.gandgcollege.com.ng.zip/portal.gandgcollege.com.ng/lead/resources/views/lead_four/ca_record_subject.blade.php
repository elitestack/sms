@extends('lead_four.master')

@section('content')

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h1 class="text-center mt-2"><b style="color:red">{{$subject->subject->subject}}</b></h1>
        <h5 class="text-center mt-2"><b>{{session()->get('lead_four')}}</b></h5>
    </div>
    <div class="card-body mt-3">
       
    <form action="{{url('/lead_four/ca_record')}}" method="post" >
        @csrf()
        <input type="hidden" value="{{$subject->subject->id}}" name="subject_id" >
        <div class="form-group mt-4">
            <label class="form-label">Select Academic session</label>
            <select class="form-control" name="academic_session_id" >
                @for($i=0; count($academic_session) > $i; $i++)
                <option value="{{$academic_session[$i]->id}}">{{$academic_session[$i]->academic_session}}</option>
                @endfor
</select>
        </div>
        <div class="form-group mt-2">
            <button class="form-control">Fetch Data</button>
        </div>
</form>
    </div>
</div>



@endsection