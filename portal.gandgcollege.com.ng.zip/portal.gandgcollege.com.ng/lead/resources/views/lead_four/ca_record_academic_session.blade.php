@extends('lead_four.master')

@section('content')

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h1 class="text-center mt-2"><b style="color:red">{{$subject->subject->subject}}</b></h1>
        <h2 class="text-center mt-2"><b style="color:red">{{$academic_session->academic_session}}</b></h2>
        <h3 class="text-center mt-2"><b>{{'class: '. $subject->class->class}}</b></h3>
    </div>
    <div class="card-body mt-3">
       
    <form action="{{url('/lead_four/ca_record_start')}}" method="post" >
        @csrf()
        <input type="hidden" value="{{$subject->subject->id}}" name="subject_id" >
        <input type="hidden" value="{{$academic_session->id}}" name="academic_session_id" >

        <div class="form-group mt-4">
            <label class="form-label">Select Academic session term</label>
            <select class="form-control" name="term_id" >
                @for($i=0; count($term) > $i; $i++)
                <option value="{{$term[$i]->id}}">{{$term[$i]->term}}</option>
                @endfor
</select>
        </div>
        <div class="form-group mt-2">
            <button class="form-control">Fetch Data</button>
        </div>
</form>
    </div>
</div>

<div class="card mt-5">
    <div class="card-header">
        <h2 class="text-center mt-3"><b>Previous Data</h2>
    </div>
</div>

@endsection