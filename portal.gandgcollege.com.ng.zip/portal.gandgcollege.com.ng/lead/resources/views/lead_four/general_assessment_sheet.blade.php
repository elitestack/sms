@extends('lead_four.master')

@section('content')
<form method="post" action="{{url('/lead_four/assessment')}}">
    @csrf()
<div class="card mx-auto w-100 mt-5">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>{{$subject->subject->subject}}</b></h4>
        <h4 class="text-center mt-1"><b>Academic session: </b>{{$academic_session->academic_session}}</h4>
        <h4 class="text-center mt-1"><b>Term: </b>{{$term->term}}</h4>
        <h4 class="text-center mt-1"><b>Class: </b>{{$subject->class->class}}</h4>
        @if(session()->has('message'))
        <h4 class="text-center mt-1" style="color:red"><b>{{session()->get('message')}} </b></h4>
        @endif
    </div>
    <div class="card-body">
    <table class="table mt-3">
        <thead>
            <th>#</th>
            <th>Name</th>
            <th>Student reg</th>

            <th>CA</th>
            <th>Exam</th>
        </thead>
        <tbody>
        <input type="hidden" name="student_count" value="{{count($student)}}">
        <input type="hidden" name="subject_id" value="{{$subject->subject->id}}">
        <input type="hidden" name="term_id" value="{{$term->id}}">
        <input type="hidden" name="academic_session_id" value="{{$academic_session->id}}">
        <input type="hidden" name="class_id" value="{{$subject->class->id}}">

            @for($i =0; count($student) > $i; $i++)

            @php 
    $data = App\Models\student_reg_base::with('students')->where('student_reg', '=', $student[$i]->student_reg)->first();
    $student_score =  App\Models\student_ca::where('student_reg', '=', $student[$i]->student_reg)->
    where('academic_session_id', '=', $academic_session->id)->where('term_id', '=', $term->id)->
    where('subject_id', '=', $subject->subject->id)->
    where('class_id', '=', $subject->class->id)->first();
    if(!$student_score){
        $create_score = App\Models\student_ca::create([
            'student_reg' => $student[$i]->student_reg,
            'academic_session_id' => $academic_session->id,
            'term_id' => $term->id,
            'ca_score' => 0,
            'exam_score' => 0,
            'subject_id' => $subject->subject->id,
            'class_id' => $subject->class->id
            ]);

            $student_score =  App\Models\student_ca::where('student_reg', '=', $student[$i]->student_reg)->
    where('academic_session_id', '=', $academic_session->id)->where('term_id', '=', $term->id)->
    where('subject_id', '=', $subject->subject->id)->
    where('class_id', '=', $subject->class->id)->first();
    }
    

    @endphp

@if($data->students)

            
<tr>
<td>{{$i+1}}</td>
    <td>{{$data->students->surname.' '.$data->students->othernames}}</td>
    <td>{{$student[$i]->student_reg}}</td>
    <input type="hidden" name="{{'student_reg_'.$i}}" value="{{$student[$i]->student_reg}}">
    <td><input type="number" name="{{'ca_score_'.$i}}" value="{{$student_score->ca_score}}" style="width:40px"></td>
    <td><input type="number" name="{{'exam_score_'.$i}}" value="{{$student_score->exam_score}}" style="width:40px"></td>
</tr>


@endif
@endfor

    </tbody>
</table>

    </div>
    <div class="card-footer">
        <div class="form-group mt-3">
            <button class="form-control">Save Records</button>
        </div>
    </div>


</div>
    
</form>

@endsection
