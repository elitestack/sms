@extends('lead_four.master')

@section('content')
<div class="card mx-auto w-100 mt-5">

    <div class="card-header">
        <h3 class="text-center">Academic session</h3>
    </div>

    <div class="card-body">
<form action="{{url('/lead_four/student')}}" method="post" class="w-75">
    @csrf()
    <div class="form-group mt-3">
        <label class="form-label">select academic session</label>
        <select class="form-control" name="academic_session_id">
            @for($i=0; count($academic_session) > $i; $i++)
            <option value="{{$academic_session[$i]->id}}">{{$academic_session[$i]->academic_session}}</option>
            @endfor
</select>
<div class="form-group mt-3">
    <button class="form-control">Fetch Data</button>
</div>
</form>
    </div>
</div>






@endsection
