@extends('lead_four.master')

@section('content')





<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
        <h4 class="text-center mt-5"><b>{{$class->class.' student list'}}</b></h4>
        <h2 class="text-center"><b>Academic session: </b>{{$academic_session->academic_session}}</h2>
        <h2 class="text-center"><b>Term: </b>{{$term->term}}</h2>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Student name</th>
                    <th>reg</th>
                    <th>Portal</th>
                </tr>
            </thead>
            <tbody>
                @for($i =0; count($student) > $i; $i++)
                
                @php 
    $data = App\Models\student_reg_base::with('students')->where('student_reg', '=', $student[$i]->student_reg)->first();

    @endphp
    
@if($data->students)
<tr>
    <td>{{$i+1}}</td>
    
    
    

    <td>{{$data->students->surname.' '.$data->students->othernames}}</td>
    <td>{{$student[$i]->student_reg}}</td>
    <td><a href="{{url('/lead_five/dashboard/'.$student[$i]->student_reg)}}" target="_blank">view</a></td>
</tr>
@endif
                @endfor
            </tbody>
            </table>
    </div>

</div>


@endsection