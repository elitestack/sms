@extends('lead_four.master')

@section('content')

<div class="card mx-auto w-100 mt-5">
    <div class="card-header"><h4 class="text-center mt-5"><b>Assigned class</b></h4></div>
    <div class="card-body">
<form method="post" action="{{url('/lead_four/class')}}">
    @csrf()
    <div class="form-group mt-3">
<select class="form-control" name="class_id">
@for($i =0; count($assigned_class) > $i; $i++)
    @if($assigned_class)
            <option value="{{$assigned_class[$i]->class->id}}">{{$assigned_class[$i]->class->class}}</option>
    @endif
@endfor
</select>
    </div>

    <div class="form-group mt-3">
        <button class="form-control">Fetch Class Data</button>
    </div>
</form>
    </div>
</div>


@endsection
