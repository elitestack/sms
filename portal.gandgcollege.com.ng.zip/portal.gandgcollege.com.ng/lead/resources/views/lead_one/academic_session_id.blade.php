@extends('lead_one.master')

@section('content')






<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center mt-3">{{$fetch->academic_session." Academic session"}}</h4>
    </div>
    <div class="card-body">
        <form class="mx-auto mt-3" style="width:80%" action="{{url('/lead_one/create_academic_session_term')}}" method="post">
            @csrf()
            <div class="form-group">
                <input class="form-control" name="term" >
                <input type="hidden" value="{{$academic_session_id}}" name="academic_session_id">
            </div>
            @error('academic_session_term')
                <p style="color:red">{{session()->error('academic_session term')}}</p>
            @enderror
            <div class="form-group mt-2">
                <button class="btn btn-info form-control">Create Academic session Terms</button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-5 mb-5">
    <div class="card-body">
        <table class="table mt-3">
        <h5 class="text-center mt-3">Academic sessions terms</h5>
        <table class="table">
            <thead>
                <tr><th>#</th>
                    <th>Academic session</th><th>term</th><th>Status</th><th>Date</th><th>Action</th>
                         
            </tr>
            </thead>
            <tbody>
                @for($i =0; count($terms) > $i; $i++)
                    <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$fetch->academic_session}}</td>
                    <td>{{$terms[$i]->term}}</td>
                    <td>{{$terms[$i]->term_status}}</td>
                    <td>{{$terms[$i]->created_at}}</td>
                    <td>
                        <form action="{{url('/lead_one/term_status')}}">
                            @csrf()
                            <input type="hidden" name="academic_session_id" value="{{$academic_session_id}}">
                            <div class="form-group">
                                <select name="status" id="" class="form-control">
                                    <option value="publish">publish</option>
                                    <option value="delete">delete</option>
                                    <option value="pending">pending</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-danger">trigger</button>
                            </div>
                        </form>
                    </td>               
</tr>

                @endfor
            </tbody>
        </table>
    </div>
</div>


@endsection