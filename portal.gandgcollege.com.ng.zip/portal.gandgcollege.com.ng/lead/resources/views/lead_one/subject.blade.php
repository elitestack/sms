@extends('lead_one.master')

@section('content')

<div class="card w-75 mx-auto mt-5" >
    <div class="card-header">
        <h4 class="text-center mt-4"><b>Create new subject </b></h4>
    </div>
    <div class="card-body">
        <form method="post" action="{{url('/lead_one/subject')}}">
            @csrf()
            <div class="form-group mt-2">
                <input class="form-control" type="text" name="subject_name">
            </div>
            <div class="form-group mt-2">
                <button class="form-control btn mt-2">Create Subject</button>
            </div>

        </form>
    </div>


<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Subjects</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <!--<th>action</th>-->
            </tr>
            
            </thead>
            <tbody>
                @for($i =0; count($subject) > $i; $i++)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$subject[$i]->subject}}</td>
                    <!--<td><a href="{{url('/lead_one/subject/'.$subject[$i]->id)}}">view</a></td>-->
                </tr>
                @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
