@extends('lead_one.master')


@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-1" style='width:100%'>
            <div class="card-header">
                <h3 class="text-center mt-1">Staff Portal</h3>
            
        </div>
            <div class="card-body">
           
        
            <table class="table mb-3 mt-3">
                 <tr>
                    <th>Staff Name: <th><td>{{session()->get('staff_name')}}</td>
                </tr>
                <tr>
                    <th>Email:<th><td>{{session()->get('staff_email')}}</td>
                </tr>
                <tr>
                    <th>Role: <th><td>{{'Admin '.session()->get('staff_role')}}</td>
                </tr>

            </table>
                <form action="{{url('/staff_data_update')}}" class="w-100 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center" style="color:red">
            @php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            @endphp
    </h6>
                    
                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="2" class="form-control" style="width:100%" placeholder="address" ></textarea>
                        
                    </div>


                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="2" class="form-control" style="width:100%" placeholder="address"></textarea>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%" disabled>Update Data</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>


@endsection

