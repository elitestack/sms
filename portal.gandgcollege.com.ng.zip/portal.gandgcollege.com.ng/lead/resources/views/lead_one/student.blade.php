@extends('lead_one.master')

@section('content')


<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>{{count($student).' students'}}</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>student name</th>
                <th>student reg</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            @for($i =0; count($student) > $i; $i++)
                @if($student[$i]->students)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$student[$i]->students->surname.' '.$student[$i]->students->othernames}}</td>
                    <td>{{$student[$i]->student_reg}}</td>
                    <td><a href="{{url('/lead_five/dashboard/'.$student[$i]->student_reg)}}" target="_blank">view</a></td>

                </tr>
                @endif
        @endfor
            </tbody>
        </table>
    </div>
</div>

@endsection
