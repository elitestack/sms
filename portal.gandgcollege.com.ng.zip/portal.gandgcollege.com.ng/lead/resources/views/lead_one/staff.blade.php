@extends('lead_one.master')

@section('content')




<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staffs</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>Staff name</th>
                <th>Email</th>
                <th>Staff role</th>
                <th>created</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
@for($i=0; count($staff) > $i; $i++)

<tr>
    <td>{{$i+1}}</td>
    <td>{{$staff[$i]->staff_name}}</td>
    <td>{{$staff[$i]->staff_email}}</td>
    <td>{{$staff[$i]->staff_role}}</td>
    <td>{{$staff[$i]->created_at}}</td>
    <td><button class="btn btn-danger">Delete</button></td>
</tr>
@endfor
</tbody>
        </table>
    </div>
</div>

@endsection
