@extends('lead_one.master')

@section('content')






<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center mt-3">Verify Admission</h4>
    </div>
    <div class="card-body">
        <form class="mx-auto mt-3" style="width:80%" action="{{url('/lead_one/admission_verify')}}" method="post">
            @csrf()
            <div class="form-group">
                <input class="form-control" name="application_id">
            </div>
            @error('application_id')
                <p style="color:red">{{session()->error('application_id')}}</p>
            @enderror
            <div class="form-group mt-2">
                <button class="btn btn-info form-control">Verify now</button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-5 mb-5">
    <div class="card-body">
        <table class="table mt-3">
        <h5 class="text-center mt-3" style="color:red"><b>{{count($pending_admission).' Pending Admission' }}</b></h5>
        <table class="table">
            <thead>
                
                <tr><th>#</th><th>Name</th><th>Date</th><th>Action</th>
                         
            </tr>
            </thead>

            <tbody>
    @for($i =0; count($pending_admission) > $i; $i++)

<tr>
    <td>{{$i+1}}</td>
    <td>{{$pending_admission[$i]->surname.' '.$pending_admission[$i]->othernames}}</td>
    <td>{{$pending_admission[$i]->created_at}}</td>
<td><a href="{{url('application/'.$pending_admission[$i]->application_id)}}" target="_blank" ><button class="btn">View</button></a>
</td>

</tr>

    @endfor
            </tbody>
        </table>
    </div>
</div>



@endsection