<div class="side-menu-non" id="side_content">
    <ul class="mt-4" style="list-style: none;">
        <li class="h-5 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/cbt')}}" class="nav-link"><i class="fa-solid fa-home"></i> Dashboard</a></li>
        <li><a href="draftpull.com/about-us" class="nav-link" style="color:black"><i class="fa-solid fa-book"></i> About</a></li>
        
        <li><a href="{{url('/nsuk_cbt/logout')}}" class="nav-link" style="color:black"><i class="fa-solid fa-arrow"></i> logout</a></li>
    </ul>
</div>
