<!--<div class="advert mt-3  w-100 mx-auto mw-100" style="background-color: DodgerBlue; color:white; height:10%">-->
<!--    <h3 class="text-center">-->
<!--        ADS Space-->
<!--        call: +2349039421996</h3>-->
<!--</div>        -->
<!--<div class="advert h-5 mt-3 w-100 mx-auto mw-100" style="background-color: DodgerBlue; color:white">-->
<!--    <h3 class="text-center">CGPGA Calculator</h3>-->
<!--</div>-->
<!--<div class="advert h-5 mt-3 mb-3 w-100 mx-auto mw-100" style="background-color: DodgerBlue; color:white">-->
<!--    <h3 class="text-center">Admin:</h3>-->
<!--    <h6>Tel: +2349039421996</h6>-->
<!--    <h6>Whatsapp: +2349039421996</h6>-->
<!--</div>-->
