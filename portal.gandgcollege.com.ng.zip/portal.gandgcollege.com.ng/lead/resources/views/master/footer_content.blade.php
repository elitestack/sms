<div class="row mt-3">
    <div class="col">
        <a href="https://draftpull.com" class="nav-link"><h5>Home !!</h5></a>
    </div>
    <div class="col">
        <a href="https://draftpull.com/about-us" class="nav-link"><h5>About us</h5></a>
    </div>
    <div class="col">
        <a href="https://draftpull.com/contact-us" class="nav-link"><h5>Support</h5></a>
    </div>
</div>
<div class="row mt-3">
    <div class="row">
<h1 class="text-center"><a href='https://www.youtube.com/@elitesoftwarelab'><img src="{{asset('asset/youtube.webp')}}"  class="w-50" alt=""></a></h1>
    </div>
    <div class="row">
        <h3>Note: you can support us by subscribing your our youtube channel</h3>
        <p>Please this blog is to help students both freshers and returning students in academics</p>
    </div>
    <div class="row">
        <a href="{{url('/contact_us')}}" class="nav-link">Powered By: DPS Lab</a>
    </div>
</div>