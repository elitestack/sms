<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/umd/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="/fontawesome/js/all.js" crossorigin="anonymous"></script>
<style>

body{
  font-size: 12px;
}

table {
  border-collapse: collapse;
}

table, th, td {
  border: 1px solid;
}

.page{
height:297mm;
width:210mm;
padding: 10px 10px 10px 10px;
}

@media print{

  @page{
      size: A4 portrait;
  }
}


</style>
    <title>school portal</title>
</head>
<body >
  <!-- https://ndapplication.fpno.edu.ng/Applicant/Form/PostJambFormInvoiceGeneration -->

    @yield('content')

    
</body>
</html>