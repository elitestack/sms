@extends('lead_five.master')

@section('content')

<div class="card mt-5 w-100">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Student Result</b></h4>
    </div>

    <div class="card-body">
<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Class</th>
            <th>Academic session</th>
            <th>Term</th>
            <th>Action</th>
        </tr>
    </thead>

    <?php for($i=0; count($result) > $i; $i++) {?>
<tr>
    <td>{{$i+1}}</td>
    <td>{{$result[$i]->class->class}}</td>
    <td>{{$result[$i]->academic_session->academic_session}}</td>
        <td>
            @php 
            
            if($result[$i]->term){
            $result[$i]->term->term;            
            }
            
            @endphp
            
        </td>

    <td><a href="{{
url('/result_sheet/academic_session_id='.$result[$i]->academic_session_id.'&term_id='.$result[$i]->term_id.'&class_id='.$result[$i]->class_id.'&student_reg='.$result[$i]->student_reg)
    }}" target="_blank" >
        view</a>
</td>
</tr>
    <?php } ?>
</table>
    </div>
</div>

@endsection
