@extends('student.master.app')

@section('content')

<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('student.master.side_menu')
    </div>


    <!-- php start -->


    <!-- php end -->

<div class="card-expand  mt-5" id="mainbar">

<!-- box start -->
<div class="mt-5">
    <h5 class="text">{{'Welcome '.session()->get('student_reg')}}</h5>
</div>
<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h3 class='text-center'></h3>
                        <h2 class="text-center">GST 111</h2>
                        <form action="" method="post">
                    <input type="hidden" name="cbt_id">
                    <h3 class="text-center"><button class="btn btn-danger">START CBT</button></h3>       
                </form>                        
                            
        </div>
    <div class="box-holder">

        <div class="box">


        <h5 class="text-center"></h5>
        <h2 class="text-center">GST 112</h2>
                <form action="" method="post">
                    <input type="hidden" name="cbt_id">
                    <h3 class="text-center"><button class="btn btn-danger">START CBT</button></h3>       
                </form>
        </div>
    </div>
    <div class="box-holder">
            <div class="box"><h5 class="text-center"></h5>
                
                <h2 class='text-center'>GST 113</h2>
                    
                <form action="" method="post">
                    <input type="hidden" name="cbt_id">
                    <h3 class="text-center"><button class="btn btn-danger">START CBT</button></h3>       
                </form>
            </div>
    </div>
</div>
<!-- end box -->




{{-- ending --}}
</div>
</div>

@endsection