<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="{{asset('/js/jquery.slim.min.js')}}" ></script>
    <script src="{{asset('/js/popper.min.js')}}" ></script>
    <script src="{{asset('/js/bootstrap.bundle.min.js')}}" ></script>
    <script src="{{asset('fontawesome/js/all.js')}}" crossorigin="anonymous"></script>
    <title>CBT Platform</title>
</head>
<body>
<navbar>
    <div class="d-flex justify-items-space-between" style="color:white; line-height:50px; background-color:#ff6347; width:100%;">
    <a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
    <a href="{{url('/student_cbt/logout')}}"  class="nav-link" style="width:100%; color:white"><i class="user-plus"></i>Logout</a>
    </div>
</navbar>
<!-- questions -->
<div class="card mt-5">
    <div class="card-header">
        <h6 class="text-center"><b>Question 1</b></h6>
    </div>
    <div class="card-body">
        <h1 class="text-center">question</h1>
    </div>
</div>

<footer style="background-color: #ff6347; line-height:400px; position:static; width:100%" class="card-header">
    <h6><b>00:00 Minute remaining</b></h6>
</footer>

</body>


</html>