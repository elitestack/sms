@extends('student.master.app')

@section('content')


@php 

$question_count = count($cbt_question);
$answer = App\Models\cbt_answer_data::where('student_reg', '=', session()->get('student_reg'))->where('cbt_data_id', '=', session()->get('cbt_data_id'))->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_type', '=', session()->get('cbt_type'))->count();

@endphp

{{-- statistics card start --}}
<div class="card w-75 mx-auto" style="position:static; margin-top:8%">
    <div class="card-header">
        <h4 class="text-center">CBT EXAM DATA</h4>
    </div>
    <div class="card-body">
       <table class="table">
       <tr>
            <th>Student Name:</th><td>{{session()->get('student_name')}}</td>
        </tr>
       <tr>
            <th>Student Reg:</th><td>{{session()->get('student_reg')}}</td>
        </tr> 
       <tr>
            <th>Subject:</th><td>{{$course->course_name}}</td>
        </tr>
        <tr>
            <?php 

$current_academic_session = App\Models\academic_session::where('academic_session_id', '=', session()->get('academic_session_id'))->first();

            ?>
            <th>Term:</th><td>{{$current_academic_session->academic_session}}</td>
        </tr>
        <tr>
            <th>Time Taken:</th><td>{{session()->get('cbt_duration')."Minutes"}}</td>
        </tr>
        <tr>
            <th>Time Remaining</th><td><h5 style="color:red" id="countdown"></h5></td>
        </tr>
        <tr>
            <th>Total Question:</th><td>{{$question_count.' Total Questions / '.$answer.' Questions answered'}}</td>
        </tr>
        <tr>
            <th>Date Submmitted:</th><td>
                @if($cbt_exam_submit)
                    {{$cbt_exam_submit->created_at}}
                @endif
        
            </td>
        </tr>
        <tr>
            <th>CBT Status</th><td>
                @if(!$cbt_exam_submit)
                <a href="{{url('/student_cbt/cbt_mode')}}"><button class="btn btn-info">Review</button></a>
                @else
                    <button class="btn btn-info">{{'Reviewed'}}</button>
                @endif
            </td><td>
                @if(!$cbt_exam_submit)
                <form action="{{url('/student_cbt/cbt_score_submit')}}" method="post">
                    @csrf()
                    <input type="hidden" name="student_reg" value="{{session()->get('student_reg')}}">
                    <input type="hidden" name="cbt_type" value="{{session()->get('cbt_type')}}">
                    <input type="hidden" name="academic_session_id" value="{{session()->get('academic_session_id')}}">
                    <input type="hidden" name="department_id" value="{{session()->get('department_id')}}">
                    <input type="hidden" name="faculty_id" value="{{session()->get('faculty_id')}}">
                    <input type="hidden" name="cbt_course_id" value="{{$course->course_id}}">
                    <button class="btn btn-danger">Submit</button>
                </form>
                @else
                    <button class="btn btn-danger">{{'Submitted'}}</button>
                @endif
        </td>
        </tr>
       </table>
    </div>
</div>

{{-- </div> --}}


{{-- statistics card end --}}

<!-- if not random type -->
<div class="card mt-5 w-75 mx-auto" style="position:static">
    <div class="card-header">
        <h4 class="text-center">CBT EXAM QUESTIONS SUMMARY</h4>
    </div>
    <div class="card-body">
        <table class="table">
           @for($i=0; $question_count > $i; $i++)
            <tr>
                <th>{{'Question '.$cbt_question[$i]->question_no}}</th>
                @php 
                   $answer = App\Models\cbt_answer_data::where('student_reg', '=', session()->get('student_reg'))->where('cbt_question_id', '=', $cbt_question[$i]->cbt_question_id)->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_type', '=', session()->get('cbt_type'))->first();
                @endphp
                <td>
                    @if($answer)
                        {{'Answered'}}
                    @else(!$answer)
                        {{'Un-Answered'}}
                    @endif
                </td>
            </tr>
            @endfor
        </table>
    </div>
</div>



@endsection