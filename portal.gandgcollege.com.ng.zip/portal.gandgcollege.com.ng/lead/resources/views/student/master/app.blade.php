<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="{{asset('/js/jquery.slim.min.js')}}" ></script>
    <script src="{{asset('/js/popper.min.js')}}" ></script>
    <script src="{{asset('/js/bootstrap.bundle.min.js')}}" ></script>
    <script src="{{asset('fontawesome/js/all.js')}}" crossorigin="anonymous"></script>
    <title>CBT Platform</title>
</head>
<body>
<navbar>
    <div class="d-flex" style="color:white; justify-content:space-between; position:fixed; right:0; bottom:100; top:0; line-height:50px; background-color:#ff6347; width:100%;">
    <a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
    <a href="{{url('/student_cbt/logout')}}"  class="nav-link" style="width:100%; color:white"><i class="user-plus"></i>Logout</a>
    </div>
</navbar>
     
    @yield('content')
</body>
<script>

let countDisplay = document.getElementById("countdown");
const startTime = Number({{session()->get('cbt_duration')}});
// console.log(typeof(startTime));
let time = startTime * 60;
if(localStorage.getItem("{{'time_allow'.session()->get('class_subject').session()->get('cbt_type').session()->get('academic_session_id').session()->get('student_reg')}}")){
    let time_get = localStorage.getItem("{{'time_allow'.session()->get('class_subject').session()->get('cbt_type').session()->get('academic_session_id').session()->get('student_reg')}}");
    time = Number(time_get);
    console.log(typeof(time));
}

if(!localStorage.getItem("{{'time_allow'.session()->get('class_subject').session()->get('cbt_type').session()->get('academic_session_id').session()->get('student_reg')}}")){
    localStorage.setItem("{{'time_allow'.session()->get('class_subject').session()->get('cbt_type').session()->get('academic_session_id').session()->get('student_reg')}}", Number(time));
    let time_get = localStorage.getItem("{{'time_allow'.session()->get('class_subject').session()->get('cbt_type').session()->get('academic_session_id').session()->get('student_reg')}}");
    time = Number(time_get);
    console.log(typeof(time));
}


setInterval(function timer(){ 
    
            const minutes = Math.floor(time / 60);
            let seconds = time % 60;
        
            seconds = seconds < 10 ? '0'+seconds : seconds;

            // time remaining
            countDisplay.innerHTML = `${Number(minutes)}Min: ${Number(seconds)}Secs Time Remaining`;
            if(time > 1){
                localStorage.setItem("{{'time_allow'.session()->get('class_subject').session()->get('cbt_type').session()->get('academic_session_id').session()->get('student_reg')}}", Number(time--));
                time--;
        }           
        if(time < 1){
            countDisplay.innerHTML = `${00}Min: ${00}Secs Time Remaining`;

                                document.getElementById('data-form').submit();
        }            
        
    }, 1000);

</script>


</html>