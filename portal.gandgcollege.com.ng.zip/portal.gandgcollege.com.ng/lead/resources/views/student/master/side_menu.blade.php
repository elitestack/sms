<div class="side-menu-non" id="side_content">
    <ul class="mt-4" style="list-style: none;">
        <li class="h-5 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/student_cbt/welcome')}}" class="nav-link"><i class="fa-solid fa-home"></i> Dashboard</a></li>
        <li><a href="{{url('/student_cbt/logout')}}" class="nav-link" style="color:black"><i class="fa-solid fa-book"></i> Logout</a></li>
        
    </ul>
</div>
