@extends('student.master.app')

@section('content')


@php 

$question_count = count($cbt_question);

@endphp

<div class="card w-75 mx-auto" style="position:static; margin-top:10%">
    <div class="card-header">
        <table class="table">
                <tr>
                    <th>Subject:</th><td>{{$course->course_name}}</td>
                </tr>
                <tr>
                    <th>Student Name:</th><td>{{session()->get('student_name')}}</td>
                </tr>
                <tr>
                    <th>Student Reg:</th><td>{{session()->get('student_reg')}}</td>
                </tr>
            </table>
    </div>
</div>

            <form action="{{url('/student_cbt/cbt_mode_submit')}}" method="post" class="w-75 mx-auto rounded" id="data-form" >
                    @csrf
                    <input type="hidden" name="cbt_set_id" value="{{session()->get('cbt_data_id')}}">
                    <input type="hidden" name="cbt_data_id" value="{{session()->get('cbt_data_id')}}">
                    <input type="hidden" name="cbt_question" value="{{$question_count}}">
                    <input type="hidden" name="student_reg" value="{{session()->get('student_reg')}}">
                    <input type="hidden" name="faculty_id" value="{{session()->get('faculty_id')}}">
                    <input type="hidden" name="department_id" value="{{session()->get('department_id')}}">
                    @for($i =0; $question_count > $i; $i++)    
    <div class="card mt-3" style="position:static">
            <div class="card-header"><h6 class="text-center">{{'CBT Question '.$i+1}}</h6></div>
                    
            <?php 
                $fetch_all_images = App\Models\cbt_question_image::where('cbt_question_id', '=', $cbt_question[$i]->cbt_question_id)->get();
            ?>
            </div>
    <div class="card-body">

@foreach($fetch_all_images as $image)
                            <div class="form-group mt-1">
                                    @csrf
                                    <h1 class="text-center"><img style="width:35%" src="{{asset('/question_images/'.$image->image_name)}}" alt="" srcset=""></h1>
                                    <h6 class="text-center">{{$image->image_title}}</h6>
                            </div>
@endforeach

                        <div class="form-group mt-2 mb-3">
                        @php echo $cbt_question[$i]->cbt_question; @endphp
                        </div>
                        <input type="hidden" name="{{'cbt_question_id_'.$i}}" id="cbt_question_id" value="{{$cbt_question[$i]->cbt_question_id}}">

                        @foreach($cbt_question[$i]->cbt_student_answer as $cbt_answer)
                        <div class="form-group">
                            
                            <input type="radio" name="{{'cbt_answer_'.$i}}" class="mt-2 mb-2" value="{{$cbt_answer->option_label_id}}" id="<?php 
                            // student answer

                            // answer database
                            $previous_answer_check = App\Models\cbt_answer_data::where('cbt_question_id', '=', $cbt_question[$i]->cbt_question_id)->where('student_reg', '=', session()->get('student_reg'))->where('academic_session_id', '=', session()->get('academic_session_id'))->where('cbt_type', '=', session()->get('cbt_type'))->where('cbt_data_id', '=', session()->get('cbt_data_id'))->where('cbt_option_id', '=', $cbt_answer->option_label_id)->first();
                                                   
                            // dd($previous_answer_check);
                            if($previous_answer_check){

                                echo 'q'.$i+1;}
                       ?>">
                        <label for=""><?php 
                        
                        echo $cbt_answer->option_label_id.'.'.'  '.$cbt_answer->options;
                        ?></label>

       
                    </div>
                    @endforeach
</div>   
                    @endfor
                    <div class="mt-3" style="display:flex;  margin-bottom:10%; justify-content:space-between">
                            <button type="submit" style="width:100%; padding:10px" class="btn btn-danger">Submit</button>
                </div>

                </form>


    {{-- statistics card start --}}
    <footer class="mt-5" style="position:fixed; bottom:0; right:0; background-color: #ff6347; line-height:400px; width:100%" class="card-header">
    <h4 class="text-center" style="color:white"><b id="countdown"></b></h4>
                    <h4 class="text-center" style="color:white" id="question_id" style="margin-left:20px"> {{$question_count.' Questions'}}</h4>
</footer>

{{-- statistics card end --}}



<script>
review_cbt();
function review_cbt(){

let q1 = document.getElementById('q1');
q1.checked = true;

let q2 = document.getElementById('q2');
q2.checked = true;

let q3 = document.getElementById('q3');
q3.checked = true;

let q4 = document.getElementById('q4');
q4.checked = true;
let q5 = document.getElementById('q5');
q5.checked = true;

let q6 = document.getElementById('q6');
q6.checked = true;

let q7 = document.getElementById('q7');
q7.checked = true;
let q8 = document.getElementById('q8');
q8.checked = true;

let q9 = document.getElementById('q9');
q9.checked = true;

let q10 = document.getElementById('q10');
q10.checked = true;

let q11 = document.getElementById('q11');
q11.checked = true;

let q12 = document.getElementById('q12');
q12.checked = true;

let q13 = document.getElementById('q13');
q13.checked = true;

let q14 = document.getElementById('q14');
q14.checked = true;

let q15 = document.getElementById('q15');
q15.checked = true;

let q16 = document.getElementById('q16');
q16.checked = true;

let q17 = document.getElementById('q17');
q17.checked = true;

let q18 = document.getElementById('q18');
q18.checked = true;

let q19 = document.getElementById('q19');
q19.checked = true;

let q20 = document.getElementById('q20');
q20.checked = true;

let q21 = document.getElementById('q21');
q21.checked = true;

let q22 = document.getElementById('q22');
q22.checked = true;

let q23 = document.getElementById('q23');
q23.checked = true;

let q24 = document.getElementById('q24');
q24.checked = true;

let q25 = document.getElementById('q25');
q25.checked = true;

let q26 = document.getElementById('q26');
q26.checked = true;

let q27 = document.getElementById('q27');
q27.checked = true;

let q28 = document.getElementById('q28');
q28.checked = true;

let q29 = document.getElementById('q29');
q29.checked = true;

let q30 = document.getElementById('q30');
q30.checked = true;

let q31 = document.getElementById('q31');
q31.checked = true;

let q32 = document.getElementById('q32');
q32.checked = true;

let q33 = document.getElementById('q33');
q33.checked = true;

let q34 = document.getElementById('q34');
q34.checked = true;

let q35 = document.getElementById('q35');
q35.checked = true;

let q36 = document.getElementById('q36');
q36.checked = true;

let q37 = document.getElementById('q37');
q37.checked = true;

let q38 = document.getElementById('q38');
q38.checked = true;

let q39 = document.getElementById('q39');
q39.checked = true;

let q40 = document.getElementById('q40');
q40.checked = true;

let q41 = document.getElementById('q41');
q41.checked = true;

let q42 = document.getElementById('q42');
q42.checked = true;

let q43 = document.getElementById('q43');
q43.checked = true;

let q44 = document.getElementById('q44');
q44.checked = true;

let q45 = document.getElementById('q45');
q45.checked = true;

let q46 = document.getElementById('q46');
q46.checked = true;

let q47 = document.getElementById('q47');
q47.checked = true;

let q48 = document.getElementById('q48');
q48.checked = true;

let q49 = document.getElementById('q49');
q49.checked = true;

let q50 = document.getElementById('q50');
q50.checked = true;

let q51 = document.getElementById('q51');
q51.checked = true;

let q52 = document.getElementById('q52');
q52.checked = true;

let q53 = document.getElementById('q53');
q53.checked = true;

let q54 = document.getElementById('q54');
q54.checked = true;

let q55 = document.getElementById('q55');
q55.checked = true;

let q56 = document.getElementById('q56');
q56.checked = true;

let q57 = document.getElementById('q57');
q57.checked = true;

let q58 = document.getElementById('q58');
q58.checked = true;

let q59 = document.getElementById('q59');
q59.checked = true;

let q60 = document.getElementById('q60');
q60.checked = true;

let q61 = document.getElementById('q61');
q61.checked = true;

let q62 = document.getElementById('q62');
q62.checked = true;

let q63 = document.getElementById('q63');
q63.checked = true;

let q64 = document.getElementById('q64');
q64.checked = true;

let q65 = document.getElementById('q65');
q65.checked = true;

let q66 = document.getElementById('q66');
q66.checked = true;

let q67 = document.getElementById('q67');
q67.checked = true;

let q68 = document.getElementById('q68');
q68.checked = true;

let q69 = document.getElementById('q69');
q69.checked = true;

let q70 = document.getElementById('q70');
q70.checked = true;

let q71 = document.getElementById('q71');
q71.checked = true;

let q72 = document.getElementById('q72');
q72.checked = true;

let q73 = document.getElementById('q73');
q73.checked = true;

let q74 = document.getElementById('q74');
q74.checked = true;

let q75 = document.getElementById('q75');
q75.checked = true;

let q76 = document.getElementById('q76');
q76.checked = true;

let q77 = document.getElementById('q77');
q77.checked = true;

let q78 = document.getElementById('q78');
q78.checked = true;

let q79 = document.getElementById('q79');
q79.checked = true;

let q80 = document.getElementById('q80');
q80.checked = true;

let q81 = document.getElementById('q81');
q81.checked = true;

let q82 = document.getElementById('q82');
q82.checked = true;

let q83 = document.getElementById('q83');
q83.checked = true;

let q84 = document.getElementById('q84');
q84.checked = true;

let q85 = document.getElementById('q85');
q85.checked = true;

let q86 = document.getElementById('q86');
q86.checked = true;

let q87 = document.getElementById('q87');
q87.checked = true;

let q88 = document.getElementById('q88');
q88.checked = true;

let q89 = document.getElementById('q89');
q89.checked = true;

let q90 = document.getElementById('q90');
q90.checked = true;

let q91 = document.getElementById('q91');
q91.checked = true;

let q92 = document.getElementById('q92');
q92.checked = true;

let q93 = document.getElementById('q93');
q93.checked = true;

let q94 = document.getElementById('q94');
q94.checked = true;

let q95 = document.getElementById('q95');
q95.checked = true;

let q96 = document.getElementById('q96');
q96.checked = true;

let q97 = document.getElementById('q97');
q97.checked = true;

let q98 = document.getElementById('q98');
q98.checked = true;

let q99 = document.getElementById('q99');
q99.checked = true;

let q100 = document.getElementById('q100');
q100.checked = true;














}

</script>


@endsection
