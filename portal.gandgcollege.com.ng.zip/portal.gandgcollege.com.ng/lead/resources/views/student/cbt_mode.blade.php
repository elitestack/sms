@extends('student.master.app')

@section('content')
{{-- <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
<a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
</div> --}}
<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('student.master.side_menu')
    </div>

@php 

$question_count = count($cbt_question);

@endphp


<div class="card-expand  mt-5" id="mainbar">

<div class="exam-master" style="width:100%">
    <!-- master start -->
    
    <div class="exam-holder" style="width:70%">
        <!-- exam holder start -->
            <div class="card-body">

                <form action="{{url('/student_cbt/cbt_mode_submit')}}" method="post" class="w-75 mx-auto rounded mt-3" >
                    @csrf
                    @for($i =0; $question_count > $i; $i++)    
                    <div class="question_group mt-5" id="question_group">
                    <h6 class="text-center">{{'CBT Question '.$i+1}}</h6>
                        <div class="form-group">
                        <h4 class="text">{{$cbt_question[$i]->cbt_question}}</h4>
                        </div>
                        <input type="hidden" name="cbt_question_id" id="cbt_question_id">
                        <input type="hidden" name="cbt_data_id" id="cbt_data_id">
                        @foreach($cbt_question[$i]->cbt_student_answer as $cbt_answer)
                        <div class="form-group">
                        <input type="hidden" name="cbt_option_id" id="cbt_option_id">
                        
                        <input type="radio" id="cbt_answer" name="cbt_answer">
                        <label for="">{{$cbt_answer->options}}</label>
                    </div>
                        @endforeach
                        </div>   
                    @endfor
                    <div class="mt-3" style="display:flex; justify-content:space-between">
                <button class="btn btn-danger" onclick="prev_next_step(-1)" id="previous">Previous</button>
                            <button class="btn btn-danger" id="next" onclick="prev_next_step(1)">Next</button>

                </div>

                </form>
        </div>

            <!-- question start -->
    <div>


    <div class="exam-holder" style="width:30%">
        <!-- exam holder start -->


        {{-- statistics card start --}}
            <div class="card mt-5" style="position:static; width:100%; margin-left:8px;">
                <div class="card-header">

                    <h4 class="text-center" id="question_id"> {{$question_count}}</h4>
                </div>
                <div class="card-body">
                <div class="question-holder-number">
                        <div class="question-number">
                        @for($i =0; $question_count > $i; $i++)    
                            <button class="btn btn-danger mt-2" style="margin-left: 5px" id="custom_number" onclick="@php 
                            echo 'question_'.$i.'()'
                            @endphp
                            
                            ">{{$i+1}}</button>
                        @endfor
                        </div>
                </div>
                </div>
            </div>



            {{-- statistics card end --}}
        <!-- exam holder end -->

    </div>
     

    <!-- master end -->
</div>




{{-- ending --}}
</div>
</div>

<script>

    let question_group = document.getElementsByClassName('question_group');

    let firstTab = 0;

    group_step(firstTab);

    function group_step(n){
        // get the grouping id and make it visible
        question_group[n].style.display = "block";

        // next or previous button control
        let previous_button = document.getElementById('previous');
        let next_button = document.getElementById('next');
        if(n == 0){
            // hide the previous button 
            
            previous_button.style.display = "none";
        }else{
            // showing the previous, if the result is not equal to zero
            previous_button.style.display = "inline";
        }

        // checking for the last question group
        if(n == (question_group.length - 1)){
            // if the it the total length
            next_button.innerHtml = "Finished"
        }else{
            next_button.innerHtml = "Next"
        }
    }

    // tab number adder

    function prev_next_step(n){

        // hiding the first tab
        question_group[firstTab].style.display = 'none';
        // get the group id
        // question_group[n].style.display = 'block';

        // adding the current number to firstTab

        firstTab = n + firstTab;

        if(firstTab >= (question_group.length - 1)){

            group_step(firstTab);

        }

        group_step(firstTab);
    }

    let cbt_answer = document.getElementById('cbt_answer');

    function answer_click(){
        console.log(cbt_answer.value);
    }

</script>

<script>


@endsection
