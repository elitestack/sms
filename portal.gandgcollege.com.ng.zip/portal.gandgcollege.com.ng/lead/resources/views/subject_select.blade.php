@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  
    <?php 

$class = App\Models\faculty::all();

    ?>

        <div class="card mx-auto mt-5" style='width:45%'>
            <div class="card-header">
        <h1 class="text-center"><img src="{{asset('/asset/nsuk.png')}}" alt="" style="width:15%"></h1>
                <h3 class="text-center">CBT Portal</h3>
                
                <h3 class="text-center">Select Subject to continue!!!</h3>
                
            </div>
            <div class="card-body">
        
                <form action="{{url('/subject_select_process')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h3 class="text-center"><?php session()->get('message') ?></h3>
                    <?php 
                    // active cbt session 

                    $current_academic_session = App\Models\academic_session::where('session_status', '=', 'activated')->first();

                    session()->put('academic_session_id', $current_academic_session->academic_session_id);
                    // check current cbt permission // fetching all activated courses with current academic session based on current permission level e.g. c.a or exam
                    $cbt_type = App\Models\current_open_cbt::where('academic_session', '=', $current_academic_session->academic_session_id)->where('status', '=', 'open')->first();    
                    
                    // staff to deactivated a course after it was written to avoid been displayed to students
                    if($cbt_type){
                         //fetching all activated courses 
$activated_courses = App\Models\activate_course::where('academic_session_id', '=', $current_academic_session->academic_session_id)->where('cbt_type', '=', $cbt_type->cbt_type)->where('status', '=', 'opened')->get();
                   
                       
                   ?>

<div class="form-group">
                        <label for="" class="form-label">Subject:</label>
                        <select name="class_subject" id="course_fetch" class="form-control">
                            <option value="none">Select subject</option>
                            @for($i=0; count($activated_courses) > $i; $i++)
    <?php 
$course_data = App\Models\cbt_course::where('course_id', '=', $activated_courses[$i]->course_id)->first();

    ?>
    @if($course_data)
    <option value="{{$activated_courses[$i]->course_id}}">
        {{$course_data->course_name}}
        </option>
    @endif
                            @endfor
                            
                        </select>
                    </div>

                    <?php

                }                    



// dd(session()->get('student_class'));

                    ?>





                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Start</button>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <h6 class="text"></h6>
            </div>
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

<script>
    
</script>

@endsection
