@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:80%'>
            <div class="card-header">
        <h1 class="text-center"><a href="{{url('/')}}"><img src="{{asset('/asset/icon.webp')}}" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">MCA Student Application Portal</h3>
            </div>
            <div class="card-body">
                    @for($i=0; count($applicated_associated) > $i; $i++)
<a href="{{url('/application/'.$applicated_associated[$i]->application_id)}}" target="_blank"><button class="btn btn-danger">{{$applicated_associated[$i]->application_id}}</button></a>
                    @endfor
            </div>
            
        </div>
        

        

    </div>
    {{-- side bar --}}
</div>

@endsection
