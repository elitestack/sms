@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5 card-size" >
            <div class="card-header">
        <h1 class="text-center"><a href="https://gandgcollege.com.ng"><img src="{{asset('/images/logo.jpeg')}}" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">GandG Student Portal</h3>
                
                
            </div>
            <div class="card-body">
        
                <form action="{{url('/student_login')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center" style="color:red">
            @php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            @endphp
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Student reg:</label>
                        <input type="text" name="student_reg" placeholder="student reg" class="form-control" style="width:100%" >
                        @error('student_reg')
                        <p>please enter your email</p>
                        @enderror
                    </div>


                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:green; color:white; width:100%">Login</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

@endsection
