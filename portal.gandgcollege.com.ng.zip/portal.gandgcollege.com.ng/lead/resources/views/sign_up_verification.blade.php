@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:45%'>
            <div class="card-header">
        <h1 class="text-center"><img src="{{asset('/asset/nsuk.png')}}" alt="" style="width:15%"></h1>
                <h3 class="text-center">Nasrawa State University CBT Portal</h3>
                
                <h3 class="text-center">Login to have access !!!</h3>
                
            </div>
            <div class="card-body">
        
                <form action="{{url('/password_set')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center">
            @if(session()->has('message'))

                {{session()->get('message')}}
            @endif
        </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Password:</label>
                        <input type="password" name="password" class="form-control" style="width:100%">
                        <span>
                            @error('password')
                                <h6 >Password required</h6>
                            @enderror
                        </span>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Confirm Password:</label>
                        <input type="password" name="confirm_password" class="form-control" style="width:100%">
                        <input type="hidden" name="reg_code" value="{{$validate_id}}">
                        <input type="hidden" name="session_id" value="{{$session_id}}">
                        <input type="hidden" name="email" value="{{$staff_id}}">
                        <span>
                            @error('confirm_password')
                                <h6 class="text-">Confirm password required</h6>
                            @enderror
                        </span>
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Finish Set Up</button>
                    </div>
                    <p class="mt-3">Already have account, <a style="color:blue; text-decoration:none" href="{{url('/nsuk_cbt_create_account')}}">Register !!!</a></p>
                </form>
            </div>
            <div class="card-footer">
                <h6 class="text">Note: create new account by collecting registration code from your unit</h6>
            </div>
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

@endsection
