@extends('lead_three.master')

@section('content')





<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
    <table class="table">
            <tr>
                <th>Academic session:</th><td style="color:red">{{$academic_session->academic_session}}</td>
            </tr>
            
</table>
    </div>
    <div class="card-body">
        <form action="{{url('/lead_three/fetch_student_term')}}" method="post">
            @csrf()
          <input type="hidden" value="{{$academic_session->id}}" name="academic_session_id">
            <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    @for($i=0; count($class) > $i; $i++)
                    <option value="{{$class[$i]->id}}">{{$class[$i]->class}}</opion>
                @endfor
                </select>
            </div>
            <div class="form-group mt-3">
                <label class="form-label">Term</label>
                <select class="form-control" name="term_id">
                    @for($i=0; count($term) > $i; $i++)
                    <option value="{{$term[$i]->id}}">{{$term[$i]->term}}</opion>
                @endfor
                </select>
            </div>

            <div class="form-group mt-3">
                <button class="form-control">Fetch Student</button>
            </div>
        </form>
    </div>

</div>


@endsection