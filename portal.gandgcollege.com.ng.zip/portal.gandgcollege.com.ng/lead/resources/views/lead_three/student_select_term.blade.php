@extends('lead_three.master')

@section('content')

<div class="card mt-5 mx-auto w-100">
    <div class="card-header">
        <h4 class="text-center mt-3"><b>Student Data</b></h4>
    </div>
    <div class="card-body">
        <table class="table">
            <tr>
                <th>Student reg:</th><td>{{$student->student_reg}}</td>
            </tr>
            <tr>
                <th>Surname:</th><td>{{$student->students->surname}}</td>
            </tr>
            <tr>
                <th>Othernames:</th><td>{{$student->students->othernames}}</td>
            </tr>

            <tr>
                <th>Academic session: </th><td>{{$academic_session->academic_session}}</td>
            </tr>
            <tr>
                <th>Assign Class: </th><td>{{$class->class}}</td>
            </tr>

            <tr>
                <th>Student portal</th><td><a href="{{url('/lead_five/dashboard/'.$student->student_reg)}}" target="_blank">view</a></td>
            </tr>

        </table>
    </div>

</div>



<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
        <h4 class="text-center mt-3"><b>Select Session</b></h4>
    </div>
    <div class="card-body">
        <form action="{{url('/lead_three/add_student_confirm')}}" method="post">
            @csrf()
           <input type="hidden" value="{{$student->student_reg}}" name="student_reg" >
           <input type="hidden" value="{{$academic_session->id}}" name="academic_session_id" >
           <input type="hidden" value="{{$class->id}}" name="class_id" >
            <div class="form-group mt-3">
                <label class="form-label">Term</label>
                <select class="form-control" name="term_id">
                    @for($i=0; count($term) > $i; $i++)
                    <option value="{{$term[$i]->id}}">{{$term[$i]->term}}</opion>
                @endfor
                </select>
            </div>
            

            <div class="form-group mt-3">
                <button class="form-control">Confirm Data</button>
            </div>
        </form>
    </div>

</div>


@endsection