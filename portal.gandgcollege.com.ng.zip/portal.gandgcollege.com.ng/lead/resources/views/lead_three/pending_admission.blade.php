@extends('lead_three.master')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:80%'>
            <div class="card-header">
        <h1 class="text-center"><a href="{{url('/')}}"><img src="{{asset('/images/logo.jpeg')}}" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">Student Application</h3>
                @php 
if(!$passport){
    $passport = "avatar.png";
}else{
    $passport =$passport->student_passport;    

}
                @endphp
   
                <p class="text-center"><img alt="student passport" style="width:25%" src="{{url('/student_passport/'.$passport)}}" ></p>
            

                <script>
                    function student_passport(e){

                        e.preventDefault();

                        alert("am working");
                    }
                </script>
            </div>
            <div class="card-body">
        
            <table class="table mb-3 mt-3">
 
                <tr>
                    <th>Application Id<th><td>{{$application_data->application_id}}</td>
                </tr>
                <tr>
                    <th>Application session<th><td>{{$academic_session}}</td>
                </tr>
                <tr>
                    <th>Application status<th><td>{{$application_data->application_status}}</td>
                </tr>
                <tr>
                    <th>Date<th><td>{{$application_data->created_at}}</td>
                </tr>
            </table>
                <form action="{{url('/lead_three/student_application_approve')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h6 class="text-center" style="color:red">
            @php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            @endphp
    </h6>
    <input type="hidden" name="application_id" value="{{$application_data->application_id}}" >
        <input type="hidden" name="acadmic_session_id" value="{{$application_data->academic_session_id}}" >
                    <div class="form-group">
                        <label for="" class="form-label">Surname</label>
                        <input type="surname" name="surname" placeholder="student surname" class="form-control" style="width:100%" value="{{$application_data->surname}}">
                       
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Othernames:</label>
                        <input type="text" placeholder="othernames" name="othernames" class="form-control" style="width:100%" value="{{$application_data->othernames}}">
                       
                    </div>
                    <div class="form-group">
                        <label for="" class="form-label">Sex:</label>

                        @error('sex')
                        <p>please enter your sex</p><br>
                        @enderror
                    <select name="sex" class="form-control" >
                        <option value="{{session()->get('sex')}}">{{session()->get('sex')}}</option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>    
                    </div>
                    
                    
                <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    @if($current_class)
                                        <option value="{{$current_class->id}}">{{$current_class->class}}</opion>
                    @endif
                    @for($i =0; count($class) > $i; $i++)
                    <option value="{{$class[$i]->id}}">{{$class[$i]->class}}</opion>
                   @endfor
                  
                </select>
                @error('class_id')
                   <p style="color:red">Please select class</p>
                   @enderror
            </div>
                        <div class="form-group mt-3">
                <label class="form-label">Term</label>
                <select class="form-control" name="term_id">
                    @for($i=0; count($term) > $i; $i++)
                    <option value="{{$term[$i]->id}}">{{$term[$i]->term}}</opion>
                @endfor
                </select>
            </div>

                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="10" class="form-control" style="width:100%" placeholder="address" >{{$application_data->address}}</textarea>
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian name:</label>
                        <input type="guardian" placeholder="guardian name" name="guardian" class="form-control" style="width:100%" value="{{$application_data->guardian}}">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%" value="{{$application_data->guardian_phone}}">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="10" class="form-control" style="width:100%" placeholder="address">{{$application_data->guardian_address}}</textarea>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:green; color:white; width:100%">Aprove Application</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
@endsection