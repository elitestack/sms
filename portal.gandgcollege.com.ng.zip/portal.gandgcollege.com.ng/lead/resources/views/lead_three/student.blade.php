@extends('lead_three.master')

@section('content')


<div class="card mt-5 mx-auto w-100">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Student Data</b></h4>
    </div>
    <div class="card-body mt-3">
        <form method="post" action="{{url('/lead_three/student_view')}}">
            @csrf()
            <div class="form-group">
                <label class="form-label">Select Academic session</label>
                <select class="form-control" name="academic_session_id">
                    @for($i=0; count($academic_session) > $i; $i++)
                    <option value="{{$academic_session[$i]->id}}">{{$academic_session[$i]->academic_session}}</opion>
                   @endfor
                </select>
            </div>
            <div class="form-group mt-3">
                <button class="form-control">Fetch student</button>
            </div>
        </form>
    </div>

</div>
<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
        <h4 class="text-center mt-3"><b>Add student to class room</b></h4>
        @if(session()->has('message'))
            <h4 class="text-center" style="color:red">{{session()->get('message')}}</h4>
        @endif
    </div>
    <div class="card-body">
        <form action="{{url('/lead_three/add_student')}}" method="post">
            @csrf()
            <div class="form-group mt-3">
                <label class="form-label">Student reg</label>
                <input class="form-control" name="student_reg">
                @error('student_reg')
                   <p style="color:red">enter student reg</p>
                   @enderror
            </div>
            <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    @for($i =0; count($class) > $i; $i++)
                    <option value="{{$class[$i]->id}}">{{$class[$i]->class}}</opion>
                   @endfor
                  
                </select>
                @error('class_id')
                   <p style="color:red">Please select class</p>
                   @enderror
            </div>
            <div class="form-group mt-3" id="term">
                <label class="form-label">Academic session</label>
                <select class="form-control" name="academic_session_id">
                    @for($i=0; count($academic_session) > $i; $i++)
                    <option value="{{$academic_session[$i]->id}}">{{$academic_session[$i]->academic_session}}</opion>
                   @endfor
                </select>
                @error('academic_session_id')
                   <p style="color:red">Please select academic session</p>
                   @enderror
            </div>

            <div class="form-group mt-3">
                <button class="form-control">Add student</button>
            </div>
        </form>
    </div>

</div>


<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>{{count($student).' total students'}}</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>student name</th>
                <th>student reg</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            @for($i =0; count($student) > $i; $i++)
                @if($student[$i]->students)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$student[$i]->students->surname.' '.$student[$i]->students->othernames}}</td>
                    <td>{{$student[$i]->student_reg}}</td>
                    <td><a href="{{url('/lead_five/dashboard/'.$student[$i]->student_reg)}}" target="_blank">view</a></td>

                </tr>
                @endif
        @endfor
            </tbody>
        </table>
    </div>
</div>


@endsection