@extends('master.app_two')

@section('content')
<div class="w-100">
    <div class="main mt-5">
  
    <?php 

$class = App\Models\faculty::all();

    ?>

        <div class="card mx-auto mt-5" style='width:45%'>
            <div class="card-header">
        <h1 class="text-center"><img src="{{asset('/asset/nsuk.png')}}" alt="" style="width:15%"></h1>
                <h3 class="text-center">CBT Portal</h3>
                
                <h3 class="text-center">Select Subject to continue!!!</h3>
                
            </div>
            <div class="card-body">
        
                <form action="{{url('/student_cbt_start_process')}}" class="w-85 mx-auto rounded" method="post">
         @csrf
            
         <h3 class="text-center"><?php session()->get('message') ?></h3>
                    <?php 
$data = $class = App\Models\department::where('faculty_id', '=', session()->get('student_class'))->get();

// dd(session()->get('student_class'));

                    ?>

                    <div class="form-group">
                        <label for="" class="form-label">Section:</label>
                        <select name="class_section" id="course_fetch" class="form-control">
                            <option value="none">Select section</option>
                            @foreach($data as $datas)
<option value="{{$datas->department_id}}">{{$datas->department_name}}</option>
                            @endforeach
                            
                        </select>
                        <span>
                            @error('student_reg')
                                
                            @enderror
                        </span>
                    </div>



                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Proceed !!!</button>
                    </div>
                </form>
            </div>
            <div class="card-footer">
                <h6 class="text"></h6>
            </div>
        </div>
        
        <section>
        
    </div>
    {{-- side bar --}}
</div>

<script>
    
</script>

@endsection
