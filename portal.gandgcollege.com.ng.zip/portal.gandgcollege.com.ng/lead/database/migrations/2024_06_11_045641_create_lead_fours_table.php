<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {

        Schema::create('subject', function (Blueprint $table) {
            $table->id();
            $table->text('subject');
            $table->timestamps();
        });


        Schema::create('student_ca', function (Blueprint $table) {
            $table->id();
            $table->text('student_reg');
            $table->text('subject_id');
            $table->text('score');
            $table->text('ca_id');
            $table->text('class_id');
            $table->text('term_id');
            $table->text('academic_session_id');
            $table->timestamps();
        });

        Schema::create('class_student_records', function (Blueprint $table) {
            $table->id();
            $table->text('student_reg');
            $table->text('class_id');
            $table->text('term_id');
            $table->text('academic_session_id');
            $table->timestamps();
        });


        Schema::create('student_grade_records', function (Blueprint $table) {
            $table->id();
            $table->text('student_reg');
            $table->text('class_id');
            $table->text('term_id');
            $table->text('academic_session_id');
            $table->text('total_score');
            $table->text('position');
            $table->text('average');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lead_fours');
    }
};
