<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('student_data', function (Blueprint $table) {
            $table->id();
            $table->text('student_reg');
            $table->text('surname');
            $table->text('othernames');
            $table->text('pending_student_id');
            $table->text('sex');
            $table->text('address');
            $table->text('academic_session_id');
            $table->text('term_id');
            $table->text('gurdian');
            $table->text('guardian_address');
            $table->text('guardian_phone');
            $table->timestamps();
        });
        

        Schema::create('pending_student_data', function (Blueprint $table) {
            $table->id();
            $table->text('surname');
            $table->text('othernames');
            $table->text('sex');
            $table->text('address');
            $table->text('academic_session_id');
            $table->text('term_id');
            $table->text('guardian');
            $table->text('guardian_address');
            $table->text('guardian_phone');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lead_fives');
    }
};
