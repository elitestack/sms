<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('staff_reg_permission', function (Blueprint $table) {
            $table->id();
            $table->text('user_id');
            $table->text('staff_role');
            $table->timestamps();
        });

        Schema::create('previous_staff_reg_permission', function (Blueprint $table) {
            $table->id();
            $table->text('user_id');
            $table->text('staff_role');
            $table->timestamps();
        });


        Schema::create('staff_login', function (Blueprint $table) {
            $table->id();
            $table->text('surname');
            $table->text('name');
            $table->text('user_id');
            $table->text('password');
            $table->timestamps();
        });

        Schema::create('academic_session', function (Blueprint $table) {
            $table->id();
            $table->text('academic_session');
            $table->text('academic_session_status');
            $table->text('user_id');
            $table->timestamps();
        });

        Schema::create('term', function (Blueprint $table) {
            $table->id();
            $table->text('term');
            $table->text('academic_session_id');
            $table->text('user_id');
            $table->timestamps();
        });

        Schema::create('term_activities', function (Blueprint $table) {
            $table->id();
            $table->text('academic_session_id');
            $table->text('activities');
            $table->text('term_id');
            $table->text('user_id');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('lead_ones');
    }
};
