

<?php $__env->startSection('content'); ?>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Add Subject</b></h4>
        <?php if(session()->has('message')): ?>
            <p class="text-center mt-2" style="color:red"><?php echo e(session()->get('message')); ?></p>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <form method="post" action="<?php echo e(url('/lead_two/assign_subject')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-2">
                <label>select subject</label>
                <select class="form-control" name="subject_id">
                    <?php for($i=0; count($subject) > $i; $i++): ?>
                        <option value="<?php echo e($subject[$i]->id); ?>"><?php echo e($subject[$i]->subject); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <input type="hidden" value="<?php echo e($class->id); ?>" name="class_id">
            <div class="mt-3 form-group">
                <button class="form-control">Add Subject</button>
            </div>
        </form>
    </div>
</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Assign Staff</b></h4>
        <?php if(session()->has('message')): ?>
            <p class="text-center mt-2" style="color:red"><?php echo e(session()->get('message')); ?></p>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <form method="post" action="<?php echo e(url('/lead_two/assign_staff')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-2">
                <label>select staff</label>
                <select class="form-control" name="staff_email">
                    <?php for($i=0; count($staffs) > $i; $i++): ?>
                        <option value="<?php echo e($staffs[$i]->staff_email); ?>"><?php echo e($staffs[$i]->staff_email); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <input type="hidden" value="<?php echo e($class->id); ?>" name="class_id">
            <div class="mt-3 form-group">
                <button class="form-control">Assign staff</button>
            </div>
        </form>
    </div>
</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2" style="color:red"><b>
            <?php echo e($class->class.' subjects'); ?>

        </b></h4>
        <?php if($assigned_staff){ ?>
        <h2 class="text-center mt-2"><b>
            <?php echo e('Class Teacher: '.$assigned_staff->staff->staff_name); ?>

        </b></h2>
        <h2 class="text-center mt-2"><b>
            <?php echo e('Class Teacher Email: '.$assigned_staff->staff->staff_email); ?>

        </b></h2>
        <?php } ?>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                <?php for($i =0; count($class_subject) > $i; $i++): ?>
                <?php if($class_subject[$i]->subject): ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($class_subject[$i]->subject->subject); ?></td>
                    <td><buton class="btn btn-danger">Privilege</button></td>
                </tr>
                <?php endif; ?>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_two/class_data.blade.php ENDPATH**/ ?>