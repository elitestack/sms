

<?php $__env->startSection('content'); ?>
<form method="post" action="<?php echo e(url('/lead_four/assessment')); ?>">
    <?php echo csrf_field(); ?>
<div class="card mx-auto w-100 mt-5">
    <div class="card-header">
        <h4 class="text-center mt-5"><b><?php echo e($subject->subject->subject); ?></b></h4>
        <h4 class="text-center mt-1"><b>Academic session: </b><?php echo e($academic_session->academic_session); ?></h4>
        <h4 class="text-center mt-1"><b>Term: </b><?php echo e($term->term); ?></h4>
        <h4 class="text-center mt-1"><b>Class: </b><?php echo e($subject->class->class); ?></h4>
        <?php if(session()->has('message')): ?>
        <h4 class="text-center mt-1" style="color:red"><b><?php echo e(session()->get('message')); ?> </b></h4>
        <?php endif; ?>
    </div>
    <div class="card-body">
    <table class="table mt-3">
        <thead>
            <th>#</th>
            <th>Name</th>
            <th>Student reg</th>

            <th>CA</th>
            <th>Exam</th>
        </thead>
        <tbody>
        <input type="hidden" name="student_count" value="<?php echo e(count($student)); ?>">
        <input type="hidden" name="subject_id" value="<?php echo e($subject->subject->id); ?>">
        <input type="hidden" name="term_id" value="<?php echo e($term->id); ?>">
        <input type="hidden" name="academic_session_id" value="<?php echo e($academic_session->id); ?>">
        <input type="hidden" name="class_id" value="<?php echo e($subject->class->id); ?>">

            <?php for($i =0; count($student) > $i; $i++): ?>

            <?php 
    $data = App\Models\student_reg_base::with('students')->where('student_reg', '=', $student[$i]->student_reg)->first();
    $student_score =  App\Models\student_ca::where('student_reg', '=', $student[$i]->student_reg)->
    where('academic_session_id', '=', $academic_session->id)->where('term_id', '=', $term->id)->
    where('subject_id', '=', $subject->subject->id)->
    where('class_id', '=', $subject->class->id)->first();
    if(!$student_score){
        $create_score = App\Models\student_ca::create([
            'student_reg' => $student[$i]->student_reg,
            'academic_session_id' => $academic_session->id,
            'term_id' => $term->id,
            'ca_score' => 0,
            'exam_score' => 0,
            'subject_id' => $subject->subject->id,
            'class_id' => $subject->class->id
            ]);

            $student_score =  App\Models\student_ca::where('student_reg', '=', $student[$i]->student_reg)->
    where('academic_session_id', '=', $academic_session->id)->where('term_id', '=', $term->id)->
    where('subject_id', '=', $subject->subject->id)->
    where('class_id', '=', $subject->class->id)->first();
    }
    ?>


            
<tr>
<td><?php echo e($i+1); ?></td>
    <td><?php echo e($data->students->surname.' '.$data->students->othernames); ?></td>
    <td><?php echo e($student[$i]->student_reg); ?></td>
    <input type="hidden" name="<?php echo e('student_reg_'.$i); ?>" value="<?php echo e($student[$i]->student_reg); ?>">
    <td><input type="number" name="<?php echo e('ca_score_'.$i); ?>" value="<?php echo e($student_score->ca_score); ?>" style="width:40px"></td>
    <td><input type="number" name="<?php echo e('exam_score_'.$i); ?>" value="<?php echo e($student_score->exam_score); ?>" style="width:40px"></td>
</tr>
<?php endfor; ?>

    </tbody>
</table>

    </div>
    <div class="card-footer">
        <div class="form-group mt-3">
            <button class="form-control">Save Records</button>
        </div>
    </div>


</div>
    
</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/lead_four/general_assessment_sheet.blade.php ENDPATH**/ ?>