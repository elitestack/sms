

<?php $__env->startSection('content'); ?>

<div class="card mt-5 w-100">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Student Result</b></h4>
    </div>

    <div class="card-body">
<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Class</th>
            <th>Academic session</th>
            <th>Term</th>
            <th>Action</th>
        </tr>
    </thead>

    <?php for($i=0; count($result) > $i; $i++) {?>
<tr>
    <td><?php echo e($i+1); ?></td>
    <td><?php echo e($result[$i]->class->class); ?></td>
    <td><?php echo e($result[$i]->academic_session->academic_session); ?></td>
        <td>
            <?php 
            
            if($result[$i]->term){
            $result[$i]->term->term;            
            }
            
            ?>
            
        </td>

    <td><a href="<?php echo e(url('/result_sheet/academic_session_id='.$result[$i]->academic_session_id.'&term_id='.$result[$i]->term_id.'&class_id='.$result[$i]->class_id.'&student_reg='.$result[$i]->student_reg)); ?>" target="_blank" >
        view</a>
</td>
</tr>
    <?php } ?>
</table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_five.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_five/student_result.blade.php ENDPATH**/ ?>