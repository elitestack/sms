

<?php $__env->startSection('content'); ?>





<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
    <table class="table">
            <tr>
                <th>Academic session:</th><td style="color:red"><?php echo e($academic_session->academic_session); ?></td>
            </tr>
            
</table>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('/lead_four/fetch_student_term')); ?>" method="post">
            <?php echo csrf_field(); ?>
          <input type="hidden" value="<?php echo e($academic_session->id); ?>" name="academic_session_id">
            <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    <?php for($i=0; count($class) > $i; $i++): ?>
                    <option value="<?php echo e($class[$i]->id); ?>"><?php echo e($class[$i]->class); ?></opion>
                <?php endfor; ?>
                </select>
            </div>
            <div class="form-group mt-3">
                <label class="form-label">Term</label>
                <select class="form-control" name="term_id">
                    <?php for($i=0; count($term) > $i; $i++): ?>
                    <option value="<?php echo e($term[$i]->id); ?>"><?php echo e($term[$i]->term); ?></opion>
                <?php endfor; ?>
                </select>
            </div>

            <div class="form-group mt-3">
                <button class="form-control">Fetch Student</button>
            </div>
        </form>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_four/student_view_academic_session.blade.php ENDPATH**/ ?>