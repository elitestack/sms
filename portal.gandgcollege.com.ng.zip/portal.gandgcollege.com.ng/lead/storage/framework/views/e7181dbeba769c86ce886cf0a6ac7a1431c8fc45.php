

<?php $__env->startSection('content'); ?>






<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center mt-3">Verify Admission</h4>
    </div>
    <div class="card-body">
        <form class="mx-auto mt-3" style="width:80%" action="<?php echo e(url('/lead_one/admission_verify')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input class="form-control" name="application_id">
            </div>
            <?php $__errorArgs = ['application_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color:red"><?php echo e(session()->error('application_id')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group mt-2">
                <button class="btn btn-info form-control">Verify now</button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-5 mb-5">
    <div class="card-body">
        <table class="table mt-3">
        <h5 class="text-center mt-3" style="color:red"><b><?php echo e(count($pending_admission).' Pending Admission'); ?></b></h5>
        <table class="table">
            <thead>
                
                <tr><th>#</th><th>Name</th><th>Date</th><th>Action</th>
                         
            </tr>
            </thead>

            <tbody>
    <?php for($i =0; count($pending_admission) > $i; $i++): ?>

<tr>
    <td><?php echo e($i+1); ?></td>
    <td><?php echo e($pending_admission[$i]->surname.' '.$pending_admission[$i]->othernames); ?></td>
    <td><?php echo e($pending_admission[$i]->created_at); ?></td>
<td><a href="<?php echo e(url('application/'.$pending_admission[$i]->application_id)); ?>" target="_blank" ><button class="btn">View</button></a>
</td>

</tr>

    <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_one.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_one/admission_verify.blade.php ENDPATH**/ ?>