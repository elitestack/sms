

<?php $__env->startSection('content'); ?>



<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Subjects</b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
            </tr>
            
            </thead>
            <tbody>
                <?php for($i =0; count($subject) > $i; $i++): ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($subject[$i]->subject); ?></td>
                </tr>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/lead_two/subject.blade.php ENDPATH**/ ?>