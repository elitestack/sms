

<?php $__env->startSection('content'); ?>


<div class="card mt-5 mx-auto w-100">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Student Data</b></h4>
    </div>
    <div class="card-body mt-3">
        <form method="post" action="<?php echo e(url('/lead_three/student_view')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label">Select Academic session</label>
                <select class="form-control" name="academic_session_id">
                    <?php for($i=0; count($academic_session) > $i; $i++): ?>
                    <option value="<?php echo e($academic_session[$i]->id); ?>"><?php echo e($academic_session[$i]->academic_session); ?></opion>
                   <?php endfor; ?>
                </select>
            </div>
            <div class="form-group mt-3">
                <button class="form-control">Fetch student</button>
            </div>
        </form>
    </div>

</div>
<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
        <h4 class="text-center mt-3"><b>Add student to class room</b></h4>
        <?php if(session()->has('message')): ?>
            <h4 class="text-center" style="color:red"><?php echo e(session()->get('message')); ?></h4>
        <?php endif; ?>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('/lead_three/add_student')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-3">
                <label class="form-label">Student reg</label>
                <input class="form-control" name="student_reg">
                <?php $__errorArgs = ['student_reg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p style="color:red">enter student reg</p>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    <?php for($i =0; count($class) > $i; $i++): ?>
                    <option value="<?php echo e($class[$i]->id); ?>"><?php echo e($class[$i]->class); ?></opion>
                   <?php endfor; ?>
                  
                </select>
                <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p style="color:red">Please select class</p>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group mt-3" id="term">
                <label class="form-label">Academic session</label>
                <select class="form-control" name="academic_session_id">
                    <?php for($i=0; count($academic_session) > $i; $i++): ?>
                    <option value="<?php echo e($academic_session[$i]->id); ?>"><?php echo e($academic_session[$i]->academic_session); ?></opion>
                   <?php endfor; ?>
                </select>
                <?php $__errorArgs = ['academic_session_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p style="color:red">Please select academic session</p>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <div class="form-group mt-3">
                <button class="form-control">Add student</button>
            </div>
        </form>
    </div>

</div>


<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b><?php echo e(count($student).' total students'); ?></b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>student name</th>
                <th>student reg</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            <?php for($i =0; count($student) > $i; $i++): ?>
                <?php if($student[$i]->students): ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($student[$i]->students->surname.' '.$student[$i]->students->othernames); ?></td>
                    <td><?php echo e($student[$i]->student_reg); ?></td>
                    <td><a href="<?php echo e(url('/lead_five/dashboard/'.$student[$i]->student_reg)); ?>" target="_blank">view</a></td>

                </tr>
                <?php endif; ?>
        <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_three.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/lead_three/student.blade.php ENDPATH**/ ?>