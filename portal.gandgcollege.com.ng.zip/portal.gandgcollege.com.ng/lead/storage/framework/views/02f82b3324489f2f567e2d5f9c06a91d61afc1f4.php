

<?php $__env->startSection('content'); ?>

<div class="card mt-5">
    <div class="card-header">
        <h4 class="text-center mt-3"><b>Grade student</b></h4>
    </div>
    <div class="card-body">
        <form method="post" action="<?php echo e(url('/lead_two/grade_student')); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group">
                <label class="form-label"><b>Select student class</b></label>
                <select class="form-control" name="class_id">
                    <?php for($i =0; count($class) > $i; $i++): ?>
                    <option value="<?php echo e($class[$i]->id); ?>"><?php echo e($class[$i]->class); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <div class="form-group mt-2">
                <label class="form-label"><b>Select academic session</b></label>
                <select class="form-control" name="academic_session_id">
                    <?php for($i=0; count($academic_session) > $i; $i++): ?>
                    <option value="<?php echo e($academic_session[$i]->id); ?>"><?php echo e($academic_session[$i]->academic_session); ?></option>
                    <?php endfor; ?>
                </select>
            </div>

            <div class="form-group">
                <button class="form-control btn">Fetch Data</button>
            </div>
</form>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/lead_two/grade_student.blade.php ENDPATH**/ ?>