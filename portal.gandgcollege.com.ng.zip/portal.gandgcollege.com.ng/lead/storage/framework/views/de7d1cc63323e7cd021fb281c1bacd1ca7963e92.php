

<?php $__env->startSection('content'); ?>

<div class="card mt-5 mx-auto w-100">
    <div class="card-header">
        <h4 class="text-center mt-3"><b>Student Data</b></h4>
    </div>
    <div class="card-body">
        <table class="table">
            <tr>
                <th>Student reg:</th><td><?php echo e($student->student_reg); ?></td>
            </tr>
            <tr>
                <th>Surname:</th><td><?php echo e($student->students->surname); ?></td>
            </tr>
            <tr>
                <th>Othernames:</th><td><?php echo e($student->students->othernames); ?></td>
            </tr>

            <tr>
                <th>Academic session: </th><td><?php echo e($academic_session->academic_session); ?></td>
            </tr>
            <tr>
                <th>Assign Class: </th><td><?php echo e($class->class); ?></td>
            </tr>

            <tr>
                <th>Student portal</th><td><a href="<?php echo e(url('/lead_five/dashboard/'.$student->student_reg)); ?>" target="_blank">view</a></td>
            </tr>

        </table>
    </div>

</div>



<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
        <h4 class="text-center mt-3"><b>Select Session</b></h4>
    </div>
    <div class="card-body">
        <form action="<?php echo e(url('/lead_three/add_student_confirm')); ?>" method="post">
            <?php echo csrf_field(); ?>
           <input type="hidden" value="<?php echo e($student->student_reg); ?>" name="student_reg" >
           <input type="hidden" value="<?php echo e($academic_session->id); ?>" name="academic_session_id" >
           <input type="hidden" value="<?php echo e($class->id); ?>" name="class_id" >
            <div class="form-group mt-3">
                <label class="form-label">Term</label>
                <select class="form-control" name="term_id">
                    <?php for($i=0; count($term) > $i; $i++): ?>
                    <option value="<?php echo e($term[$i]->id); ?>"><?php echo e($term[$i]->term); ?></opion>
                <?php endfor; ?>
                </select>
            </div>
            

            <div class="form-group mt-3">
                <button class="form-control">Confirm Data</button>
            </div>
        </form>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_three.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/lead_three/student_select_term.blade.php ENDPATH**/ ?>