

<?php $__env->startSection('content'); ?>
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5 card-size" >
            <div class="card-header">
        <h1 class="text-center"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/asset/icon.webp')); ?>" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">MCA Student Portal</h3>
                
                
            </div>
            <div class="card-body">
        
                <form action="<?php echo e(url('/student_login')); ?>" class="w-85 mx-auto rounded" method="post">
         <?php echo csrf_field(); ?>
            
         <h6 class="text-center" style="color:red">
            <?php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            ?>
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Student reg:</label>
                        <input type="text" name="student_reg" placeholder="student reg" class="form-control" style="width:100%" >
                        <?php $__errorArgs = ['student_reg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your email</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>


                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Login</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/student_login.blade.php ENDPATH**/ ?>