<!DOCTYPE html>
<html lang="en" id="idtranslate" class="sidebar-color topbar_open">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="M9vNT0ON3AtEakKUG9RRbfUmvRHZY5xRK1eYpj8h">

    <title>School Portal | Student panel</title>
    <link rel="icon" href="/cloud/app/images/favlogo.png" type="image/png"/>

	<!-- Fonts and icons -->
	<script src="<?php echo e(asset('webfont.min.js')); ?>"></script>
<!-- Sweet Alert -->
<script src="<?php echo e(asset('sweetalert.min.js')); ?>"></script>
	<!-- CSS Files -->
	<link rel="stylesheet" href="<?php echo e(url('bootstrap.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('fonts.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('atlantis.min.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('customs.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(url('style.css')); ?>">
	<script src="<?php echo e(asset('fontawesome/js/all.js')); ?>" crossorigin="anonymous"></script>
	
	<!--new-->
	
	<link href="https://db.onlinewebfonts.com/c/0f5a77f185cdc9637eb4d0d85b98434e?family=fa-brand" rel="stylesheet">
	
	    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/simple-line-icons/2.5.5/css/simple-line-icons.min.css">
	<!--end new-->
	<style>
	    .fa{
	        font-size: 14px;
	    }
	</style>
	

	
	
	<link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.6.2/css/buttons.dataTables.min.css">
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/v/bs4/dt-1.10.21/af-2.3.5/b-1.6.3/b-flash-1.6.3/b-html5-1.6.3/b-print-1.6.3/r-2.2.5/datatables.min.css"/>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script> 
</head>
<body class="" data-background-color="">
    <div id="app">
         <!--PayPal-->
        
        <!--/PayPal-->
            
        <!--Start of Tawk.to Script-->
       
        <!--End of Tawk.to Script-->
        <div class="wrapper">
                    <div class="main-header">
    <!-- Logo Header -->
    <div class="logo-header bg-primary" data-background-color="">
        <a href="/" class="logo" style="font-size: 27px; color:#fff;">
            <small>School Portal</small>
        </a>
        <button class="ml-auto navbar-toggler sidenav-toggler" type="button" data-toggle="collapse" data-target="collapse" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon">
                <i class="icon-menu"></i>
            </span>
        </button>
        <button class="topbar-toggler more"><i class="icon-options-vertical"></i></button>
        <div class="nav-toggle">
            <button class="btn btn-toggle toggle-sidebar">
                <i class="icon-menu"></i>
            </button>
        </div>
    </div>
    <!-- End Logo Header -->

    <!-- Navbar Header -->
    <nav class="navbar navbar-header navbar-expand-lg bg-primary" data-background-color="">
        
        <div class="container-fluid">
            <ul class="navbar-nav topbar-nav ml-md-auto align-items-center">
                <li class="nav-item hidden-caret">
                    <div id="google_translate_element"></div>
                </li>
                <li class="nav-item dropdown hidden-caret">
                    <a class="nav-link dropdown-toggle" href="#" id="notifDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <i class="fa fa-bell"></i>
                        
                    </a>
                    <ul class="dropdown-menu notif-box animated fadeIn" aria-labelledby="notifDropdown">
                        
                        <li>
                            <a class="see-all" href="#">See all notifications<i class="fa fa-angle-right"></i> </a>
                        </li>
                    </ul>
                </li>
                    
                                <li class="nav-item dropdown hidden-caret">
                    <a class="nav-link" data-toggle="dropdown" href="#" aria-expanded="false">
                        <i class="fas fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-user animated fadeIn">
                        <div class="dropdown-user-scroll scrollbar-outer">
                            <li>
                                <div class="dropdown-divider"></div>
                                <a class="dropdown-item" href="<?php echo e(url('/lead_five/logout')); ?>">
                                    Logout
                                    </a>
                               
                            </li>
                        </div>
                    </ul>
                </li>
            </ul>
        </div>
    </nav>
    <!-- End Navbar -->
</div>        <!-- Stored in resources/views/child.blade.php -->

<!-- Sidebar -->

<div class="sidebar sidebar-style-2 bg-secondary" data-background-color="">
    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <div class="user">
                <div class="info">
                    <a  data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                        <span color="white">
                        Welcome                            
                            <span color="white" class="caret"></span>
                        </span>
                    </a>
                    <div class="clearfix"></div>
                    <div class="collapse in" id="collapseExample">
                        <ul class="nav">
                            <li>
                                <a href="#">
                                    <span class="link-collapse">Account Settings</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <ul class="nav nav-primary">
                <li class="nav-item active">
                    <a href="<?php echo e(url('/lead_five/dashboard/'.$student->student_reg)); ?>">
                        <i color="white" class="fas fa-home"></i>
                        <p color="white">Dashboard</p>
                    </a>
                </li>
                
             
       
                <li class="nav-item">
                    <a data-toggle="collapse" href="#dept">
                        <i color="white" class="fas fa-credit-card"></i>
                        <p style="color:white">Data</p>
                        <span class="caret"></span>
                    </a>
                    <div class="collapse" id="dept">
                        <ul class="nav nav-collapse" style="color:white">
                            <li>
                                <a style="color:white" href="<?php echo e(url('/lead_five/student_result/'.$student->student_reg)); ?>">
                                    <span class="sub-item" style="color:white">Result</span>
                                </a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/lead_five/student_class/'.$student->student_reg)); ?>">
                                    <span class="sub-item" style="color:white">Class</span>
                                </a>
                            </li>
                        </ul>
                    </div>
                </li>
                
                
                
                <li class="nav-item" style="color:white">
                   <a href="<?php echo e(url('/lead_five/logout')); ?>">
                        <i style="color:white" class="fa fa-sign-out-alt " aria-hidden="true"></i>
                        <p style="color:white">Logout</p>
                    
                    </a>
                   
                </li>
                
            </ul>
        </div>
    </div>
</div>
<!-- End Sidebar -->

<div class="main-panel">
<?php echo $__env->yieldContent('content'); ?>
</div>


<footer class="footer ">
                    <div class="container-fluid">
                        <div class="text-center row copyright text-align-center">
                            <p>All Rights Reserved &copy; cbtdraft.com</p>
                        </div>
                    </div>
                </footer>
            </div>
        </div>
    </div>



		
<script type="text/javascript">
		
	function googleTranslateElementInit() {
	new google.translate.TranslateElement({pageLanguage: 'en', layout: google.translate.TranslateElement.InlineLayout.SIMPLE}, 'google_translate_element');
	}
	
	(function(){var gtConstEvalStartTime = new Date();function d(b){var a=document.getElementsByTagName("head")[0];a||(a=document.body.parentNode.appendChild(document.createElement("head")));a.appendChild(b)}function _loadJs(b){var a=document.createElement("script");a.type="text/javascript";a.charset="UTF-8";a.src=b;d(a)}function _loadCss(b){var a=document.createElement("link");a.type="text/css";a.rel="stylesheet";a.charset="UTF-8";a.href=b;d(a)}function _isNS(b){b=b.split(".");for(var a=window,c=0;c<b.length;++c)if(!(a=a[b[c]]))return!1;return!0}
	function _setupNS(b){b=b.split(".");for(var a=window,c=0;c<b.length;++c)a.hasOwnProperty?a.hasOwnProperty(b[c])?a=a[b[c]]:a=a[b[c]]={}:a=a[b[c]]||(a[b[c]]={});return a}window.addEventListener&&"undefined"==typeof document.readyState&&window.addEventListener("DOMContentLoaded",function(){document.readyState="complete"},!1);
	if (_isNS('google.translate.Element')){return}(function(){var c=_setupNS('google.translate._const');c._cest = gtConstEvalStartTime;gtConstEvalStartTime = undefined;c._cl='en';c._cuc='googleTranslateElementInit';c._cac='';c._cam='';c._ctkk=eval('((function(){var a\x3d814543065;var b\x3d2873925779;return 414629+\x27.\x27+(a+b)})())');var h='translate.googleapis.com';var s=(true?'https':window.location.protocol=='https:'?'https':'http')+'://';var b=s+h;c._pah=h;c._pas=s;c._pbi=b+'/translate_static/img/te_bk.gif';c._pci=b+'/translate_static/img/te_ctrl3.gif';c._pli=b+'/translate_static/img/loading.gif';c._plla=h+'/translate_a/l';c._pmi=b+'/translate_static/img/mini_google.png';c._ps=b+'/translate_static/css/translateelement.css';c._puh='translate.google.com';_loadCss(c._ps);_loadJs(b+'/translate_static/js/element/main.js');})();})();
	
	</script>
    <!--   Core JS Files   -->
	<script src="<?php echo e(asset('jquery.3.2.1.min.js')); ?>"></script>
	<script src="<?php echo e(asset('popper.min.js')); ?>"></script>
	<script src="<?php echo e(asset('bootstrap.min.js')); ?>"></script>
	<script src="<?php echo e(asset('customs.js')); ?>"></script>
	
	<!-- jQuery UI -->
	<script src="<?php echo e(asset('jquery-ui.min.js')); ?>"></script>
	<script src="<?php echo e(asset('jquery.ui.touch-punch.min.js')); ?>"></script>

	<!-- jQuery Scrollbar -->
	<script src="<?php echo e(asset('jquery.scrollbar.min.js')); ?>"></script>

	<!-- jQuery Sparkline -->
	<script src="<?php echo e(asset('jquery.sparkline.min.js')); ?>"></script>

	<!-- Sweet Alert -->
	<script src="<?php echo e(asset('sweetalert.min.js')); ?>"></script>
	<!-- Bootstrap Notify -->
	<script src="<?php echo e(asset('bootstrap-notify.min.js')); ?>"></script>
	
	<script type="text/javascript" src="https://cdn.datatables.net/v/bs4/dt-1.10.21/af-2.3.5/b-1.6.3/b-flash-1.6.3/b-html5-1.6.3/b-print-1.6.3/r-2.2.5/datatables.min.js"></script>

	<!-- Atlantis JS -->
	<script src="<?php echo e(asset('atlantis.min.js')); ?>"></script>
	<script src="<?php echo e(asset('atlantis.js')); ?>"></script>
	
	 <script>
		$(document).ready( function () {
			$('#ShipTable').DataTable({
				order: [ [0, 'desc'] ],
				dom: 'Bfrtip',
				buttons: [
				'copy', 'csv', 'print', 'excel','pdf'
        	]
			});

			
			$(".dataTables_length select").addClass("bg-dark text-light");
			$(".dataTables_filter input").addClass("bg-dark text-light");
		} );
	</script>
	<script>
		$(document).ready( function () {
			$('.UserTable').DataTable({
				order: [ [0, 'desc'] ]
			});
			$(".dataTables_length select").addClass("bg-dark text-light");
			$(".dataTables_filter input").addClass("bg-dark text-light");
		} );
	</script>
	




</body>
</html>

<?php /**PATH C:\xampp\htdocs\school_lead\lead\resources\views/lead_five/master.blade.php ENDPATH**/ ?>