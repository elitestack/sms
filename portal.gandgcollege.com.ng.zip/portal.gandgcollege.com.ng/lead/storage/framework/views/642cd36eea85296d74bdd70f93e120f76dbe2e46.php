

<?php $__env->startSection('content'); ?>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h1 class="text-center mt-2"><b style="color:red"><?php echo e($subject->subject->subject); ?></b></h1>
        <h2 class="text-center mt-2"><b style="color:red"><?php echo e($academic_session->academic_session); ?></b></h2>
        <h3 class="text-center mt-2"><b><?php echo e('class: '. $subject->class->class); ?></b></h3>
    </div>
    <div class="card-body mt-3">
       
    <form action="<?php echo e(url('/lead_four/ca_record_start')); ?>" method="post" >
        <?php echo csrf_field(); ?>
        <input type="hidden" value="<?php echo e($subject->subject->id); ?>" name="subject_id" >
        <input type="hidden" value="<?php echo e($academic_session->id); ?>" name="academic_session_id" >

        <div class="form-group mt-4">
            <label class="form-label">Select Academic session term</label>
            <select class="form-control" name="term_id" >
                <?php for($i=0; count($term) > $i; $i++): ?>
                <option value="<?php echo e($term[$i]->id); ?>"><?php echo e($term[$i]->term); ?></option>
                <?php endfor; ?>
</select>
        </div>
        <div class="form-group mt-2">
            <button class="form-control">Fetch Data</button>
        </div>
</form>
    </div>
</div>

<div class="card mt-5">
    <div class="card-header">
        <h2 class="text-center mt-3"><b>Previous Data</h2>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/lead_four/ca_record_academic_session.blade.php ENDPATH**/ ?>