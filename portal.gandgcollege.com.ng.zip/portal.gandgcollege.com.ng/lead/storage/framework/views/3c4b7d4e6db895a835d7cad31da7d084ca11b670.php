

<?php $__env->startSection('content'); ?>
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5 card-size" >
            <div class="card-header">
        <h1 class="text-center"><a href="https://gandgcollege.com.ng"><img src="<?php echo e(asset('/images/logo.jpeg')); ?>" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">GandG College Portal</h3>
                
                
            </div>
            <div class="card-body">
        
                <form action="<?php echo e(url('/login')); ?>" class="w-85 mx-auto rounded" method="post">
         <?php echo csrf_field(); ?>
            
         <h6 class="text-center" style="color:red">
            <?php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            ?>
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Email:</label>
                        <input type="email" name="email" placeholder="type email" class="form-control" style="width:100%" value="<?php if(session()->has('mail')){
                            echo session()->get('mail');
                        } ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your email</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Password:</label>
                        <input type="password" placeholder="type password" name="password" class="form-control" style="width:100%" value="<?php if(session()->has('password')){ echo session()->get('password'); } ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your password</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:green; color:white; width:100%">Login</button>
                    </div>


                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/staff_login.blade.php ENDPATH**/ ?>