

<?php $__env->startSection('content'); ?>


<div class="mt-5 w-100 mx-auto">
    <div class="card-header"><h4 class="text-center mt-5"><b>Class</b></h4></h4></div>

    <div class="card-body">
    <form method="post" action="<?php echo e(url('/lead_two/assign_class')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group mt-2">
                <label>select class</label>
                <select class="form-control" name="class_id">
                    <?php for($i=0; count($class) > $i; $i++): ?>
                        <option value="<?php echo e($class[$i]->id); ?>">
                            <?php echo e($class[$i]->class); ?>

                        </option>
                    <?php endfor; ?>
                </select>
            </div>
<input type="hidden" value="<?php echo e($staff_email); ?>" name="staff_email" >
            <div class="mt-3 form-group">
                <button class="form-control">Fetch Subjects</button>
            </div>
        </form>
    </div>
</div>


<div class="mt-5 card">
    <div id="load_data">

    </div>
</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staff role</b></h4>
        <h5 class="text-center mt-2"><b><?php echo e($staff_email); ?></b></h5>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>class</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_two/staff_data.blade.php ENDPATH**/ ?>