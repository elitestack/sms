

<?php $__env->startSection('content'); ?>

        <div class="card mx-auto mt-5" style='width:80%'>
            <div class="card-header">
        <h1 class="text-center"><a href="#"><img src="<?php echo e(asset('/images/logo.jpeg')); ?>" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">Student Application</h3>
                
                
            </div>
            <div class="card-body">

                <form action="<?php echo e(url('/lead_three/application')); ?>" class="w-85 mx-auto rounded" method="post">
         <?php echo csrf_field(); ?>
            
         <h6 class="text-center" style="color:red">
            <?php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            ?>
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Surname</label>
                        <input type="surname" name="surname" placeholder="student surname" class="form-control" style="width:100%" value="<?php if(session()->has('surname')){
                            echo session()->get('surname');
                        } ?>">
                        <?php $__errorArgs = ['surname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your surname</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Othernames:</label>
                        <input type="text" placeholder="othernames" name="othernames" class="form-control" style="width:100%" value="<?php if(session()->has('password')){ echo session()->get('password'); } ?>">
                        <?php $__errorArgs = ['othernames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your othernames</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>
                     <div class="form-group">
                        <label for="" class="form-label">D.O.B:</label>
                        <input type="date" placeholder="D.O.B" name="dob" class="form-control" style="width:100%" value="">
                        <?php $__errorArgs = ['dob'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your D.O.B</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>
                <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    <?php for($i =0; count($class) > $i; $i++): ?>
                    <option value="<?php echo e($class[$i]->id); ?>"><?php echo e($class[$i]->class); ?></opion>
                   <?php endfor; ?>
                  
                </select>
                <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p style="color:red">Please select class</p>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label class="form-label">Select Academic session</label>
                <?php $__errorArgs = ['term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please select term</p><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                <select class="form-control" name="academic_session_id">
                    <?php for($i=0; count($academic_session) > $i; $i++): ?>
                    <option id="term" value="<?php echo e($academic_session[$i]->id); ?>"><?php echo e($academic_session[$i]->academic_session); ?></opion>
                   <?php endfor; ?>
                </select>
            </div>
                    <div class="form-group">
                        <label for="" class="form-label">Sex:</label>

                        <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your sex</p><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <select name="sex" class="form-control" >

                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>    
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="10" class="form-control" style="width:100%" placeholder="address" value="<?php if(session()->has('address')){ echo session()->get('address'); } ?>"></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your address</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian name:</label>
                        <input type="guardian" placeholder="guardian name" name="guardian" class="form-control" style="width:100%" value="<?php if(session()->has('password')){ echo session()->get('password'); } ?>">
                        <?php $__errorArgs = ['othernames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your guardian name</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%" value="<?php if(session()->has('password')){ echo session()->get('password'); } ?>">
                        <?php $__errorArgs = ['othernames'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your guardian name</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>




                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="10" class="form-control" style="width:100%" placeholder="address" value="<?php if(session()->has('address')){ echo session()->get('address'); } ?>"></textarea>
                        <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your address</p>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:green; color:white; width:100%">Start Application</button>
                    </div>

                </form>
            </div>
            
        </div>
        
        <section>
<script>
    const term = document.getElementById("term");
    
    term.addEventlistener("click", function(){
       
       alert("hello world"); 
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_three.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_three/application.blade.php ENDPATH**/ ?>