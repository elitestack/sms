

<?php $__env->startSection('content'); ?>





<div class="card mt-5 mx-auto w-100">

    <div class="card-header">
        <h4 class="text-center mt-5"><b><?php echo e($class->class.' student list'); ?></b></h4>
        <h2 class="text-center"><b>Academic session: </b><?php echo e($academic_session->academic_session); ?></h2>
        <h2 class="text-center"><b>Term: </b><?php echo e($term->term); ?></h2>
    </div>
    <div class="card-body">
        <table class="table">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Student name</th>
                    <th>reg</th>
                    <th>Portal</th>
                </tr>
            </thead>
            <tbody>
                <?php for($i =0; count($student) > $i; $i++): ?>
<tr>
    <td><?php echo e($i+1); ?></td>
    <?php 
    $data = App\Models\student_reg_base::with('students')->where('student_reg', '=', $student[$i]->student_reg)->first();

    ?>

    <td><?php echo e($data->students->surname.' '.$data->students->othernames); ?></td>
    <td><?php echo e($student[$i]->student_reg); ?></td>
    <td><a href="<?php echo e(url('/lead_five/dashboard/'.$student[$i]->student_reg)); ?>" target="_blank">view</a></td>
</tr>
                <?php endfor; ?>
            </tbody>
            </table>
    </div>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_three.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_three/student_view_academic_session_term.blade.php ENDPATH**/ ?>