

<?php $__env->startSection('content'); ?>

<div class="card mt-5">
    <div class="card-header">
        <h4 class="text-center mt-3"><b>Grade student</b></h4>
        <h4><b>Academic session: </b><?php echo e($academic_session->academic_session); ?></h4>
        <h4><b>Class: </b><?php echo e($class->class); ?></h4>
    </div>
    <div class="card-body">
        <form method="post" action="<?php echo e(url('/lead_two/student_result_grade')); ?>">
            <?php echo csrf_field(); ?>
            <input type="hidden" name="class_id" value="<?php echo e($class->id); ?>">
            <input type="hidden" name="academic_session_id" value="<?php echo e($academic_session->id); ?>">
            <div class="form-group">
                
            </div>
            <div class="form-group mt-2">
                <label class="form-label"><b>Select term</b></label>
                <select class="form-control" name="term_id">
                    <?php for($i =0; count($term) >$i; $i++): ?>
<option value="<?php echo e($term[$i]->id); ?>"><?php echo e($term[$i]->term); ?>

</option> 
                    <?php endfor; ?>
                </select>
            </div>

            <div class="form-group">
                <button class="form-control btn">Grade</button>
            </div>
</form>
    </div>
</div>

<?php for($i=0; count($term) > $i; $i++): ?>
<div class="card mt-2">
    <div class="card-header"><h4 class="text-center"><b>Student Grades: </b>
    <?php echo e($term[$i]->term); ?>

</div>
    <div class="card-body">
        <table class="table">
            <thead>
<tr>
    <th>#</th>
    <th>student name</th>
    <th>Reg Id</th>
    <th>Class</th>
    <th>Position</th>
    <th>Action</th>
</tr>
            </thead>
            <tbody>
<?php for($i =0; count($student_grade) > $i; $i++): ?>


<?php 

$student_data = App\Models\pending_student::where('application_id', '=', $student_grade[$i]->student->application_id)->first();

?>
<?php if($student_data): ?>
<tr>
    <td><?php echo e($i+1); ?></td>
    <td><?php echo e($student_data->surname.' '.$student_data->othernames); ?></td>
    <td><?php echo e($student_grade[$i]->student_reg); ?></td>
    <td><?php echo e($student_grade[$i]->class->class); ?></td>
    <td><?php echo e($student_grade[$i]->position); ?></td>
    <td><a href="<?php echo e(url('/lead_five/student_result/'.$student_grade[$i]->student_reg)); ?>" target="_blank">View</a></td>
</tr>
<?php endif; ?>

<?php endfor; ?>
</tbody>
</table>
    </div> 
</div>
<?php endfor; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_two/grade_student_session_class.blade.php ENDPATH**/ ?>