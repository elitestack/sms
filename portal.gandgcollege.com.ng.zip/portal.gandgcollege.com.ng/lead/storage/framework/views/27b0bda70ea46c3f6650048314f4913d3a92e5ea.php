

<?php $__env->startSection('content'); ?>
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:80%'>
            <div class="card-header">
        <h1 class="text-center"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/asset/icon.webp')); ?>" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">MCA Student Application Portal</h3>
            </div>
            <div class="card-body">
                    <?php for($i=0; count($applicated_associated) > $i; $i++): ?>
<a href="<?php echo e(url('/application/'.$applicated_associated[$i]->application_id)); ?>" target="_blank"><button class="btn btn-danger"><?php echo e($applicated_associated[$i]->application_id); ?></button></a>
                    <?php endfor; ?>
            </div>
            
        </div>
        

        

    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/associated_application.blade.php ENDPATH**/ ?>