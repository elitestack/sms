

<?php $__env->startSection('content'); ?>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Assign new subject</b></h4>
        <?php if(session()->has('message')): ?>
            <p class="text-center" style="color:red"><?php echo e(session()->get('message')); ?></p>
        <?php endif; ?>
    </div>
    <div class="card-body">
    <form method="post" action="<?php echo e(url('/lead_two/assign_subject_confirm')); ?>">
        <?php echo csrf_field(); ?>
            <div class="form-group mt-5">
                <label class="form-label">Select Subject</lablel>
                <select class="form-control" name="subject_id">
                    <?php for($i=0; count($subject) > $i; $i++): ?>
                    <option value="<?php echo e($subject[$i]->id); ?>"><?php echo e($subject[$i]->subject); ?></option>
                    <?php endfor; ?>
                </select>
            </div>
            <input type="hidden" value="<?php echo e($staff_email); ?>" name="staff_email" >
            <input type="hidden" value="<?php echo e($class_id); ?>" name="class_id" >
            <div class="form-group mt-4">
                <button class="form-control mt-1">Assign Subject</button>
            </div>
</form>
        </div>

</div>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staff subjects</b></h4>
        <h5 class="text-center mt-2"><b><?php echo e($staff_email); ?></b></h5>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>class</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                <?php for($i =0; count($assign_subject) > $i; $i++): ?>
                   <?php if($assign_subject[$i]->subject): ?>
                   <tr>
                        <td><?php echo e($i+1); ?></td>
                        <td><?php echo e($assign_subject[$i]->subject->subject); ?></td>
                        <td><?php echo e($assign_subject[$i]->class->class); ?></td>
                        <td><button class="btn btn-danger">Delete</button></td>
                    </tr>
                   <?php endif; ?>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/lead_two/assign_staff_class_subject.blade.php ENDPATH**/ ?>