

<?php $__env->startSection('content'); ?>

<!--<div class="mt-5 card w-100 mx-auto">-->
<!--    <div class="card-header">-->
<!--        <h4 class="text-center mt-5"><b>Filter Students</b><h4>-->
<!--    </div>-->
<!--    <div class="card-body">-->
<!--<form action="<?php echo e(url('/lead_two/filter_student')); ?>" method="post">-->
<!--    <div class="form-group">-->
<!--        <select name="academic_session_id" class="form-control">-->
<!--            <?php for($i =0; count($academic_session) > $i; $i++): ?>-->
<!--            <option value="<?php echo e($academic_session[$i]->id); ?>"><?php echo e($academic_session[$i]->academic_session); ?></option>-->
<!--            <?php endfor; ?>-->
<!--</select>-->
<!--</div>-->
<!--<div class="form-group">-->
<!--        <select name="academic_session_id" class="form-control">-->
<!--            <?php for($i=0; count($class) > $i; $i++): ?>-->
<!--            <option value="<?php echo e($class[$i]->id); ?>"><?php echo e($class[$i]->class); ?></option>-->
<!--            <?php endfor; ?>-->
<!--</select>-->
<!--</div>-->
<!--<div class="form-group">-->
<!--    <button class="btn btn-danger form-control" disabled>Fetch Data</button>-->
<!--</div>-->
<!--</form>-->
<!--    </div>-->
<!--</div>-->

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-5"><b><?php echo e(count($student).' total students'); ?></b></h4>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>student name</th>
                <th>student reg</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
            <?php for($i =0; count($student) > $i; $i++): ?>
                <?php if($student[$i]->students): ?>
                <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($student[$i]->students->surname.' '.$student[$i]->students->othernames); ?></td>
                    <td><?php echo e($student[$i]->student_reg); ?></td>
                    <td><a href="<?php echo e(url('/lead_five/dashboard/'.$student[$i]->student_reg)); ?>" target="_blank">view</a></td>

                </tr>
                <?php endif; ?>
        <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/lead_two/students.blade.php ENDPATH**/ ?>