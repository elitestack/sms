<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="<?php echo e(url('css/bootstrap.min.css')); ?>">
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/umd/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="/fontawesome/js/all.js" crossorigin="anonymous"></script>
<style>


.card-size{
    
    width: 45%;
}
    @media only screen and (max-width:768px){
        .card-size{
            
            width: 100%;
        }
        
    }
</style>
    <title>School Portal</title>
</head>
<body class="container" style="background-image: url('/images/background.jpeg')">

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <!--<h6 class="mt-3 text-center"><b>Designed by <a href="https://cbtdraft.com" target="_blank">CBTDRAFT.COM</a></b></h6>-->
    </footer>
</body>
</html><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/master/app_two.blade.php ENDPATH**/ ?>