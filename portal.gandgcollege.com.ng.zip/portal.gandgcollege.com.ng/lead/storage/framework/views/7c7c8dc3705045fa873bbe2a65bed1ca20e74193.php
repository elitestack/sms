

<?php $__env->startSection('content'); ?>
<div class="card mx-auto w-100 mt-5">

    <div class="card-header">
        <h3 class="text-center">Academic session</h3>
    </div>

    <div class="card-body">
<form action="<?php echo e(url('/lead_four/student')); ?>" method="post" class="w-75">
    <?php echo csrf_field(); ?>
    <div class="form-group mt-3">
        <label class="form-label">select academic session</label>
        <select class="form-control" name="academic_session_id">
            <?php for($i=0; count($academic_session) > $i; $i++): ?>
            <option value="<?php echo e($academic_session[$i]->id); ?>"><?php echo e($academic_session[$i]->academic_session); ?></option>
            <?php endfor; ?>
</select>
<div class="form-group mt-3">
    <button class="form-control">Fetch Data</button>
</div>
</form>
    </div>
</div>






<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_four/student.blade.php ENDPATH**/ ?>