

<?php $__env->startSection('content'); ?>
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-1" style='width:100%'>
            <div class="card-header">
                <h3 class="text-center mt-1">MCA Staff Portal</h3>
            
        </div>
            <div class="card-body">
           
        
            <table class="table mb-3 mt-3">
                 <tr>
                    <th>Staff Name: <th><td><?php echo e(session()->get('staff_name')); ?></td>
                </tr>
                <tr>
                    <th>Email:<th><td><?php echo e(session()->get('staff_email')); ?></td>
                </tr>
                <tr>
                    <th>Role: <th><td><?php echo e('Head teacher '.session()->get('staff_role')); ?></td>
                </tr>

            </table>
                <form action="<?php echo e(url('/staff_data_update')); ?>" class="w-100 mx-auto rounded" method="post">
         <?php echo csrf_field(); ?>
            
         <h6 class="text-center" style="color:red">
            <?php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            ?>
    </h6>
                    
                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="2" class="form-control" style="width:100%" placeholder="address" ></textarea>
                        
                    </div>


                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="2" class="form-control" style="width:100%" placeholder="address"></textarea>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%" disabled>Update Data</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_two.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/lead_two/dashboard.blade.php ENDPATH**/ ?>