

<?php $__env->startSection('content'); ?>






<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center mt-3"><?php echo e($fetch->academic_session." Academic session"); ?></h4>
    </div>
    <div class="card-body">
        <form class="mx-auto mt-3" style="width:80%" action="<?php echo e(url('/lead_one/create_academic_session_term')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <input class="form-control" name="term" >
                <input type="hidden" value="<?php echo e($academic_session_id); ?>" name="academic_session_id">
            </div>
            <?php $__errorArgs = ['academic_session_term'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <p style="color:red"><?php echo e(session()->error('academic_session term')); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            <div class="form-group mt-2">
                <button class="btn btn-info form-control">Create Academic session Terms</button>
            </div>
        </form>
    </div>
</div>

<div class="card mt-5 mb-5">
    <div class="card-body">
        <table class="table mt-3">
        <h5 class="text-center mt-3">Academic sessions terms</h5>
        <table class="table">
            <thead>
                <tr><th>#</th>
                    <th>Academic session</th><th>term</th><th>Status</th><th>Date</th><th>Action</th>
                         
            </tr>
            </thead>
            <tbody>
                <?php for($i =0; count($terms) > $i; $i++): ?>
                    <tr>
                    <td><?php echo e($i+1); ?></td>
                    <td><?php echo e($fetch->academic_session); ?></td>
                    <td><?php echo e($terms[$i]->term); ?></td>
                    <td><?php echo e($terms[$i]->term_status); ?></td>
                    <td><?php echo e($terms[$i]->created_at); ?></td>
                    <td>
                        <form action="<?php echo e(url('/lead_one/term_status')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="academic_session_id" value="<?php echo e($academic_session_id); ?>">
                            <div class="form-group">
                                <select name="status" id="" class="form-control">
                                    <option value="publish">publish</option>
                                    <option value="delete">delete</option>
                                    <option value="pending">pending</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <button class="btn btn-danger">trigger</button>
                            </div>
                        </form>
                    </td>               
</tr>

                <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_one.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/lead_one/academic_session_id.blade.php ENDPATH**/ ?>