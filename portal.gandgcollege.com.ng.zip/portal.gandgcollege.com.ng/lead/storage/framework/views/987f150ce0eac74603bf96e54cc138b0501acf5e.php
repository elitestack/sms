

<?php $__env->startSection('content'); ?>

<div class="card mx-auto w-100 mt-5">
    
    <div class="card-header">
        <h4 class="text-center mt-5"><b>Assessment Sheet</b></h4>
        <h4 class="mt-2"><b>Academic session:</b> <?php echo e($academic_data->academic_session); ?></h4>
        <h4 class="mt-2"><b>Academic Term:</b> <?php echo e($term->term); ?></h4>

    </div>
    <div class="card-body">
    <table class="table mt-3">
        <thead>
            <th>#</th>
            <th>Subject</th>
            <th>Assessment</th>
        </thead>
        <tbody>
            <?php for($i =0; count($assigned_subject) > $i; $i++): ?>

           <?php if($assigned_subject): ?>
           <tr>
                <td><?php echo e($i+1); ?></td>
                <td><?php echo e($assigned_subject[$i]->subject->subject); ?></td>
                
                <td>
                <a href="<?php echo e('/lead_four/assessment&class_id='.$assigned_subject[$i]->class_id.'&subject_id='.$assigned_subject[$i]->subject_id.'&academic_session_id='.$academic_data->id.'&term_id='.$term->id); ?>" target="_blank">Assessment Sheet</a>
                </td>
                </tr>
           <?php endif; ?>
            <?php endfor; ?>
        </tbody>
</table>

    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_four/class_data.blade.php ENDPATH**/ ?>