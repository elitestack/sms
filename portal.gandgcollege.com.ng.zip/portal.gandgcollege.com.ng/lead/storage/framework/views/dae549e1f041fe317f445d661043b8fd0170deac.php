

<?php $__env->startSection('content'); ?>

<div class="card mx-auto w-100 mt-5">
    <div class="card-header"><h4 class="text-center mt-5"><b>Assigned class</b></h4></div>
    <div class="card-body">
<form method="post" action="<?php echo e(url('/lead_four/class')); ?>">
    <?php echo csrf_field(); ?>
    <div class="form-group mt-3">
<select class="form-control" name="class_id">
<?php for($i =0; count($assigned_class) > $i; $i++): ?>
    <?php if($assigned_class): ?>
            <option value="<?php echo e($assigned_class[$i]->class->id); ?>"><?php echo e($assigned_class[$i]->class->class); ?></option>
    <?php endif; ?>
<?php endfor; ?>
</select>
    </div>

    <div class="form-group mt-3">
        <button class="form-control">Fetch Class Data</button>
    </div>
</form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/lead_four/class.blade.php ENDPATH**/ ?>