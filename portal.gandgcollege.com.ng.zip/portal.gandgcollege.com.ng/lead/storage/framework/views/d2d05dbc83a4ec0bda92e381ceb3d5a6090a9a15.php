

<?php $__env->startSection('content'); ?>
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:80%'>
            <div class="card-header">
        <h1 class="text-center"><a href="https://gandgcollege.com.ng"><img src="<?php echo e(asset('/images/logo.jpeg')); ?>" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">Student Application</h3>
                <?php 
if(!$passport){
    $passport = "avatar.png";
}else{
    $passport =$passport->student_passport;    

}
                ?>
   
                <p class="text-center"><img alt="student passport" style="width:25%" src="<?php echo e(url('/student_passport/'.$passport)); ?>" ></p>
                <form action="<?php echo e(url('/student_passport_upload')); ?>" method="post" enctype="multipart/form-data" >
                <?php echo csrf_field(); ?>
                <input type="file" name="student_passport"  />
                <button onClick("student_passport")>upload</button>
                </form>

                <script>
                    function student_passport(e){

                        e.preventDefault();

                        alert("am working");
                    }
                </script>
            </div>
            <div class="card-body">
        
            <table class="table mb-3 mt-3">
                <tr>

                    <th>Academic session applied<th><td><?php echo e($application_data->academic_session_id); ?></td>
                </tr>
                <tr>
                    <th>Student reg<th><td><?php echo e(session()->get('application_id')); ?></td>
                </tr>
                <tr>
                    <th>Application Id<th><td>pending</td>
                </tr>
                <tr>
                    <th>Application status<th><td><?php echo e($application_data->academic_session_id); ?></td>
                </tr>
                <tr>
                    <th>Date<th><td><?php echo e($application_data->created_at); ?></td>
                </tr>
            </table>
                <form action="<?php echo e(url('/student_application_update')); ?>" class="w-85 mx-auto rounded" method="post">
         <?php echo csrf_field(); ?>
            
         <h6 class="text-center" style="color:red">
            <?php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            ?>
    </h6>
                    <div class="form-group">
                        <label for="" class="form-label">Surname</label>
                        <input type="surname" name="surname" placeholder="student surname" class="form-control" style="width:100%" value="<?php echo e($application_data->surname); ?>">
                       
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Othernames:</label>
                        <input type="text" placeholder="othernames" name="othernames" class="form-control" style="width:100%" value="<?php echo e($application_data->othernames); ?>">
                       
                    </div>
                    <div class="form-group">
                        <label for="" class="form-label">Sex:</label>

                        <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your sex</p><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <select name="sex" class="form-control" >
                        <option>Male</option>
                        <option>Female</option>
                    </select>    
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="10" class="form-control" style="width:100%" placeholder="address" ><?php echo e($application_data->address); ?></textarea>
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian name:</label>
                        <input type="guardian" placeholder="guardian name" name="guardian" class="form-control" style="width:100%" value="<?php echo e($application_data->guardian); ?>">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%" value="<?php echo e($application_data->guardian_phone); ?>">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="10" class="form-control" style="width:100%" placeholder="address"><?php echo e($application_data->guardian_address); ?></textarea>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:#ff6347; color:white; width:100%">Update Application</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
    </div>
    
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('master.app_two', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/efvecpvz/portal.gandgcollege.com.ng/lead/resources/views/application.blade.php ENDPATH**/ ?>