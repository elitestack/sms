

<?php $__env->startSection('content'); ?>

<div class="mt-5 card w-100 mx-auto">
    <div class="card-header">
        <h4 class="text-center mt-2"><b>Staff subjects</b></h4>
        <h5 class="text-center mt-2"><b><?php echo e(session()->get('lead_four')); ?></b></h5>
    </div>
    <div class="card-body mt-3">
        <table class="table">
            <thead>
            <tr>
                <th>#</th>
                <th>subject</th>
                <th>class</th>
                <th>action</th>
            </tr>
            
            </thead>
            <tbody>
                <?php for($i =0; count($assign_subject) > $i; $i++): ?>
                   <?php if($assign_subject[$i]->subject && $assign_subject[$i]->class): ?>
                   <tr>
                        <td><?php echo e($i+1); ?></td>
                        <td><?php echo e($assign_subject[$i]->subject->subject); ?></td>
                        <td><?php echo e($assign_subject[$i]->class->class); ?></td>
                        <td><a href="<?php echo e(url('/lead_four/ca_record/subject_id='.$assign_subject[$i]->subject_id)); ?>">assessment</a></td>
                    </tr>
                   <?php endif; ?>
                <?php endfor; ?>
            </tbody>
        </table>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_four.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/school.cbtdraft.com/lead/resources/views/lead_four/ca_record.blade.php ENDPATH**/ ?>