

<?php $__env->startSection('content'); ?>
<div class="w-100">
    <div class="main mt-5">
  

        <div class="card mx-auto mt-5" style='width:80%'>
            <div class="card-header">
        <h1 class="text-center"><a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('/images/logo.jpeg')); ?>" alt="cbtdraft.com" style="width:15%"></a></h1>
                <h3 class="text-center mt-3">Student Application</h3>
                <?php 
if(!$passport){
    $passport = "avatar.png";
}else{
    $passport =$passport->student_passport;    

}
                ?>
   
                <p class="text-center"><img alt="student passport" style="width:25%" src="<?php echo e(url('/student_passport/'.$passport)); ?>" ></p>
            

                <script>
                    function student_passport(e){

                        e.preventDefault();

                        alert("am working");
                    }
                </script>
            </div>
            <div class="card-body">
        
            <table class="table mb-3 mt-3">
 
                <tr>
                    <th>Application Id<th><td><?php echo e($application_data->application_id); ?></td>
                </tr>
                <tr>
                    <th>Application session<th><td><?php echo e($academic_session); ?></td>
                </tr>
                <tr>
                    <th>Application status<th><td><?php echo e($application_data->application_status); ?></td>
                </tr>
                <tr>
                    <th>Date<th><td><?php echo e($application_data->created_at); ?></td>
                </tr>
            </table>
                <form action="<?php echo e(url('/lead_three/student_application_approve')); ?>" class="w-85 mx-auto rounded" method="post">
         <?php echo csrf_field(); ?>
            
         <h6 class="text-center" style="color:red">
            <?php 

        if(session()->has('message')){

         echo   session()->get('message');
        }
            ?>
    </h6>
    <input type="hidden" name="application_id" value="<?php echo e($application_data->application_id); ?>" >
        <input type="hidden" name="acadmic_session_id" value="<?php echo e($application_data->academic_session_id); ?>" >
                    <div class="form-group">
                        <label for="" class="form-label">Surname</label>
                        <input type="surname" name="surname" placeholder="student surname" class="form-control" style="width:100%" value="<?php echo e($application_data->surname); ?>">
                       
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Othernames:</label>
                        <input type="text" placeholder="othernames" name="othernames" class="form-control" style="width:100%" value="<?php echo e($application_data->othernames); ?>">
                       
                    </div>
                    <div class="form-group">
                        <label for="" class="form-label">Sex:</label>

                        <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p>please enter your sex</p><br>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <select name="sex" class="form-control" >
                        <option value="<?php echo e(session()->get('sex')); ?>"><?php echo e(session()->get('sex')); ?></option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>    
                    </div>
                    
                    
                <div class="form-group mt-3">
                <label class="form-label">Class</label>
                <select class="form-control" name="class_id">
                    <?php if($current_class): ?>
                                        <option value="<?php echo e($current_class->id); ?>"><?php echo e($current_class->class); ?></opion>
                    <?php endif; ?>
                    <?php for($i =0; count($class) > $i; $i++): ?>
                    <option value="<?php echo e($class[$i]->id); ?>"><?php echo e($class[$i]->class); ?></opion>
                   <?php endfor; ?>
                  
                </select>
                <?php $__errorArgs = ['class_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <p style="color:red">Please select class</p>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
                        <div class="form-group mt-3">
                <label class="form-label">Term</label>
                <select class="form-control" name="term_id">
                    <?php for($i=0; count($term) > $i; $i++): ?>
                    <option value="<?php echo e($term[$i]->id); ?>"><?php echo e($term[$i]->term); ?></opion>
                <?php endfor; ?>
                </select>
            </div>

                    <div class="form-group">
                        <label for="" class="form-label">Address:</label>
                        <textarea  name="address" rows="10" class="form-control" style="width:100%" placeholder="address" ><?php echo e($application_data->address); ?></textarea>
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian name:</label>
                        <input type="guardian" placeholder="guardian name" name="guardian" class="form-control" style="width:100%" value="<?php echo e($application_data->guardian); ?>">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian Telephone:</label>
                        <input type="guardian" placeholder="guardian telephone" name="guardian_phone" class="form-control" style="width:100%" value="<?php echo e($application_data->guardian_phone); ?>">
                        
                    </div>

                    <div class="form-group">
                        <label for="" class="form-label">Guardian address:</label>
                        <textarea  name="guardian_address" rows="10" class="form-control" style="width:100%" placeholder="address"><?php echo e($application_data->guardian_address); ?></textarea>
                        
                    </div>

                    <div class="form-group mt-3" style=''>
                        <button class="btn" style="background-color:green; color:white; width:100%">Aprove Application</button>
                    </div>
                </form>
            </div>
            
        </div>
        
        <section>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('lead_three.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/bklubrzz/portal.gandgcollege.com.ng/lead/resources/views/lead_three/pending_admission.blade.php ENDPATH**/ ?>