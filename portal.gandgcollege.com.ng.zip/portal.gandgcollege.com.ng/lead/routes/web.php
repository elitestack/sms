<?php
use App\Http\Controllers\cbt_exam;
use App\Http\Controllers\cbt_score;
use App\Http\Controllers\cbt_user;
use App\Http\Controllers\admin_controller;
use App\Http\Controllers\faculty_controller;
use App\Http\Controllers\department_controller;
use App\Http\Controllers\staff_controller;
use App\Http\Controllers\code_validate;

// sms 
use App\Http\Controllers\lead_five;
use App\Http\Controllers\lead_four;
use App\Http\Controllers\lead_three;
use App\Http\Controllers\lead_two;
use App\Http\Controllers\lead_one;
use App\Http\Controllers\user;

// sms end
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
| 

*/



Route::get('/', function () { return redirect('/student_login'); });
Route::get('/login', function () {     return view('staff_login'); });
// Route::get('/about', function () {     return view('welcome.about'); });
// Route::get('/contact', function () {     return view('welcome.contact'); });
Route::post('/login', [user::class, 'login']);

Route::get('/logout', [user::class, 'logout']);






Route::get('/student_data_update/{student_reg}', [lead_five::class, "admin_student_data"]);

Route::post('/admin_student_data_update', [lead_five::class, "admin_student_data_update"]);








Route::get('/student_login', function () { return view('student_login');});
Route::post('/student_login', [lead_five::class, 'student_login']);
Route::get('/student_application', function () { 
    
    return redirect('/application_login');
    
    return view('student_application');});

// student application 

Route::post('/application_login', [lead_five::class, 'application_login']);


// data reset
Route::get('/application_data_m', [lead_five::class, 'application_data_m']);




Route::get('/application_login', function(){

    return view("application_login");
});

Route::post('/student_passport_upload', [lead_five::class, 'student_passport_upload']);

Route::get('/student_passport_upload', function(){

    return redirect("/application_login");
});

Route::get('/result_sheet/academic_session_id={academic_session_id}&term_id={term_id}&class_id={class_id}&student_reg={student_reg}', [lead_five::class, 'result_sheet']);
Route::get('/mass_result_sheet/academic_session_id={academic_session_id}&term_id={term_id}&class_id={class_id}', [lead_five::class, 'mass_result_sheet']);


Route::get('/id_card', function(){

    return view("id_card");
});

Route::get('/application/{application_id}', [lead_five::class, "application_data"]);


Route::get('/application_associated/{application_id}',[lead_five::class, "associated_application"]);




Route::post('/application', [lead_five::class, "application"]);
Route::post('/student_application_update', [lead_five::class, "student_application_update"]);
Route::post('/student_data_update', [lead_five::class, "student_data_update"]);


Route::post('/student_application', [lead_five::class, 'student_application']);


Route::middleware('lead_three_m')->prefix('/lead_three')->group(function(){

    Route::get('/dashboard', [lead_three::class, 'dashboard']);
    Route::get('/add_student', [lead_three::class, 'student']);
    Route::post('/add_student', [lead_three::class, 'add_student']);
        Route::post('/student_application_approve', [lead_three::class, 'student_application_approve']);
        
        Route::get('/generate_student_reg/{application_id}', [lead_three::class, "generate_student_reg"]);
    Route::get('/application', [lead_three::class, "application"]);
    Route::post('/application', [lead_three::class, "submit_application"]);
        Route::get('/application/{application_id}', [lead_three::class, "pending_admission"]);
    Route::post('/add_student_confirm', [lead_three::class, 'add_student_confirm']);
    Route::get('/add_student_confirm', function(){

        return redirect('/lead_three/add_student');
    });
    Route::post('/student_view', [lead_three::class, 'student_view']);
    Route::post('/fetch_student_term', [lead_three::class, 'fetch_student_term']);

    Route::get('/student_view', function(){
        return redirect('/lead_three/add_student');
    });
    Route::get('/fetch_student_term', function(){
        return redirect('/lead_three/add_student');
    });
    Route::get('/student_view/academic_session_id={academic_session_id}', 
    [lead_three::class, 'student_view_academic_session']);

    Route::get('/student_view/academic_session_id={academic_session_id}/term_id={term_id}/class_id={class_id}', 
    [lead_three::class, 'student_view_academic_session_term']);
    // component start
   

    // component end

});

Route::prefix('/lead_five')->group(function(){

    Route::get('/dashboard/{student_reg}', [lead_five::class, 'dashboard']);
    Route::get('/student_result/{student_reg}', [lead_five::class, 'student_result']);
    Route::get('/student_class/{student_reg}', [lead_five::class, 'student_class']);
    Route::get('/logout', [lead_five::class, 'logout']);
});


// lead one 
Route::middleware('lead_one_m')->prefix('lead_one')->group(function(){

    Route::get('/dashboard', [lead_one::class, 'dashboard']);
    Route::get('/staff', [lead_one::class, 'staff']);
    Route::post('/staff', [lead_one::class, 'staff_create']);


    Route::get('/students', [lead_one::class, 'students']);
    Route::get('/student_class', [lead_one::class, 'student_class']);
    Route::post('/student_class', [lead_one::class, 'create_student_class']);

    Route::get('/subject', [lead_one::class, 'subject']);
    Route::post('/subject', [lead_one::class, 'create_subject']);


    // pending student
    Route::post('/admission_verify', [lead_one::class, 'post_admission_verify']);
    Route::get('/admission_verify', [lead_one::class, 'admission_verify']);
    Route::get('/academic_session/{academic_session_id}', [lead_one::class, 'academic_session_id']);
    Route::post('/academic_session', [lead_one::class, 'create_academic_session']);
    Route::get('/academic_session', [lead_one::class, 'academic_session']);
    Route::post('/academic_status', [lead_one::class, 'academic_session_status']);

    Route::post('/student_application_approve', [lead_one::class, 'student_application_approve']);
    Route::get('/student_application_approve', function(){

        return redirect('/lead_one/dashboard');
    });

    Route::get('/academic_status', function(){

        return redirect('/lead_one/academic_session');
    });

    Route::post('/create_academic_session_term', [lead_one::class, 'create_academic_session_term']);
    Route::get('/create_academic_session_term', function(){
        return redirect("/lead_one/academic_session");
    });
    Route::get('/pending_admission/{application_id}', [lead_one::class, 'pending_admission']);

    // academci session 
    Route::post('/delete_academic_session', [lead_one::class, 'delete_academic_session']);
    Route::post('/delete_academic_session_term', [lead_one::class, 'delete_academic_session_term']);
    Route::post('/term_status', [lead_one::class, 'term_status']);
    Route::get('/term_status', function(){
        return redirect('/lead_one/academic_session');
    });
});
Route::middleware('lead_two_m')->prefix('/lead_two')->group(function(){
    Route::get('/dashboard', [lead_two::class, 'dashboard']);
    Route::get('/staff', [lead_two::class, 'staff']);
    Route::post('/staff', [lead_two::class, 'create_staff']);


    Route::get('/assign_staff', function(){
        return redirect('/lead_two/dashboard');
    });
    Route::post('/assign_staff', [lead_two::class, 'assign_staff']);


    Route::get('/staff/{staff_email}', [lead_two::class, 'staff_data']);
    Route::get('/staff/{staff_email}/{class_id}', [lead_two::class, 'staff_data_assign_subject']);
    Route::get('/subject', [lead_two::class, 'subject']);
    Route::get('/students', [lead_two::class, 'students']);
    Route::get('/student_class', [lead_two::class, 'student_class']);
    Route::get('/student_class/{class_id}', [lead_two::class, 'class_data']);
    Route::post('/assign_subject', [lead_two::class, 'assign_subject']);
    Route::get('/assign_subject', function(){ return redirect('/subject'); });
    Route::post('/assign_subject_confirm', [lead_two::class, 'assign_subject_confirm']);
    Route::post('/assign_class', [lead_two::class, 'assign_class']);
    Route::get('/assign_class', function(){ return redirect('/lead_two/staff'); });
    Route::get('/assign_subject_confirm', function(){ return redirect('/lead_two/staff'); });
    Route::get('/grade_student', [lead_two::class, 'grade_student']);
    Route::post('/grade_student', [lead_two::class, 'grade_student_select']);
    Route::get('/grade_student/academic_session_id={academic_session_id}&class_id={class_id}', [lead_two::class, 'grade_student_session_class']);
    Route::post('/student_result_grade', [lead_two::class, 'student_result_grade']);
    
    // Route::post('/filter_student', [lead_two::class, 'filter_student']);

});





Route::middleware('lead_four_m')->prefix('/lead_four')->group(function(){

    Route::get('/dashboard', [lead_four::class, 'dashboard']);
    Route::get('/class', [lead_four::class, 'class']);
    Route::post('/class', [lead_four::class, 'select_class']);
    Route::get('/class/{class_id}', [lead_four::class, 'class_data']);
    Route::get('/assessment&class_id={class_id}&subject_id={subject_id}&academic_session_id={academic_session_id}&term_id={term_id}', [lead_four::class, 'assessment_data']);
    Route::post('/assessment', [lead_four::class, 'assessment_capture']);
    Route::get('/assessment', function(){ return redirect('/lead_four/dashboard'); });
    Route::get('/student', [lead_four::class, 'student']);
    Route::post('/student', [lead_four::class, 'student_view']);
    Route::get('/student_view/academic_session={academic_session_id}', [lead_four::class, 'student_view_academic_session']);
    Route::get('/student_view/academic_session_id={academic_session_id}/term_id={term_id}/class_id={class_id}', 
    [lead_four::class, 'student_view_academic_session_term']);
    Route::post('/fetch_student_term', [lead_four::class, 'fetch_student_term']);

    Route::get('/fetch_student_term', function(){
        return redirect('/lead_four/student');
    });

    Route::get('/ca_record', [lead_four::class, 'ca_record']);
    Route::post('/ca_record', [lead_four::class, 'ca_record_post']);
    Route::post('/ca_record_start', [lead_four::class, 'ca_record_start']);
    Route::get('/ca_record_start', function(){

        return redirect('/ca_record');
    });

    Route::get('/ca_record/subject_id={subject_id}', [lead_four::class, 'ca_record_subject']);
    Route::get('/ca_record/academic_session_id={academic_session_id}/subject_id={subject_id}', [lead_four::class, 'ca_record_academic_session']);
    Route::get('/ca_record/academic_session_id={academic_session_id}/term_id={term_id}/subject_id={subject_id}', [lead_four::class, 'assessment_data']);
});











