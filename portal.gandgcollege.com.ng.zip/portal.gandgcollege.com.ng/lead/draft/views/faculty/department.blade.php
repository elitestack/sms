@extends('admin.master.app')

@section('content')

<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('faculty.master.side_menu')
    </div>


    <!-- php start -->
    @php 

$department_count = count($department);

@endphp

    <!-- php end -->

<div class="card-expand  mt-5" id="mainbar">

<!-- box start -->

<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h1 class='text-center'>{{$department_count}}</h1>
                        <h5 class="text-center">Total Sections</h5>
                        <h6 class="text-center"><a href="#"><button class="btn btn-danger">view Department</button></a></h6>
        </div>
    <div class="box-holder">

        <div class="box">


        <h1 class='text-center'>0</h1>
                        <h5 class="text-center">Total Students</h5>
                        <h6 class="text-center"><a href="#"><button class="btn btn-danger">view Students</button></a></h6>
        </div>
    </div>
</div>
<!-- end box -->


<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center">Add New Section</h4>
    </div>
    <div class="card-body">
        <form action="{{url('/faculty/add_department')}}" method="post">
            @csrf
            <div class="form-group">
                <label for="" class="form-label">Section Name</label>
                <input type="text" placeholder="type section ..." class="form-control" name="department_name">
            </div>
            <div class="form-group mt-3">
                <button class="btn btn-danger">Add Section</button>
            </div>
        </form>
    </div>
</div>





<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center">Sections</h4>
    </div>
</div>


<div class="card mt-5 mb-5">
    <div class="card-body">
        <h5 class="text-center mt-3">Sections</h5>

        <table class="table">
            
            <thead>
                <tr><th>S/N</th><th>Section</th><th>Section Code</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
            @for($i = 0; $i < $department_count; $i++)
                <tr>
                    <td>{{$i+1}}</td>
                    <td>{{$department[$i]->department_name}}</td>
                    <td>{{$department[$i]->department_id}}</td>
                    <td>{{$department[$i]->department_status}}</td>
                    <td><a href="#"><button class="btn btn-danger">View</button></a></td>
                    <!-- <td><a href="{{url('/department_data/department_id='.$department[$i]->department_id)}}"><button class="btn btn-danger">View</button></a></td> -->
                </tr>
            @endfor
            </tbody>
        </table>
    </div>
</div>



{{-- ending --}}
</div>
</div>

@endsection