<div class="side-menu-non" id="side_content">
    <ul class="mt-4" style="list-style: none;">
        <li class="h-5 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/class/dashboard')}}" class="nav-link"><i class="fa-solid fa-home"></i> Dashboard</a></li>
        <li class="h-5 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/class/department')}}" class="nav-link mt-3"><i class="fa-solid fa-home"></i> Section</a></li>
        <li class="h-5 mt-3 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/class/incoming_request')}}" class="nav-link"><i class="fa-solid fa-home"></i> Incoming Request</a></li>
        <li class="h-5 rounded" style="background-color:#ff6347; color:black"><a style="color:black" href="{{url('/class/logout')}}" class="nav-link mt-3"><i class="fa-solid fa-home"></i> Logout</a></li>
    </ul>
</div>
