@extends('faculty.master.app')

@section('content')

<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('faculty.master.side_menu')
    </div>


    <!-- php start -->

    @php 

$department_count = count($department);

    @endphp

    <!-- php end -->

<div class="card-expand  mt-5" id="mainbar">

<!-- box start -->

<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h1 class='text-center'>{{$department_count}}</h1>
                        <h5 class="text-center">Section</h5>
                        <h6 class="text-center"><a href="{{url('/faculty/department')}}"><button class="btn btn-danger">View Department</button></a></h6>
        </div>
    <div class="box-holder">

        <div class="box">


        <h1 class='text-center'>0</h1>
                        <h5 class="text-center">Students</h5>
                        <h6 class="text-center"><a href="#"><button class="btn btn-danger">View Students</button></a></h6>
        </div>
    </div>

</div>
<!-- end box -->




{{-- ending --}}
</div>
</div>

@endsection