@extends('faculty.master.app')

@section('content')

<div class="dashboard d-flex">
    <div class="sidebar" id="sidebar">
@include('faculty.master.side_menu')
    </div>

    <?php 

$total_department_count = count($total_department);
$activated_department_count = count($activated_department);
    ?>

    <!-- php start -->


    <!-- php end -->

<div class="card-expand  mt-5" id="mainbar">

<!-- box start -->

<div class="box-holder mt-5">
            <div class="box"><h5 class="text-center">
        
                    <h1 class='text-center'>{{$total_department_count}}</h1>
                        <h5 class="text-center">Total Section</h5>
                        <h6 class="text-center"><a href="#"><button class="btn btn-danger">view CBT</button></a></h6>
        </div>
    <div class="box-holder">

        <div class="box">


        <h1 class='text-center'>{{$activated_department_count}}</h1>
                        <h5 class="text-center">Activated Section</h5>
                        <h6 class="text-center"><a href="#"><button class="btn btn-danger">View</button></a></h6>
        </div>
    </div>
   
</div>
<!-- end box -->





<div class="card mt-5" style="position:static" style="width:100%">
    <div class="card-header">
        <h4 class="text-center">Pending Incoming Departments</h4>
    </div>
</div>

<div class="card mt-5 mb-5">
    <div class="card-body">
        <table class="table mt-3">
        <h5 class="text-center mt-3">Department Data</h5>
        <table class="table">
            <thead>
                <tr><th>Email</th><th>Status</th><th>Date</th><th>Action</th>
                         
            </tr>
            </thead>
            <tbody>
@for($i=0; $total_department_count > $i; $i++)
                <tr>
                    <td>{{$total_department[$i]->email}}</td>
                    <td>{{$total_department[$i]->incoming_request}}</td>
                    <td>{{$total_department[$i]->created_at}}</td>
                    <td><form style="display:flex" action="{{url('/faculty/department_incoming_request')}}" method="post">
                        @csrf
                        <input type="hidden" name="email" value="{{$total_department[$i]->email}}">
                        <div class="form-group">
                        <select name="status" id="" class="form-control">
                            <option value="activated">activate</option>
                            <option value="deactivated">deactivate</option>
                        </select>
                        </div>
                    <div class="form-group">
                    <button style="margin-left:7px;" class="btn btn-danger">
                        Save</button>
                    </div>
                    </form></td>
                </tr>
@endfor
            </tbody>
        </table>
    </div>
</div>



{{-- ending --}}
</div>
</div>

@endsection