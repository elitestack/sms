<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="{{asset('/js/jquery.slim.min.js')}}" ></script>
    <script src="{{asset('/js/popper.min.js')}}" ></script>
    <script src="{{asset('/js/bootstrap.bundle.min.js')}}" ></script>
    <script src="{{asset('fontawesome/js/all.js')}}" crossorigin="anonymous"></script>
    <title>CBT Exams</title>
</head>
<style>
    /* new admin extenstion */


.box-holder{

    display:flex;
    flex-direction:row;
    justify-content: space-evenly;
    /* align-items: center; */
    flex-wrap:wrap;
}

.box{

    margin-top:7px;
    height:150px;
    line-height:150px;
    width:300px;
    border-radius:5px;
    color:white;
    background-color: #ff6347;
}

    /* end of new admin extension */
.mainbar{
    margin-left: 27%;
    width: 75%;
}    


.card-expand{
    margin-left: 10%;
    width: 85%;
}

.card-close{
    margin-left: 27%;
    width: 70%;
}

/*question limiting*/

.group{
        display: none;
    }
    
    /*end of question limiting*/


.sidebar{
        transform: ease-in;
        /* background-color: red; */
        height: 100%;
        background-color:rgba(255, 228, 196, 0.616);
        width: 0px;
        transition-timing-function: ease-in;
        transition: width 1s;
        color: black;
        margin-top:10%;
    }
    .side-menu-active{
display: block;
color: white;
    }
    .side-menu-non{
display: none;
color: black;
    }
    .sidebar-slide{
        margin-top: 10%;
        transform: ease-in;
        width:25%;
        background-color:rgba(255, 228, 196, 0.616);
        /* background-color: red; */
        transition-timing-function: ease-in;
        transition: width 1s;
        height: 100%; 
        position:fixed;
    }
    
</style>
<body>
    <div class="header w-100" style="background-color: #ff6347; line-height:50px; position:fixed">
        <a href="javascript:void()" id="menu" style="width:100%; margin-left:10%; color:white"><i class="fa-solid fa-bars"></i></a>
        </div>
        
    @yield('content')
</body>
<script>
        let menu  = document.getElementById('menu');
        let expand = document.getElementById('mainbar');
        let menu_slide = document.getElementById('sidebar');
        let menu_content = document.getElementById('side_content')



    menu.addEventListener('click', function(){
        console.log(menu);
        if(menu_slide.className == 'sidebar'){
            menu_slide.classList.remove('sidebar');
            menu_slide.classList.add('sidebar-slide'); 
            menu_content.classList.remove('side-menu-non');
            menu_content.classList.add('side-menu-active');
            expand.classList.remove('card-expand');
            expand.classList.add('card-close');
        }else{
            menu_slide.classList.remove('sidebar-slide');
            menu_content.classList.remove('side-menu-active');
            menu_slide.classList.add('sidebar');
            menu_content.classList.add('side-menu-non');
            expand.classList.remove('card-close');
            expand.classList.add('card-expand');

        }
        // console.log(menu_slide.classList);
    })
</script>
</html>