<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="{{url('css/bootstrap.min.css')}}">
    <script src="js/jquery.slim.min.js"></script>
    <script src="js/umd/popper.min.js"></script>
    <script src="js/bootstrap.bundle.min.js"></script>
    <script src="/fontawesome/js/all.js" crossorigin="anonymous"></script>
<style>


    @media only screen and (max-width:768px){
        
        
    }
</style>
    <title>CBTDRAFT - Computer Based Testing</title>
</head>
<body class="container" style="background-image: url('/asset/student_cbt.jpg')">

    @yield('content')

    <footer>
        <h4 class="mt-3 text-center"><b>Powered by <a href="{{url('/')}}">CBTDRAFT.COM</a></b></h4>
    </footer>
</body>
</html>